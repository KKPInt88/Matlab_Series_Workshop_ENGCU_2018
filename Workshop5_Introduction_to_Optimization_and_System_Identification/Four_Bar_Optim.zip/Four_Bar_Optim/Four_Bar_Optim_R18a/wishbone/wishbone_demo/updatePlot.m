function varargout = updatePlot(varargin)
%stop = updatePlot(x,optimValues,state,varargin)works for optimtool
%
%[stop, options,optchanged] = updatePlot(optimvalues,options,flag,interval)
%for psearchtool

if nargout == 3
    x = varargin{1}.x;
    varargout{1} = false;
    varargout{2} = varargin{2};
    varargout{3} = false;
else
    x = varargin{1};
    varargout{1} = false;
end
% wrapper for plotting function
time = evalin('base','time;');
wbPlotFun(x,time)

% add intitial profile and/or ideal profile if lost
dataTag = {'ideal','initial'};
for i = 1:length(dataTag)
    hd = findobj(allchild(gcf),'Tag',dataTag{i});
    if isempty(hd)
        switch dataTag{i}
            case 'ideal'
                evalin('base','wbPlotFun(idealProfile)')
            case 'initial'
                if evalin('base','exist(''x0c'',''var'')')
                    evalin('base','wbPlotFun(x0c,time,''initial'')')
                else
                    evalin('base','wbPlotFun(x0,time,''initial'')')
                end
        end
    end
end