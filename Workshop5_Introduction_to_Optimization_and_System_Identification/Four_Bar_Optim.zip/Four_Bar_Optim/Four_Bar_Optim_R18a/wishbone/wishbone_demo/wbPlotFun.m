function wbPlotFun(varargin)
%WBPLOTFUN Plots current solution against initial and ideal profile.
%  WBPLOTFUN plots the current solution profile against the initial and
%  ideal profiles.  All profile inputs are N x 2 where the first column is
%  the x-axis and the second colun is the y-axis.
%
%  SYNTAX:
%   wbPlotFun(idealProfile)                     add ideal profile
%   wbPlotFun(x,time)                           create/add current profile
%   wbPlotFun(x,time,'initial')                 create/add initial profile
%   wbPlotFun(x,time,'current')                 create/add current profile
%   wbPlotFun(idealProfile,'ideal')             replace ideal profile
%   wbPlotFun(initProfile,'initial')            replace initial profile
%   wbPlotFun(currentProfile,'current')         replace current profile
%
%  See also: wbObjFun, wishbonedemo
%

switch nargin
    case 0
        error('You need to provide data to create a plot')

    case 1  % ideal profile defined
        dataTag = 'ideal';
        lineType = 'b-';
        profileData = varargin{1};

    case 2  % Add/Replace ideal, initial, or current profile
        if ischar(varargin{2})
            profileData = varargin{1};
            switch lower(varargin{2})
                case 'ideal'
                    dataTag = 'ideal';
                    lineType = 'b-';
                case 'initial'
                    dataTag = 'initial';
                    lineType = 'g-';
                case 'current'
                    dataTag = 'current';
                    lineType = 'r-';
            end

        else % Assume plotting current data
            dataTag = 'current';
            lineType = 'r-';
            [junk,profileData] = wbObjFun(varargin{1},varargin{2},[]);
        end
    case 3 % Get data and update plot
        [junk,profileData] = wbObjFun(varargin{1},varargin{2},[]);
        switch lower(varargin{3})
            case 'ideal'
                dataTag = 'ideal';
                lineType = 'b-';
            case 'initial'
                dataTag = 'initial';
                lineType = 'g-';
            case 'current'
                dataTag = 'current';
                lineType = 'r-';
        end
end

% test to see if plot figure exists
h = findobj(allchild(0),'Tag','WBPLOT');

if isempty(h)   % create figure if needed
    h = figure;
    hax = plot(profileData(:,1),profileData(:,2),lineType);
    grid on;
    xlabel('Travel Distance (m)'), ylabel('Camber Angle (deg)')
    set(h,'Tag','WBPLOT')
    set(hax,'Tag',dataTag)
    legend(dataTag)

else % update plot
    figure(h)
    % check to see if data is already on plot
    hd = findobj(allchild(h),'Tag',dataTag);

    if isempty(hd) % add data to plot
        hold on
        hd = plot(profileData(:,1),profileData(:,2),lineType);
        set(hd,'Tag',dataTag)
        hold off
        
        % update legend
        [legend_h,object_h,plot_h,text_strings] = legend;
        legend(text_strings,dataTag)

    else % updata plot data

        set(hd,'XData',profileData(:,1))
        set(hd,'YData',profileData(:,2))
        % update legend
        [legend_h,object_h,plot_h,text_strings] = legend;
        legend off
        legend(text_strings)
    end

    drawnow
end