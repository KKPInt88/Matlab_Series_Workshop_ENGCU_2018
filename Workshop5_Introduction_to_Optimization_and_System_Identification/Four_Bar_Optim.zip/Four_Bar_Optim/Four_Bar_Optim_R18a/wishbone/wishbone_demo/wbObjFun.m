function varargout = wbObjFun(x,time,profile)
% Simulate the wishbone model in Simulink and get camber vs. distance
% profile and/or norm of profile
%
% Use:
% F = wbObjFun(x,time,profile) returns norm of profile and sim profile
% [F,P] = wbObjFun(x,time,profile) returns profile in P

if isstruct(x), x = x.x; end

% Run simulation
simopt = simset('SrcWorkspace','Current');
[unused1,unused2,yout]= sim('DoubleWishbone',time,simopt);

% Return norm value]
if isempty(profile)
    varargout{1} = NaN;
else
    varargout{1} = norm(yout(:,1) - profile(:,1)) + norm(yout(:,2) - profile(:,2));
end

if nargout > 1 % return profile if requested
    varargout{2} = yout;
end
