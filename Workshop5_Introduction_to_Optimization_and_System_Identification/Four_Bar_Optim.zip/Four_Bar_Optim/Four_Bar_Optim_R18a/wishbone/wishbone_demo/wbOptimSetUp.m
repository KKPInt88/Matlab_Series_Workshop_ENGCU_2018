%% Define Wishbone Geometry
% Upper arm length (in)
x(1) =  10.8;
% Upper arm front connection (x,y,z, in )
x(2) = 14.2;
x(3) = 18.4;
x(4) = 4.0;
% Upper arm back connection point (x,y,z, in )
x(5) = 13.1;
x(6) = 17.3;
x(7) = -2.3;
% lower arm length (in)
x(8) = 14.3;
% lower arm front connection point (x,y,z, in)
x(9) = 9.1;
x(10) = 7.2;
x(11) = -0.5;
% lower arm back connection (x,y,z, in)
x(12) = 15.1;
x(13) = 8.2;
x(14) = 12.5;
% connecting ling length (in)
x(15) = 12.5;
x = x';
%% Define Geometric Constraints
x0 = x;
theta1 = -25*pi/180;
theta2 = 35*pi/180;
theta3 = 15*pi/180;
theta4 = 30*pi/180;
theta5 = -10*pi/180;
theta6 = 5*pi/180;
Aineq = [2*tan(theta1)  0 0  1 0 0 -1 0 0 0 0 0 0 0 0
         -2*tan(theta2) 0 0 -1 0 0  1 0 0 0 0 0 0 0 0
         0 0 0 0 0 0 0  2*tan(theta3) 0 0  1 0 0 -1 0
         0 0 0 0 0 0 0 -2*tan(theta4) 0 0 -1 0 0  1 0
         0 0  1 tan(theta5) 0 -1 -tan(theta5) 0 0 0 0 0 0 0 0
         0 0 -1 tan(theta5) 0  1 -tan(theta5) 0 0 0 0 0 0 0 0
         0 0 0 0 0 0 0 0 0  1 tan(theta6) 0 -1 -tan(theta6)  0
         0 0 0 0 0 0 0 0 0 -1 tan(theta6) 0  1 -tan(theta6)  0];
bineq = [0;0;0;0;0;0;0;0];

%% Define Bounds
lb = -inf(15,1); lb(15) = 10;
ub = inf(15,1);  ub(15) = 14;
lb(1) = 6; ub(1) = 16; % upper arm length
lb(2) = 10; ub(2) = 16; 
lb(5) = 10; ub(5) = 16;
lb(8) = 8; ub(8) = 18; % lower arm length
lb(9) = 6; ub(9) = 14;
lb(12) = 12; ub(12) = 20; 
ub(15) = 18;
%% Clean Up Variables not Necessary for Optimization Run
clear theta*
%% Load in time vector for simulation
load idealSolution