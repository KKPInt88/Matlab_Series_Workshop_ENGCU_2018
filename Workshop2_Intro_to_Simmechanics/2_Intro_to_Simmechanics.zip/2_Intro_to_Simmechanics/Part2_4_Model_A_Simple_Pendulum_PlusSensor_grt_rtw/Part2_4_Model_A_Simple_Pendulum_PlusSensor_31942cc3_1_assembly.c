/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_4_Model_A_Simple_Pendulum_PlusSensor/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_CTarget.h"

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_checkTargets(const
  double *rtdv, const double *state)
{
  (void) rtdv;
  (void) state;
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_setTargets(const
  double *rtdv, CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_resetStateVector(
  const void *mech, double *state)
{
  double xx[1];
  (void) mech;
  xx[0] = 0.0;
  state[0] = xx[0];
  state[1] = xx[0];
}

void
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_initializeTrackedAngleState
  (const void *mech, const double *rtdv, const double *motionData, double *state,
   void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) motionData;
  (void) state;
  (void) neDiagMgr;
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_computeDiscreteState(
  const void *mech, const double *rtdv, double *state)
{
  (void) mech;
  (void) rtdv;
  (void) state;
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_adjustPosition(const
  void *mech, const double *dofDeltas, double *state)
{
  (void) mech;
  state[0] = state[0] + dofDeltas[0];
}

static void perturbJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[1] = state[1] - 0.875 * mag;
}

void
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_perturbJointPrimitiveState
  (const void *mech, size_t stageIdx, size_t primIdx, double mag, boolean_T
   doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbJointPrimitiveState_0_0v(mag, state);
    break;
  }
}

void
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_perturbFlexibleBodyState
  (const void *mech, size_t stageIdx, double mag, boolean_T doPerturbVelocity,
   double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch (stageIdx * 2 + (doPerturbVelocity ? 1 : 0))
  {
  }
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_computeDofBlendMatrix
  (const void *mech, size_t stageIdx, size_t primIdx, const double *state, int
   partialType, double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_projectPartiallyTargetedPos
  (const void *mech, size_t stageIdx, size_t primIdx, const double *origState,
   int partialType, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_propagateMotion(const
  void *mech, const double *rtdv, const double *state, double *motionData)
{
  double xx[6];
  (void) mech;
  (void) rtdv;
  xx[0] = 0.5 * state[0];
  xx[1] = cos(xx[0]);
  xx[2] = 0.0;
  xx[3] = sin(xx[0]);
  xx[0] = 0.1;
  xx[4] = 2.0;
  xx[5] = xx[0] * xx[3];
  motionData[0] = - xx[1];
  motionData[1] = xx[2];
  motionData[2] = xx[2];
  motionData[3] = - xx[3];
  motionData[4] = xx[0] - xx[4] * xx[5] * xx[3];
  motionData[5] = xx[4] * xx[5] * xx[1];
  motionData[6] = xx[2];
  motionData[7] = xx[2];
  motionData[8] = xx[2];
  motionData[9] = state[1];
  motionData[10] = xx[2];
  motionData[11] = xx[0] * state[1];
  motionData[12] = xx[2];
}

size_t
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_computeAssemblyError(
  const void *mech, const double *rtdv, size_t constraintIdx, const double
  *state, const double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) state;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_computeAssemblyJacobian(
  const void *mech, const double *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const double *motionData, double
  *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_computeFullAssemblyJacobian
  (const void *mech, const double *rtdv, const double *state, const double
   *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) motionData;
  (void) J;
  return 0;
}

int
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_isInKinematicSingularity
  (const void *mech, const double *rtdv, size_t constraintIdx, const double
   *motionData)
{
  (void) mech;
  (void) rtdv
    ;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

PmfMessageId
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_convertStateVector(const
  void *asmMech, const double *rtdv, const void *simMech, const double *asmState,
  double *simState, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) asmMech;
  (void) rtdv;
  (void) simMech;
  (void) neDiagMgr;
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  return NULL;
}

void Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_constructStateVector(
  const void *mech, const double *solverState, const double *u, const double
  *uDot, double *discreteState, double *fullState)
{
  (void) mech;
  (void) u;
  (void) uDot;
  (void) discreteState;
  fullState[0] = solverState[0];
  fullState[1] = solverState[1];
}

void
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_extractSolverStateVector
  (const void *mech, const double *fullState, double *solverState)
{
  (void) mech;
  solverState[0] = fullState[0];
  solverState[1] = fullState[1];
}

int Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_isPositionViolation(
  const void *mech, const double *rtdv, const int *eqnEnableFlags, const double *
  state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

int Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_isVelocityViolation(
  const void *mech, const double *rtdv, const int *eqnEnableFlags, const double *
  state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

PmfMessageId
  Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_projectStateSim(const
  void *mech, const double *rtdv, const int *eqnEnableFlags, const double *input,
  double *state, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) input;
  (void) state;
  (void) neDiagMgr;
  return NULL;
}
