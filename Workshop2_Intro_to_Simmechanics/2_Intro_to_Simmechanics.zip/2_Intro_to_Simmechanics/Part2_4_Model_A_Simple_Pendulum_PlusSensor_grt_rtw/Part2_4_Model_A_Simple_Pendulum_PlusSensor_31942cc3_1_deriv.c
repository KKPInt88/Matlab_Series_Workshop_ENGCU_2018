/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_4_Model_A_Simple_Pendulum_PlusSensor/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

PmfMessageId Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_deriv(const
  double *rtdv, const int *eqnEnableFlags, const double *state, const double
  *input, const double *inputDot, const double *inputDdot, const double
  *discreteState, double *deriv, double *errorResult, NeuDiagnosticManager
  *neDiagMgr)
{
  int ii[1];
  double xx[3];
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.4409e-3;
  ii[0] = factorSymmetricPosDef(xx + 0, 1, xx + 1);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'Part2_4_Model_A_Simple_Pendulum_PlusSensor/Revolute Joint 0' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[1] = 9.806649999999999;
  xx[2] = sin(0.5 * state[0]);
  deriv[0] = state[1];
  deriv[1] = - (5.729577951308232e-4 * state[1] / xx[0] + 0.0108 * (xx[1] - 2.0 *
    xx[1] * xx[2] * xx[2]) / xx[0]);
  errorResult[0] = 0.0;
  return NULL;
}
