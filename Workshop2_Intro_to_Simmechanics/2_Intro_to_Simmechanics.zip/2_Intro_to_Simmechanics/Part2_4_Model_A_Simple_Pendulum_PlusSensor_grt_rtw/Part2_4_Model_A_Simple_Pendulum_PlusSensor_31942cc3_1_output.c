/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_4_Model_A_Simple_Pendulum_PlusSensor/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

PmfMessageId Part2_4_Model_A_Simple_Pendulum_PlusSensor_31942cc3_1_output(const
  double *rtdv, const double *state, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *output,
  NeuDiagnosticManager *neDiagMgr)
{
  (void) rtdv;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  output[0] = state[0];
  output[1] = state[1];
  return NULL;
}
