%% Part 2.4: Analyze a Simple Pendulum


Time = Simout_Pos.Time;
Pos  = Simout_Pos.Data;
Vel  = Simout_Vel.Data;

figure;
plot(Time, Pos, 'LineWidth', 2, 'Color', 'b');
hold on;
plot(Time, Vel, 'LineWidth', 2, 'Color', 'r');
xlabel('Time [s]');
ylabel('Pos [deg], Vel [deg/s]');
grid on;

