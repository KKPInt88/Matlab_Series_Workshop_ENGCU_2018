/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_3_Model_A_Simple_Pendulum/Solver Configuration'.
 */

#ifndef __Part2_3_Model_A_Simple_Pendulum_f09ca3b6_1_h__
#define __Part2_3_Model_A_Simple_Pendulum_f09ca3b6_1_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void Part2_3_Model_A_Simple_Pendulum_f09ca3b6_1_dae( NeDae **dae, const
    NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}
#endif
#endif
