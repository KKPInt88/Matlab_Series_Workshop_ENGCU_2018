/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

PmfMessageId sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_deriv(const double
  *rtdv, const int *eqnEnableFlags, const double *state, const double *input,
  const double *inputDot, const double *inputDdot, const double *discreteState,
  double *deriv, double *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  int ii[1];
  double xx[114];
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 0.4927254562275936;
  xx[1] = 0.5;
  xx[2] = xx[1] * state[2];
  xx[3] = cos(xx[2]);
  xx[4] = xx[0] * xx[3];
  xx[5] = 0.05740930144226845;
  xx[6] = sin(xx[2]);
  xx[2] = xx[5] * xx[6];
  xx[7] = xx[0] * xx[2];
  xx[8] = 0.5071702128332358;
  xx[9] = 0.9983507260015945;
  xx[10] = xx[9] * xx[6];
  xx[6] = xx[8] * xx[10];
  xx[11] = xx[4] + xx[7] - xx[6];
  xx[12] = xx[4] - xx[7] + xx[6];
  xx[4] = xx[8] * xx[3];
  xx[3] = xx[8] * xx[2];
  xx[2] = xx[0] * xx[10];
  xx[0] = xx[4] - xx[3] - xx[2];
  xx[6] = xx[2] + xx[4] + xx[3];
  xx[13] = - xx[11];
  xx[14] = xx[12];
  xx[15] = xx[0];
  xx[16] = - xx[6];
  xx[2] = 0.9995875964620595;
  xx[3] = xx[1] * state[4];
  xx[1] = cos(xx[3]);
  xx[4] = xx[2] * xx[1];
  xx[7] = 0.02871649350465279;
  xx[8] = sin(xx[3]);
  xx[3] = xx[7] * xx[8];
  xx[10] = xx[7] * xx[1];
  xx[1] = xx[2] * xx[8];
  xx[17] = xx[4];
  xx[18] = xx[3];
  xx[19] = xx[10];
  xx[20] = xx[1];
  xx[2] = 0.1240023369106498;
  xx[7] = xx[9] * state[3];
  xx[8] = 2.0;
  xx[21] = 0.07478806191712499;
  xx[22] = xx[21] * xx[10];
  xx[23] = xx[21] * xx[1];
  xx[24] = 0.07407490243288437 - (xx[8] * (xx[22] * xx[10] + xx[23] * xx[1]) -
    xx[21]);
  xx[25] = xx[5] * state[3];
  xx[26] = 0.01297012185805613 - xx[8] * (xx[22] * xx[4] - xx[23] * xx[3]);
  xx[27] = xx[7] * xx[24] - xx[25] * xx[26];
  xx[28] = xx[8] * (xx[23] * xx[4] + xx[22] * xx[3]);
  xx[29] = - (xx[7] * xx[27]);
  xx[30] = - (xx[28] * xx[7] * xx[7] + xx[28] * xx[25] * xx[25]);
  xx[31] = xx[25] * xx[27];
  pm_math_quatInverseXform(xx + 17, xx + 29, xx + 32);
  xx[22] = xx[21] * state[5];
  xx[23] = xx[25] * xx[10];
  xx[29] = xx[3];
  xx[30] = xx[10];
  xx[31] = xx[1];
  xx[27] = xx[10] * xx[7];
  xx[35] = xx[1] * xx[25] - xx[3] * xx[7];
  xx[36] = xx[27];
  xx[37] = xx[35];
  xx[38] = - xx[23];
  pm_math_cross3(xx + 29, xx + 36, xx + 39);
  xx[36] = xx[7] + xx[8] * (xx[4] * xx[23] + xx[41]);
  xx[23] = xx[36] + state[5];
  xx[37] = - 0.4928117066797887;
  xx[38] = - 0.5070864046287911;
  xx[42] = xx[37];
  xx[43] = xx[38];
  xx[44] = xx[37];
  xx[45] = xx[38];
  pm_math_quatCompose(xx + 42, xx + 13, xx + 46);
  pm_math_quatCompose(xx + 46, xx + 17, xx + 42);
  xx[37] = input[1] * xx[44];
  xx[38] = input[1] * xx[45];
  xx[46] = xx[8] * (xx[37] * xx[43] - xx[38] * xx[42]);
  xx[47] = xx[2] * xx[33] - xx[46];
  xx[48] = 9.27389445074187e-3;
  xx[49] = xx[25] + xx[8] * (xx[39] - xx[4] * xx[27]);
  xx[27] = xx[8] * (xx[40] - xx[4] * xx[35]);
  xx[39] = xx[49];
  xx[40] = xx[27];
  xx[41] = xx[23];
  xx[35] = 1.039974894775706e-5;
  xx[50] = 2.532320843039589e-4;
  xx[51] = 2.615651276365386e-4;
  xx[52] = xx[35] * xx[49];
  xx[53] = xx[50] * xx[27];
  xx[54] = xx[51] * xx[23];
  pm_math_cross3(xx + 39, xx + 52, xx + 55);
  xx[39] = xx[57] + xx[21] * xx[46];
  xx[40] = 9.551417200315035e-4;
  ii[0] = factorSymmetricPosDef(xx + 40, 1, xx + 41);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Upper Revolute' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[41] = (xx[39] + xx[21] * xx[47]) / xx[40];
  xx[33] = xx[8] * (xx[37] * xx[42] + xx[38] * xx[43]);
  xx[52] = xx[2] * (xx[32] - xx[22] * (xx[36] + xx[23])) - (input[1] - xx[8] *
    (xx[37] * xx[44] + xx[38] * xx[45]));
  xx[53] = xx[47] - xx[48] * xx[41];
  xx[54] = xx[2] * (xx[22] * (xx[49] + xx[49]) + xx[34]) - xx[33];
  pm_math_quatXform(xx + 17, xx + 52, xx + 36);
  xx[22] = 0.1067918730131247;
  xx[23] = xx[22] * state[3];
  xx[32] = xx[23] * xx[25];
  xx[25] = xx[4] * xx[4];
  xx[34] = 1.0;
  xx[42] = xx[8] * (xx[25] + xx[3] * xx[3]) - xx[34];
  xx[43] = xx[3] * xx[10];
  xx[44] = xx[1] * xx[4];
  xx[45] = xx[8] * (xx[43] - xx[44]);
  xx[46] = xx[1] * xx[3];
  xx[47] = xx[4] * xx[10];
  xx[52] = xx[8] * (xx[46] + xx[47]);
  xx[53] = xx[8] * (xx[43] + xx[44]);
  xx[43] = xx[8] * (xx[25] + xx[10] * xx[10]) - xx[34];
  xx[44] = xx[1] * xx[10];
  xx[54] = xx[4] * xx[3];
  xx[58] = xx[8] * (xx[44] - xx[54]);
  xx[59] = xx[8] * (xx[46] - xx[47]);
  xx[46] = xx[8] * (xx[44] + xx[54]);
  xx[44] = xx[8] * (xx[25] + xx[1] * xx[1]) - xx[34];
  xx[60] = xx[42];
  xx[61] = xx[45];
  xx[62] = xx[52];
  xx[63] = xx[53];
  xx[64] = xx[43];
  xx[65] = xx[58];
  xx[66] = xx[59];
  xx[67] = xx[46];
  xx[68] = xx[44];
  xx[25] = xx[48] / xx[40];
  xx[47] = xx[2] - xx[48] * xx[25];
  xx[69] = xx[2] * xx[42];
  xx[70] = xx[2] * xx[53];
  xx[71] = xx[2] * xx[59];
  xx[72] = xx[45] * xx[47];
  xx[73] = xx[43] * xx[47];
  xx[74] = xx[46] * xx[47];
  xx[75] = xx[2] * xx[52];
  xx[76] = xx[2] * xx[58];
  xx[77] = xx[2] * xx[44];
  pm_math_matrix3x3Compose(xx + 60, xx + 69, xx + 78);
  xx[2] = xx[23] * xx[7];
  xx[7] = 0.181849237404727;
  xx[23] = xx[7] + xx[78];
  xx[47] = xx[51] * xx[25];
  xx[48] = xx[45] * xx[47];
  xx[54] = xx[52] * xx[48];
  xx[69] = xx[24];
  xx[70] = xx[28];
  xx[71] = xx[26];
  pm_math_matrix3x3PostCross(xx + 78, xx + 69, xx + 87);
  xx[72] = xx[54] + xx[87];
  xx[73] = xx[48] * xx[44];
  xx[74] = xx[73] + xx[89];
  xx[75] = xx[22] * xx[79] - (xx[5] * xx[72] + xx[9] * xx[74]);
  xx[76] = xx[55] + xx[35] * xx[27] * state[5];
  xx[77] = xx[56] - xx[21] * xx[33] - xx[50] * state[5] * xx[49];
  xx[78] = xx[39] - xx[51] * xx[41];
  pm_math_quatXform(xx + 17, xx + 76, xx + 55);
  pm_math_cross3(xx + 69, xx + 36, xx + 76);
  xx[21] = xx[46] * xx[47];
  xx[27] = xx[52] * xx[21];
  xx[33] = xx[27] + xx[93];
  xx[39] = xx[21] * xx[44];
  xx[49] = xx[39] + xx[95];
  xx[56] = xx[37] + xx[32] * xx[83] - xx[2] * xx[81];
  xx[37] = xx[51] / xx[40];
  xx[40] = xx[51] - xx[51] * xx[37];
  xx[96] = xx[35] * xx[42];
  xx[97] = xx[35] * xx[53];
  xx[98] = xx[35] * xx[59];
  xx[99] = xx[50] * xx[45];
  xx[100] = xx[50] * xx[43];
  xx[101] = xx[50] * xx[46];
  xx[102] = xx[52] * xx[40];
  xx[103] = xx[58] * xx[40];
  xx[104] = xx[40] * xx[44];
  pm_math_matrix3x3Compose(xx + 60, xx + 96, xx + 105);
  xx[35] = xx[47] * xx[43];
  xx[40] = xx[52] * xx[35];
  xx[42] = xx[35] * xx[44];
  xx[59] = - xx[54];
  xx[60] = - xx[40];
  xx[61] = - xx[27];
  xx[62] = - (xx[58] * xx[48]);
  xx[63] = - (xx[58] * xx[35]);
  xx[64] = - (xx[58] * xx[21]);
  xx[65] = - xx[73];
  xx[66] = - xx[42];
  xx[67] = - xx[39];
  pm_math_matrix3x3PostCross(xx + 59, xx + 69, xx + 96);
  pm_math_matrix3x3PreCross(xx + 87, xx + 69, xx + 58);
  xx[21] = xx[40] + xx[90];
  xx[27] = xx[42] + xx[92];
  xx[35] = xx[7] + xx[82];
  xx[39] = xx[22] * xx[35] - (xx[5] * xx[21] + xx[9] * xx[27]);
  xx[40] = xx[5] * (xx[5] * (2.225633182644876e-5 + xx[105] - xx[96] - xx[96] -
    xx[58]) + xx[9] * (xx[107] - xx[98] - xx[102] - xx[60]) - xx[22] * xx[21]) +
    xx[9] * (xx[5] * (xx[111] - xx[102] - xx[98] - xx[64]) + xx[9] *
             (6.723243232537792e-4 + xx[113] - xx[104] - xx[104] - xx[66]) - xx
             [22] * xx[27]) + xx[22] * xx[39];
  ii[0] = factorSymmetricPosDef(xx + 40, 1, xx + 21);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Lower  Revolute' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[21] = (xx[5] * (xx[55] + xx[76] + xx[2] * xx[72] - xx[32] * xx[33]) + xx[9]
            * (xx[57] + xx[78] + xx[2] * xx[74] - xx[32] * xx[49]) + xx[22] *
            xx[56]) / xx[40];
  xx[27] = xx[7] + xx[86];
  xx[7] = xx[22] * xx[85] - (xx[5] * xx[33] + xx[9] * xx[49]);
  xx[42] = xx[36] + xx[32] * xx[80] - xx[2] * xx[23] - xx[75] * xx[21];
  xx[43] = xx[56] - xx[39] * xx[21];
  xx[44] = xx[38] + xx[32] * xx[27] - xx[2] * xx[84] - xx[7] * xx[21];
  pm_math_quatXform(xx + 13, xx + 42, xx + 45);
  xx[33] = xx[11] * xx[11];
  xx[36] = xx[0] * xx[12];
  xx[38] = xx[11] * xx[6];
  xx[42] = xx[6] * xx[12];
  xx[43] = xx[0] * xx[11];
  xx[44] = xx[11] * xx[12];
  xx[11] = xx[0] * xx[6];
  xx[48] = xx[8] * (xx[33] + xx[12] * xx[12]) - xx[34];
  xx[49] = xx[8] * (xx[36] - xx[38]);
  xx[50] = - (xx[8] * (xx[42] + xx[43]));
  xx[51] = xx[8] * (xx[36] + xx[38]);
  xx[52] = xx[8] * (xx[33] + xx[0] * xx[0]) - xx[34];
  xx[53] = xx[8] * (xx[44] - xx[11]);
  xx[54] = xx[8] * (xx[43] - xx[42]);
  xx[55] = - (xx[8] * (xx[11] + xx[44]));
  xx[56] = xx[8] * (xx[33] + xx[6] * xx[6]) - xx[34];
  xx[0] = xx[75] / xx[40];
  xx[6] = xx[39] * xx[0];
  xx[11] = xx[7] * xx[0];
  xx[12] = xx[39] / xx[40];
  xx[33] = xx[7] * xx[12];
  xx[34] = xx[7] / xx[40];
  xx[57] = xx[23] - xx[75] * xx[0];
  xx[58] = xx[79] - xx[6];
  xx[59] = xx[80] - xx[11];
  xx[60] = xx[81] - xx[6];
  xx[61] = xx[35] - xx[39] * xx[12];
  xx[62] = xx[83] - xx[33];
  xx[63] = xx[84] - xx[11];
  xx[64] = xx[85] - xx[33];
  xx[65] = xx[27] - xx[7] * xx[34];
  pm_math_matrix3x3ComposeTranspose(xx + 57, xx + 48, xx + 66);
  pm_math_matrix3x3Compose(xx + 48, xx + 66, xx + 57);
  xx[6] = 0.6041911427450275 + xx[65];
  memcpy(xx + 7, xx + 6, 1 * sizeof(double));
  ii[0] = factorSymmetricPosDef(xx + 7, 1, xx + 11);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "sm:compiler:messages:simulationErrors:DegenerateMass",
      "'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Guide-Cart Prismatic' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[38] = xx[59] / xx[7];
  xx[39] = xx[62] / xx[7];
  xx[40] = xx[6] / xx[7];
  xx[6] = 0.2800410378370479;
  xx[11] = 9.806002091429882;
  xx[23] = 3.552713678800501e-15;
  xx[42] = xx[6];
  xx[43] = xx[11];
  xx[44] = - xx[23];
  xx[27] = (input[0] - xx[47]) / xx[7] - pm_math_dot3(xx + 38, xx + 42);
  xx[38] = xx[0];
  xx[39] = xx[12];
  xx[40] = xx[34];
  xx[33] = xx[6];
  xx[34] = xx[11];
  xx[35] = xx[27] - xx[23];
  pm_math_quatInverseXform(xx + 13, xx + 33, xx + 42);
  xx[0] = xx[21] + pm_math_dot3(xx + 38, xx + 42);
  xx[6] = xx[9] * xx[0];
  xx[7] = xx[5] * xx[0];
  xx[5] = xx[7] * xx[10];
  xx[11] = - (xx[10] * xx[6]);
  xx[12] = xx[3] * xx[6] - xx[1] * xx[7];
  xx[13] = xx[5];
  pm_math_cross3(xx + 29, xx + 11, xx + 14);
  xx[9] = xx[42] - xx[2] + xx[28] * xx[6];
  xx[10] = xx[43] - xx[22] * xx[0] + xx[7] * xx[26] - xx[6] * xx[24];
  xx[11] = xx[44] + xx[32] - xx[28] * xx[7];
  pm_math_quatInverseXform(xx + 17, xx + 9, xx + 1);
  deriv[0] = state[1];
  deriv[1] = xx[27];
  deriv[2] = state[3];
  deriv[3] = - xx[0];
  deriv[4] = state[5];
  deriv[5] = - (xx[41] + (xx[8] * (xx[16] - xx[5] * xx[4]) - xx[6]) * xx[37] +
                xx[25] * xx[2]);
  errorResult[0] = 0.0;
  return NULL;
}
