/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeConstraintError(const
  void *mech, const double *rtdv, const double *state, double *error)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) error;
}
