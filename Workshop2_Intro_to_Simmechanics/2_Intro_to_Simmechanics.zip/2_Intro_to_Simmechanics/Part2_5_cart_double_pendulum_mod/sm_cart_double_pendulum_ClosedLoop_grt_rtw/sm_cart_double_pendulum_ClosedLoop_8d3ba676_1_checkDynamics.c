/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

PmfMessageId sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_checkDynamics(const
  double *rtdv, const double *state, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *result,
  NeuDiagnosticManager *neDiagMgr)
{
  double xx[20];
  (void) rtdv;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 0.07478806191712499;
  xx[1] = 2.0;
  xx[2] = - 0.4928117066797887;
  xx[3] = - 0.5070864046287911;
  xx[4] = xx[2];
  xx[5] = xx[3];
  xx[6] = xx[2];
  xx[7] = xx[3];
  xx[2] = 0.4927254562275936;
  xx[3] = 0.5;
  xx[8] = xx[3] * state[2];
  xx[9] = cos(xx[8]);
  xx[10] = xx[2] * xx[9];
  xx[11] = sin(xx[8]);
  xx[8] = 0.05740930144226845 * xx[11];
  xx[12] = xx[2] * xx[8];
  xx[13] = 0.5071702128332358;
  xx[14] = 0.9983507260015945 * xx[11];
  xx[11] = xx[13] * xx[14];
  xx[15] = xx[13] * xx[9];
  xx[9] = xx[13] * xx[8];
  xx[8] = xx[2] * xx[14];
  xx[16] = - (xx[10] + xx[12] - xx[11]);
  xx[17] = xx[10] - xx[12] + xx[11];
  xx[18] = xx[15] - xx[9] - xx[8];
  xx[19] = - (xx[8] + xx[15] + xx[9]);
  pm_math_quatCompose(xx + 4, xx + 16, xx + 8);
  xx[2] = 0.9995875964620595;
  xx[4] = xx[3] * state[4];
  xx[3] = cos(xx[4]);
  xx[5] = 0.02871649350465279;
  xx[6] = sin(xx[4]);
  xx[12] = xx[2] * xx[3];
  xx[13] = xx[5] * xx[6];
  xx[14] = xx[5] * xx[3];
  xx[15] = xx[2] * xx[6];
  pm_math_quatCompose(xx + 8, xx + 12, xx + 2);
  xx[6] = input[1] * xx[4];
  xx[7] = input[1] * xx[5];
  xx[8] = xx[1] * (xx[6] * xx[2] + xx[7] * xx[3]);
  xx[9] = xx[0] * xx[8];
  xx[10] = xx[1] * (xx[6] * xx[3] - xx[7] * xx[2]);
  xx[2] = xx[0] * xx[10];
  xx[0] = input[1] - xx[1] * (xx[6] * xx[4] + xx[7] * xx[5]);
  result[0] = xx[9] * xx[9] + xx[2] * xx[2] + xx[0] * xx[0] + xx[10] * xx[10] +
    xx[8] * xx[8];
  return NULL;
}
