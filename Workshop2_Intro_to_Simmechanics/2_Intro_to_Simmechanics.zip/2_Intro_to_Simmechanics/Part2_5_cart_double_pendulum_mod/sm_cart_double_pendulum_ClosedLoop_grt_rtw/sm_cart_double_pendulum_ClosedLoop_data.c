/*
 * sm_cart_double_pendulum_ClosedLoop_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sm_cart_double_pendulum_ClosedLoop".
 *
 * Model version              : 1.704
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Wed Oct 24 19:10:23 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sm_cart_double_pendulum_ClosedLoop.h"
#include "sm_cart_double_pendulum_ClosedLoop_private.h"

/* Constant parameters (default storage) */
const ConstP_sm_cart_double_pendulu_T sm_cart_double_pendulum__ConstP = {
  /* Expression: inv(C_modal)
   * Referenced by: '<Root>/Gain3'
   */
  { 0.019999999999999983, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.04, 0.0, 0.0, 0.0, 0.0,
    -0.0014759767203807765, 1.1782364560522644E-18, 0.16831143923228775,
    -0.19962159789269848, 0.16831143923228803, 0.19962159789269879,
    6.9341563255546668E-20, -0.0029519534407615568, -0.014512828911343931,
    0.027864755929184696, 0.014512828911343938, 0.027864755929184727,
    -0.00029967703097082279, 1.1533222296516744E-17, -0.21094779878655198,
    -0.050723355394026517, -0.21094779878655234, 0.050723355394026066,
    1.0157765228029092E-19, -0.00059935406194164471, 0.018189193360700268,
    0.0070803657163568557, -0.018189193360700254, 0.0070803657163568227 },

  /* Expression: -Kx
   * Referenced by: '<Root>/Gain'
   */
  { -49.999999999287425, -40.735739416135864, 2.7820787078168596,
    1.4323485192820229, -198.39810478767211, 250.48717406786344 }
};
