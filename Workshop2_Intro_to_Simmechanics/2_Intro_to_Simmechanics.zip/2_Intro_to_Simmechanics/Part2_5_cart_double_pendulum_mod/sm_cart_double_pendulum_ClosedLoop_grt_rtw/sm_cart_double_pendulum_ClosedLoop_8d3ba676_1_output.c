/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

PmfMessageId sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_output(const double
  *rtdv, const double *state, const double *input, const double *inputDot, const
  double *inputDdot, const double *discreteState, double *output,
  NeuDiagnosticManager *neDiagMgr)
{
  (void) rtdv;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  output[0] = state[0];
  output[1] = state[1];
  output[2] = state[2];
  output[3] = state[3];
  output[4] = state[4];
  output[5] = state[5];
  return NULL;
}
