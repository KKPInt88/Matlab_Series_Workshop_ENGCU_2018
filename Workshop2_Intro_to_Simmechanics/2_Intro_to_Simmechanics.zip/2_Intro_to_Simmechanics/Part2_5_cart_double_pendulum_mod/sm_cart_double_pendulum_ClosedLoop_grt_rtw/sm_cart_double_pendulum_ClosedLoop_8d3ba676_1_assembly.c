/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_CTarget.h"

static boolean_T checkTargets_0(const double *rtdv, const double *state)
{
  (void) rtdv;
  return fabs(state[0] - 0.07000000000000001) < 1.0e-9;
}

static boolean_T checkTargets_1(const double *rtdv, const double *state)
{
  (void) rtdv;
  return fabs(state[1]) < 1.0e-9;
}

static boolean_T checkTargets_2(const double *rtdv, const double *state)
{
  (void) rtdv;
  return fabs(state[2] + 0.3490658503988659) < 1.0e-9;
}

static boolean_T checkTargets_4(const double *rtdv, const double *state)
{
  (void) rtdv;
  return fabs(state[4] - 0.3490658503988659) < 1.0e-9;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_checkTargets(const double
  *rtdv, const double *state)
{
  const char *msgId = "sm:compiler:state:UnsatisfiedDesiredTarget";
  if (!checkTargets_0(rtdv, state)) {
    pmf_preformatted_warning(
      msgId,
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Guide-Cart Prismatic Pz high priority position target not achieved");
    pmf_printf("[manual]sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Guide-Cart Prismatic Pz high priority position target not achieved\n");
  }

  if (!checkTargets_1(rtdv, state)) {
    pmf_preformatted_warning(
      msgId,
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Guide-Cart Prismatic Pz high priority velocity target not achieved");
    pmf_printf("[manual]sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Guide-Cart Prismatic Pz high priority velocity target not achieved\n");
  }

  if (!checkTargets_2(rtdv, state)) {
    pmf_preformatted_warning(
      msgId,
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Lower  Revolute Rz high priority position target not achieved");
    pmf_printf("[manual]sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Lower  Revolute Rz high priority position target not achieved\n");
  }

  if (!checkTargets_4(rtdv, state)) {
    pmf_preformatted_warning(
      msgId,
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Upper Revolute Rz high priority position target not achieved");
    pmf_printf("[manual]sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Upper Revolute Rz high priority position target not achieved\n");
  }
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_setTargets(const double *rtdv,
  CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_resetStateVector(const void
  *mech, double *state)
{
  double xx[1];
  (void) mech;
  xx[0] = 0.0;
  state[0] = xx[0];
  state[1] = xx[0];
  state[2] = xx[0];
  state[3] = xx[0];
  state[4] = xx[0];
  state[5] = xx[0];
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_initializeTrackedAngleState(
  const void *mech, const double *rtdv, const double *motionData, double *state,
  void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) motionData;
  (void) state;
  (void) neDiagMgr;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeDiscreteState(const
  void *mech, const double *rtdv, double *state)
{
  (void) mech;
  (void) rtdv;
  (void) state;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_adjustPosition(const void
  *mech, const double *dofDeltas, double *state)
{
  (void) mech;
  state[0] = state[0] + dofDeltas[0];
  state[2] = state[2] + dofDeltas[1];
  state[4] = state[4] + dofDeltas[2];
}

static void perturbJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[1] = state[1] - 0.875 * mag;
}

static void perturbJointPrimitiveState_1_0(double mag, double *state)
{
  state[2] = state[2] + mag;
}

static void perturbJointPrimitiveState_1_0v(double mag, double *state)
{
  state[2] = state[2] + mag;
  state[3] = state[3] - 0.875 * mag;
}

static void perturbJointPrimitiveState_2_0(double mag, double *state)
{
  state[4] = state[4] + mag;
}

static void perturbJointPrimitiveState_2_0v(double mag, double *state)
{
  state[4] = state[4] + mag;
  state[5] = state[5] - 0.875 * mag;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_perturbJointPrimitiveState(
  const void *mech, size_t stageIdx, size_t primIdx, double mag, boolean_T
  doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbJointPrimitiveState_0_0v(mag, state);
    break;

   case 12:
    perturbJointPrimitiveState_1_0(mag, state);
    break;

   case 13:
    perturbJointPrimitiveState_1_0v(mag, state);
    break;

   case 24:
    perturbJointPrimitiveState_2_0(mag, state);
    break;

   case 25:
    perturbJointPrimitiveState_2_0v(mag, state);
    break;
  }
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_perturbFlexibleBodyState(
  const void *mech, size_t stageIdx, double mag, boolean_T doPerturbVelocity,
  double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch (stageIdx * 2 + (doPerturbVelocity ? 1 : 0))
  {
  }
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeDofBlendMatrix(const
  void *mech, size_t stageIdx, size_t primIdx, const double *state, int
  partialType, double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_projectPartiallyTargetedPos(
  const void *mech, size_t stageIdx, size_t primIdx, const double *origState,
  int partialType, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_propagateMotion(const void
  *mech, const double *rtdv, const double *state, double *motionData)
{
  double xx[56];
  (void) mech;
  (void) rtdv;
  xx[0] = - 0.4928117066797887;
  xx[1] = - 0.5070864046287911;
  xx[2] = 7.99546431367973e-3;
  xx[3] = 0.03660563255907853;
  xx[4] = 0.4927254562275936;
  xx[5] = 0.5;
  xx[6] = xx[5] * state[2];
  xx[7] = cos(xx[6]);
  xx[8] = xx[4] * xx[7];
  xx[9] = 0.05740930144226845;
  xx[10] = sin(xx[6]);
  xx[6] = xx[9] * xx[10];
  xx[11] = xx[4] * xx[6];
  xx[12] = 0.5071702128332358;
  xx[13] = 0.9983507260015945;
  xx[14] = xx[13] * xx[10];
  xx[10] = xx[12] * xx[14];
  xx[15] = xx[8] + xx[11] - xx[10];
  xx[16] = - xx[15];
  xx[17] = xx[8] - xx[11] + xx[10];
  xx[8] = xx[12] * xx[7];
  xx[7] = xx[12] * xx[6];
  xx[6] = xx[4] * xx[14];
  xx[4] = xx[8] - xx[7] - xx[6];
  xx[10] = xx[6] + xx[8] + xx[7];
  xx[6] = - xx[10];
  xx[7] = 2.0;
  xx[18] = xx[17];
  xx[19] = xx[4];
  xx[20] = xx[6];
  xx[8] = 3.336781597632563e-3;
  xx[11] = xx[8] * xx[4];
  xx[12] = 0.106776414276248;
  xx[14] = xx[12] * xx[10] - xx[8] * xx[17];
  xx[21] = xx[12] * xx[4];
  xx[22] = xx[11];
  xx[23] = xx[14];
  xx[24] = xx[21];
  pm_math_cross3(xx + 18, xx + 22, xx + 25);
  xx[18] = - (0.07218312915134216 + xx[7] * (xx[25] - xx[11] * xx[15]) - xx[12]);
  xx[11] = - (5.225735315492718e-3 + xx[7] * (xx[26] - xx[14] * xx[15]));
  xx[12] = - (xx[8] + xx[7] * (xx[27] - xx[21] * xx[15]));
  xx[8] = 0.9995875964620595;
  xx[14] = xx[5] * state[4];
  xx[5] = cos(xx[14]);
  xx[19] = xx[8] * xx[5];
  xx[20] = 0.02871649350465279;
  xx[21] = sin(xx[14]);
  xx[14] = xx[20] * xx[21];
  xx[22] = xx[20] * xx[5];
  xx[5] = xx[8] * xx[21];
  xx[8] = 0.07478806191712499;
  xx[20] = xx[8] * xx[22];
  xx[21] = xx[8] * xx[5];
  xx[23] = 0.07407490243288437 - (xx[7] * (xx[22] * xx[20] + xx[5] * xx[21]) -
    xx[8]);
  xx[24] = xx[7] * (xx[19] * xx[21] + xx[14] * xx[20]);
  xx[25] = 0.01297012185805613 - xx[7] * (xx[19] * xx[20] - xx[14] * xx[21]);
  xx[26] = xx[0];
  xx[27] = xx[1];
  xx[28] = xx[0];
  xx[29] = xx[1];
  xx[30] = xx[16];
  xx[31] = xx[17];
  xx[32] = xx[4];
  xx[33] = xx[6];
  pm_math_quatCompose(xx + 26, xx + 30, xx + 34);
  xx[30] = xx[18];
  xx[31] = xx[11];
  xx[32] = xx[12];
  pm_math_quatXform(xx + 26, xx + 30, xx + 38);
  xx[20] = xx[38] + state[0];
  xx[26] = xx[19];
  xx[27] = xx[14];
  xx[28] = xx[22];
  xx[29] = xx[5];
  pm_math_quatCompose(xx + 34, xx + 26, xx + 30);
  pm_math_quatXform(xx + 34, xx + 23, xx + 41);
  xx[21] = 0.0;
  xx[38] = xx[9] * state[3];
  xx[9] = xx[13] * state[3];
  xx[13] = xx[4] * state[1];
  xx[44] = state[1] * xx[17];
  xx[45] = xx[7] * (xx[13] * xx[15] - xx[44] * xx[10]);
  xx[46] = 0.1067918730131247 * state[3] - xx[7] * (xx[44] * xx[15] + xx[13] *
    xx[10]);
  xx[10] = state[1] - xx[7] * (xx[44] * xx[17] + xx[13] * xx[4]);
  xx[47] = xx[14];
  xx[48] = xx[22];
  xx[49] = xx[5];
  xx[13] = xx[9] * xx[22];
  xx[15] = xx[5] * xx[38] - xx[9] * xx[14];
  xx[44] = xx[38] * xx[22];
  xx[50] = xx[13];
  xx[51] = xx[15];
  xx[52] = - xx[44];
  pm_math_cross3(xx + 47, xx + 50, xx + 53);
  xx[47] = xx[45] - xx[9] * xx[24];
  xx[48] = xx[9] * xx[23] - xx[38] * xx[25] + xx[46];
  xx[49] = xx[10] + xx[38] * xx[24];
  pm_math_quatInverseXform(xx + 26, xx + 47, xx + 50);
  motionData[0] = xx[0];
  motionData[1] = xx[1];
  motionData[2] = xx[0];
  motionData[3] = xx[1];
  motionData[4] = state[0];
  motionData[5] = - xx[2];
  motionData[6] = xx[3];
  motionData[7] = xx[16];
  motionData[8] = xx[17];
  motionData[9] = xx[4];
  motionData[10] = xx[6];
  motionData[11] = xx[18];
  motionData[12] = xx[11];
  motionData[13] = xx[12];
  motionData[14] = xx[19];
  motionData[15] = xx[14];
  motionData[16] = xx[22];
  motionData[17] = xx[5];
  motionData[18] = xx[23];
  motionData[19] = xx[24];
  motionData[20] = xx[25];
  motionData[21] = xx[34];
  motionData[22] = xx[35];
  motionData[23] = xx[36];
  motionData[24] = xx[37];
  motionData[25] = xx[20];
  motionData[26] = xx[39] - xx[2];
  motionData[27] = xx[40] + xx[3];
  motionData[28] = xx[30];
  motionData[29] = xx[31];
  motionData[30] = xx[32];
  motionData[31] = xx[33];
  motionData[32] = xx[41] + xx[20];
  motionData[33] = xx[42] + xx[39] - xx[2];
  motionData[34] = xx[43] + xx[40] + xx[3];
  motionData[35] = xx[21];
  motionData[36] = xx[21];
  motionData[37] = xx[21];
  motionData[38] = xx[21];
  motionData[39] = xx[21];
  motionData[40] = state[1];
  motionData[41] = xx[38];
  motionData[42] = xx[21];
  motionData[43] = xx[9];
  motionData[44] = xx[45];
  motionData[45] = xx[46];
  motionData[46] = xx[10];
  motionData[47] = xx[38] + xx[7] * (xx[53] - xx[19] * xx[13]);
  motionData[48] = xx[7] * (xx[54] - xx[19] * xx[15]);
  motionData[49] = xx[9] + xx[7] * (xx[19] * xx[44] + xx[55]) + state[5];
  motionData[50] = xx[50];
  motionData[51] = xx[51] + xx[8] * state[5];
  motionData[52] = xx[52];
}

size_t sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeAssemblyError(const
  void *mech, const double *rtdv, size_t constraintIdx, const double *state,
  const double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) state;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeAssemblyJacobian(
  const void *mech, const double *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const double *motionData, double
  *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_computeFullAssemblyJacobian
  (const void *mech, const double *rtdv, const double *state, const double
   *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) motionData;
  (void) J;
  return 0;
}

int sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_isInKinematicSingularity(const
  void *mech, const double *rtdv, size_t constraintIdx, const double *motionData)
{
  (void) mech;
  (void) rtdv
    ;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

PmfMessageId sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_convertStateVector(
  const void *asmMech, const double *rtdv, const void *simMech, const double
  *asmState, double *simState, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) asmMech;
  (void) rtdv;
  (void) simMech;
  (void) neDiagMgr;
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  simState[2] = asmState[2];
  simState[3] = asmState[3];
  simState[4] = asmState[4];
  simState[5] = asmState[5];
  return NULL;
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_constructStateVector(const
  void *mech, const double *solverState, const double *u, const double *uDot,
  double *discreteState, double *fullState)
{
  (void) mech;
  (void) u;
  (void) uDot;
  (void) discreteState;
  fullState[0] = solverState[0];
  fullState[1] = solverState[1];
  fullState[2] = solverState[2];
  fullState[3] = solverState[3];
  fullState[4] = solverState[4];
  fullState[5] = solverState[5];
}

void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_extractSolverStateVector(
  const void *mech, const double *fullState, double *solverState)
{
  (void) mech;
  solverState[0] = fullState[0];
  solverState[1] = fullState[1];
  solverState[2] = fullState[2];
  solverState[3] = fullState[3];
  solverState[4] = fullState[4];
  solverState[5] = fullState[5];
}

int sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_isPositionViolation(const void
  *mech, const double *rtdv, const int *eqnEnableFlags, const double *state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

int sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_isVelocityViolation(const void
  *mech, const double *rtdv, const int *eqnEnableFlags, const double *state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

PmfMessageId sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_projectStateSim(const
  void *mech, const double *rtdv, const int *eqnEnableFlags, const double *input,
  double *state, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) input;
  (void) state;
  (void) neDiagMgr;
  return NULL;
}
