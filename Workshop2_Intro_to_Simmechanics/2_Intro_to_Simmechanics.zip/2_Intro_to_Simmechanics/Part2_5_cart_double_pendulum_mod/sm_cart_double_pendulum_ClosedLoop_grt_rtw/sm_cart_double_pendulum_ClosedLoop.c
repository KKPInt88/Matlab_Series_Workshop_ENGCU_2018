/*
 * sm_cart_double_pendulum_ClosedLoop.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sm_cart_double_pendulum_ClosedLoop".
 *
 * Model version              : 1.704
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Wed Oct 24 19:10:23 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sm_cart_double_pendulum_ClosedLoop.h"
#include "sm_cart_double_pendulum_ClosedLoop_private.h"

/* Block signals (default storage) */
B_sm_cart_double_pendulum_Clo_T sm_cart_double_pendulum_Close_B;

/* Continuous states */
X_sm_cart_double_pendulum_Clo_T sm_cart_double_pendulum_Close_X;

/* Block states (default storage) */
DW_sm_cart_double_pendulum_Cl_T sm_cart_double_pendulum_Clos_DW;

/* External inputs (root inport signals with default storage) */
ExtU_sm_cart_double_pendulum__T sm_cart_double_pendulum_Close_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_sm_cart_double_pendulum__T sm_cart_double_pendulum_Close_Y;

/* Real-time model */
RT_MODEL_sm_cart_double_pendu_T sm_cart_double_pendulum_Clos_M_;
RT_MODEL_sm_cart_double_pendu_T *const sm_cart_double_pendulum_Clos_M =
  &sm_cart_double_pendulum_Clos_M_;

/* Projection for root system: '<Root>' */
void sm_cart_double_pendulum_ClosedLoop_projection(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[8];
  int_T tmp_1[3];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T tmp_2;
  char *msg;

  /* Projection for SimscapeExecutionBlock: '<S23>/STATE_1' */
  simulationData = (NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData;
  time = sm_cart_double_pendulum_Clos_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cart_double_pendulum_Close_X.sm_cart_double_pendulum_ClosedL;
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX = NULL;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (sm_cart_double_pendulum_Clos_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian
    (&sm_cart_double_pendulum_Clos_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  tmp_0[5] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1];
  tmp_0[6] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2];
  tmp_0[7] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3];
  tmp_1[2] = 8;
  simulationData->mData->mInputValues.mN = 8;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 3;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method((NeslSimulator *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
    }
  }

  /* End of Projection for SimscapeExecutionBlock: '<S23>/STATE_1' */
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 6;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  sm_cart_double_pendulum_ClosedLoop_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  sm_cart_double_pendulum_ClosedLoop_output();
  sm_cart_double_pendulum_ClosedLoop_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  sm_cart_double_pendulum_ClosedLoop_output();
  sm_cart_double_pendulum_ClosedLoop_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  sm_cart_double_pendulum_ClosedLoop_output();
  sm_cart_double_pendulum_ClosedLoop_projection();
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void sm_cart_double_pendulum_ClosedLoop_output(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[8];
  int_T tmp_1[3];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T i;
  char *msg;
  real_T time_0;
  real_T tmp_2[14];
  int_T tmp_3[4];
  real_T rtb_OUTPUT_1_0[6];
  real_T rtb_GAIN;
  real_T rtb_GAIN_d;
  real_T rtb_GAIN_ih;
  real_T rtb_GAIN_o;
  real_T rtb_GAIN_e;
  real_T rtb_GAIN_p;
  real_T rtb_GAIN_6[6];
  real_T tmp_4[6];
  int32_T i_0;
  real_T tmp_5;
  boolean_T tmp_6;
  if (rtmIsMajorTimeStep(sm_cart_double_pendulum_Clos_M)) {
    /* set solver stop time */
    if (!(sm_cart_double_pendulum_Clos_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&sm_cart_double_pendulum_Clos_M->solverInfo,
                            ((sm_cart_double_pendulum_Clos_M->Timing.clockTickH0
        + 1) * sm_cart_double_pendulum_Clos_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&sm_cart_double_pendulum_Clos_M->solverInfo,
                            ((sm_cart_double_pendulum_Clos_M->Timing.clockTick0
        + 1) * sm_cart_double_pendulum_Clos_M->Timing.stepSize0 +
        sm_cart_double_pendulum_Clos_M->Timing.clockTickH0 *
        sm_cart_double_pendulum_Clos_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(sm_cart_double_pendulum_Clos_M)) {
    sm_cart_double_pendulum_Clos_M->Timing.t[0] = rtsiGetT
      (&sm_cart_double_pendulum_Clos_M->solverInfo);
  }

  /* SimscapeExecutionBlock: '<S23>/STATE_1' incorporates:
   *  SimscapeExecutionBlock: '<S23>/OUTPUT_1_0'
   */
  simulationData = (NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData;
  time = sm_cart_double_pendulum_Clos_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cart_double_pendulum_Close_X.sm_cart_double_pendulum_ClosedL;
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX = NULL;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  tmp_6 = rtmIsMajorTimeStep(sm_cart_double_pendulum_Clos_M);
  simulationData->mData->mIsMajorTimeStep = tmp_6;
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian
    (&sm_cart_double_pendulum_Clos_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  tmp_0[5] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1];
  tmp_0[6] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2];
  tmp_0[7] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3];
  tmp_1[2] = 8;
  simulationData->mData->mInputValues.mN = 8;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 3;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mOutputs.mN = 6;
  simulationData->mData->mOutputs.mX = &sm_cart_double_pendulum_Close_B.STATE_1
    [0];
  simulationData->mData->mSampleHits.mN = 0;
  simulationData->mData->mSampleHits.mX = NULL;
  simulationData->mData->mIsFundamentalSampleHit = false;
  simulationData->mData->mTolerances.mN = 0;
  simulationData->mData->mTolerances.mX = NULL;
  simulationData->mData->mCstateHasChanged = false;
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  i = ne_simulator_method((NeslSimulator *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, NESL_SIM_OUTPUTS,
    simulationData, diagnosticManager);
  if (i != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
    }
  }

  /* End of SimscapeExecutionBlock: '<S23>/STATE_1' */

  /* SimscapeExecutionBlock: '<S23>/OUTPUT_1_0' */
  simulationData = (NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_SimulationData;
  time_0 = sm_cart_double_pendulum_Clos_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_0;
  simulationData->mData->mContStates.mN = 0;
  simulationData->mData->mContStates.mX = NULL;
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX = NULL;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = tmp_6;
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  simulationData->mData->mIsComputingJacobian = false;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_3[0] = 0;
  tmp_2[0] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0];
  tmp_2[1] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1];
  tmp_2[2] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2];
  tmp_2[3] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3];
  tmp_3[1] = 4;
  tmp_2[4] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  tmp_2[5] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1];
  tmp_2[6] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2];
  tmp_2[7] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3];
  tmp_3[2] = 8;
  tmp_2[8] = sm_cart_double_pendulum_Close_B.STATE_1[0];
  tmp_2[9] = sm_cart_double_pendulum_Close_B.STATE_1[1];
  tmp_2[10] = sm_cart_double_pendulum_Close_B.STATE_1[2];
  tmp_2[11] = sm_cart_double_pendulum_Close_B.STATE_1[3];
  tmp_2[12] = sm_cart_double_pendulum_Close_B.STATE_1[4];
  tmp_2[13] = sm_cart_double_pendulum_Close_B.STATE_1[5];
  tmp_3[3] = 14;
  simulationData->mData->mInputValues.mN = 14;
  simulationData->mData->mInputValues.mX = &tmp_2[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_3[0];
  simulationData->mData->mOutputs.mN = 6;
  simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0[0];
  simulationData->mData->mSampleHits.mN = 0;
  simulationData->mData->mSampleHits.mX = NULL;
  simulationData->mData->mIsFundamentalSampleHit = false;
  simulationData->mData->mTolerances.mN = 0;
  simulationData->mData->mTolerances.mX = NULL;
  simulationData->mData->mCstateHasChanged = false;
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  i = ne_simulator_method((NeslSimulator *)
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator, NESL_SIM_OUTPUTS,
    simulationData, diagnosticManager);
  if (i != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
    }
  }

  /* Gain: '<S19>/GAIN' */
  rtb_GAIN = 100.0 * rtb_OUTPUT_1_0[0];

  /* Outport: '<Root>/p' */
  sm_cart_double_pendulum_Close_Y.p = rtb_GAIN;

  /* Gain: '<S20>/GAIN' */
  rtb_GAIN_d = 100.0 * rtb_OUTPUT_1_0[1];

  /* Outport: '<Root>/v' */
  sm_cart_double_pendulum_Close_Y.v = rtb_GAIN_d;

  /* Gain: '<S17>/GAIN' */
  rtb_GAIN_ih = 57.295779513082323 * rtb_OUTPUT_1_0[2];

  /* Outport: '<Root>/q1' */
  sm_cart_double_pendulum_Close_Y.q1 = rtb_GAIN_ih;

  /* Gain: '<S18>/GAIN' */
  rtb_GAIN_o = 57.295779513082323 * rtb_OUTPUT_1_0[3];

  /* Outport: '<Root>/w1' */
  sm_cart_double_pendulum_Close_Y.w1 = rtb_GAIN_o;

  /* Gain: '<S15>/GAIN' */
  rtb_GAIN_e = 57.295779513082323 * rtb_OUTPUT_1_0[4];

  /* Outport: '<Root>/q2' */
  sm_cart_double_pendulum_Close_Y.q2 = rtb_GAIN_e;

  /* Gain: '<S16>/GAIN' */
  rtb_GAIN_p = 57.295779513082323 * rtb_OUTPUT_1_0[5];

  /* Outport: '<Root>/w2' */
  sm_cart_double_pendulum_Close_Y.w2 = rtb_GAIN_p;

  /* ManualSwitch: '<Root>/Manual Switch' incorporates:
   *  Gain: '<Root>/Gain'
   *  Inport: '<Root>/f'
   */
  if (((uint8_T)0U) == 1) {
    sm_cart_double_pendulum_Close_B.ManualSwitch =
      sm_cart_double_pendulum_Close_U.f;
  } else {
    /* SignalConversion: '<Root>/TmpSignal ConversionAtGain3Inport1' */
    rtb_GAIN_6[0] = rtb_GAIN;
    rtb_GAIN_6[1] = rtb_GAIN_d;
    rtb_GAIN_6[2] = rtb_GAIN_ih;
    rtb_GAIN_6[3] = rtb_GAIN_o;
    rtb_GAIN_6[4] = rtb_GAIN_e;
    rtb_GAIN_6[5] = rtb_GAIN_p;

    /* Gain: '<Root>/Gain' */
    tmp_5 = 0.0;
    for (i = 0; i < 6; i++) {
      /* Gain: '<Root>/Gain3' incorporates:
       *  Gain: '<Root>/Gain'
       */
      tmp_4[i] = 0.0;
      for (i_0 = 0; i_0 < 6; i_0++) {
        tmp_4[i] += sm_cart_double_pendulum__ConstP.Gain3_Gain[6 * i_0 + i] *
          rtb_GAIN_6[i_0];
      }

      /* End of Gain: '<Root>/Gain3' */

      /* Gain: '<Root>/Gain' */
      tmp_5 += sm_cart_double_pendulum__ConstP.Gain_Gain[i] * tmp_4[i];
    }

    sm_cart_double_pendulum_Close_B.ManualSwitch = tmp_5;
  }

  /* End of ManualSwitch: '<Root>/Manual Switch' */

  /* SimscapeInputBlock: '<S23>/INPUT_1_1_1' */
  sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0] =
    sm_cart_double_pendulum_Close_B.ManualSwitch;
  sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1] = 0.0;
  sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2] = 0.0;
  sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3] = 0.0;

  /* SimscapeInputBlock: '<S23>/INPUT_2_1_1' */
  sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0] = 0.0;
  sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1] = 0.0;
  sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2] = 0.0;
  if (rtmIsMajorTimeStep(sm_cart_double_pendulum_Clos_M)) {
    sm_cart_double_pendulum_Clos_DW.INPUT_2_1_1_discrete[0] =
      !(sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0] ==
        sm_cart_double_pendulum_Clos_DW.INPUT_2_1_1_discrete[1]);
    sm_cart_double_pendulum_Clos_DW.INPUT_2_1_1_discrete[1] =
      sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  }

  sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0] =
    sm_cart_double_pendulum_Clos_DW.INPUT_2_1_1_discrete[1];
  sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3] =
    sm_cart_double_pendulum_Clos_DW.INPUT_2_1_1_discrete[0];

  /* End of SimscapeInputBlock: '<S23>/INPUT_2_1_1' */
}

/* Model update function */
void sm_cart_double_pendulum_ClosedLoop_update(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[8];
  int_T tmp_1[3];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T tmp_2;
  char *msg;

  /* Update for SimscapeExecutionBlock: '<S23>/STATE_1' */
  simulationData = (NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData;
  time = sm_cart_double_pendulum_Clos_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cart_double_pendulum_Close_X.sm_cart_double_pendulum_ClosedL;
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX = NULL;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (sm_cart_double_pendulum_Clos_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian
    (&sm_cart_double_pendulum_Clos_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  tmp_0[5] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1];
  tmp_0[6] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2];
  tmp_0[7] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3];
  tmp_1[2] = 8;
  simulationData->mData->mInputValues.mN = 8;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 3;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method((NeslSimulator *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, NESL_SIM_UPDATE,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
    }
  }

  /* End of Update for SimscapeExecutionBlock: '<S23>/STATE_1' */
  if (rtmIsMajorTimeStep(sm_cart_double_pendulum_Clos_M)) {
    rt_ertODEUpdateContinuousStates(&sm_cart_double_pendulum_Clos_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++sm_cart_double_pendulum_Clos_M->Timing.clockTick0)) {
    ++sm_cart_double_pendulum_Clos_M->Timing.clockTickH0;
  }

  sm_cart_double_pendulum_Clos_M->Timing.t[0] = rtsiGetSolverStopTime
    (&sm_cart_double_pendulum_Clos_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++sm_cart_double_pendulum_Clos_M->Timing.clockTick1)) {
      ++sm_cart_double_pendulum_Clos_M->Timing.clockTickH1;
    }

    sm_cart_double_pendulum_Clos_M->Timing.t[1] =
      sm_cart_double_pendulum_Clos_M->Timing.clockTick1 *
      sm_cart_double_pendulum_Clos_M->Timing.stepSize1 +
      sm_cart_double_pendulum_Clos_M->Timing.clockTickH1 *
      sm_cart_double_pendulum_Clos_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void sm_cart_double_pendulum_ClosedLoop_derivatives(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[8];
  int_T tmp_1[3];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T tmp_2;
  char *msg;
  XDot_sm_cart_double_pendulum__T *_rtXdot;
  _rtXdot = ((XDot_sm_cart_double_pendulum__T *)
             sm_cart_double_pendulum_Clos_M->derivs);

  /* Derivatives for SimscapeExecutionBlock: '<S23>/STATE_1' */
  simulationData = (NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData;
  time = sm_cart_double_pendulum_Clos_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cart_double_pendulum_Close_X.sm_cart_double_pendulum_ClosedL;
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX = NULL;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (sm_cart_double_pendulum_Clos_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian
    (&sm_cart_double_pendulum_Clos_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cart_double_pendulum_Close_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[0];
  tmp_0[5] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[1];
  tmp_0[6] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[2];
  tmp_0[7] = sm_cart_double_pendulum_Close_B.INPUT_2_1_1[3];
  tmp_1[2] = 8;
  simulationData->mData->mInputValues.mN = 8;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 3;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 6;
  simulationData->mData->mDx.mX = (real_T *)
    &_rtXdot->sm_cart_double_pendulum_ClosedL;
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method((NeslSimulator *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
    }
  }

  /* End of Derivatives for SimscapeExecutionBlock: '<S23>/STATE_1' */
}

/* Model initialize function */
void sm_cart_double_pendulum_ClosedLoop_initialize(void)
{
  {
    NeslSimulator *tmp;
    boolean_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeModelParameters modelParameters;
    real_T tmp_1;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;
    NeslSimulationData *simulationData;
    real_T time;
    NeModelParameters modelParameters_0;
    real_T time_0;
    NeParameterBundle expl_temp;
    boolean_T tmp_3;

    /* Start for SimscapeExecutionBlock: '<S23>/STATE_1' incorporates:
     *  SimscapeExecutionBlock: '<S23>/OUTPUT_1_0'
     */
    tmp = nesl_lease_simulator(
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1", 0,
      0);
    sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator);
    if (tmp_0) {
      sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_gateway();
      tmp = nesl_lease_simulator(
        "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1",
        0, 0);
      sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData = (void *)
      simulationData;
    diagnosticManager = rtw_create_diagnostics();
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager = (void *)
      diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverTolerance = 1.0E-6;
    modelParameters.mVariableStepSolver = false;
    modelParameters.mFixedStepSize = 0.001;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters.mRTWModifiedTimeStamp = 4.62308682E+8;
    tmp_1 = 0.001;
    modelParameters.mSolverTolerance = tmp_1;
    tmp_1 = 0.001;
    modelParameters.mFixedStepSize = tmp_1;
    tmp_0 = false;
    modelParameters.mVariableStepSolver = tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, &modelParameters,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (sm_cart_double_pendulum_Clos_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
      }
    }

    expl_temp.mRealParameters.mN = 0;
    expl_temp.mRealParameters.mX = NULL;
    expl_temp.mLogicalParameters.mN = 0;
    expl_temp.mLogicalParameters.mX = NULL;
    expl_temp.mIntegerParameters.mN = 0;
    expl_temp.mIntegerParameters.mX = NULL;
    expl_temp.mIndexParameters.mN = 0;
    expl_temp.mIndexParameters.mX = NULL;
    nesl_simulator_set_rtps((NeslSimulator *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, expl_temp);
    simulationData = (NeslSimulationData *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData;
    time = sm_cart_double_pendulum_Clos_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 6;
    simulationData->mData->mContStates.mX = (real_T *)
      &sm_cart_double_pendulum_Close_X.sm_cart_double_pendulum_ClosedL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = NULL;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp_0 = false;
    simulationData->mData->mFoundZcEvents = tmp_0;
    tmp_3 = rtmIsMajorTimeStep(sm_cart_double_pendulum_Clos_M);
    simulationData->mData->mIsMajorTimeStep = tmp_3;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_0 = rtsiIsSolverComputingJacobian
      (&sm_cart_double_pendulum_Clos_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_0;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      sm_cart_double_pendulum_Clos_DW.STATE_1_Simulator, NESL_SIM_INITIALIZEONCE,
      simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (sm_cart_double_pendulum_Clos_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S23>/STATE_1' */

    /* Start for SimscapeExecutionBlock: '<S23>/OUTPUT_1_0' */
    tmp = nesl_lease_simulator(
      "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1", 2,
      0);
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator);
    if (tmp_0) {
      sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_gateway();
      tmp = nesl_lease_simulator(
        "sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1",
        2, 0);
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_SimulationData = (void *)
      simulationData;
    diagnosticManager = rtw_create_diagnostics();
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_DiagnosticManager = (void *)
      diagnosticManager;
    modelParameters_0.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_0.mSolverTolerance = 1.0E-6;
    modelParameters_0.mVariableStepSolver = false;
    modelParameters_0.mFixedStepSize = 0.001;
    modelParameters_0.mStartTime = 0.0;
    modelParameters_0.mLoadInitialState = false;
    modelParameters_0.mUseSimState = false;
    modelParameters_0.mLinTrimCompile = false;
    modelParameters_0.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters_0.mRTWModifiedTimeStamp = 4.62308682E+8;
    tmp_1 = 0.001;
    modelParameters_0.mSolverTolerance = tmp_1;
    tmp_1 = 0.001;
    modelParameters_0.mFixedStepSize = tmp_1;
    tmp_0 = false;
    modelParameters_0.mVariableStepSolver = tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator, &modelParameters_0,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (sm_cart_double_pendulum_Clos_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
      }
    }

    simulationData = (NeslSimulationData *)
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_SimulationData;
    time_0 = sm_cart_double_pendulum_Clos_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = NULL;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp_0 = false;
    simulationData->mData->mFoundZcEvents = tmp_0;
    simulationData->mData->mIsMajorTimeStep = tmp_3;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_Simulator,
      NESL_SIM_INITIALIZEONCE, simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (sm_cart_double_pendulum_Clos_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, msg);
      }
    }
  }

  {
    boolean_T tmp;
    int_T tmp_0;
    char *tmp_1;

    /* InitializeConditions for SimscapeExecutionBlock: '<S23>/STATE_1' */
    tmp = false;
    if (tmp) {
      tmp_0 = strcmp("ode3", rtsiGetSolverName
                     (&sm_cart_double_pendulum_Clos_M->solverInfo));
      if (tmp_0 != 0) {
        tmp_1 = solver_mismatch_message("ode3", rtsiGetSolverName
          (&sm_cart_double_pendulum_Clos_M->solverInfo));
        rtmSetErrorStatus(sm_cart_double_pendulum_Clos_M, tmp_1);
      }
    }

    /* End of InitializeConditions for SimscapeExecutionBlock: '<S23>/STATE_1' */
  }
}

/* Model terminate function */
void sm_cart_double_pendulum_ClosedLoop_terminate(void)
{
  /* Terminate for SimscapeExecutionBlock: '<S23>/STATE_1' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_DiagnosticManager);
  nesl_destroy_simulation_data((NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.STATE_1_SimulationData);
  nesl_erase_simulator("sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1");

  /* Terminate for SimscapeExecutionBlock: '<S23>/OUTPUT_1_0' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_DiagnosticManager);
  nesl_destroy_simulation_data((NeslSimulationData *)
    sm_cart_double_pendulum_Clos_DW.OUTPUT_1_0_SimulationData);
  nesl_erase_simulator("sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver_1");
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  sm_cart_double_pendulum_ClosedLoop_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  sm_cart_double_pendulum_ClosedLoop_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  sm_cart_double_pendulum_ClosedLoop_initialize();
}

void MdlTerminate(void)
{
  sm_cart_double_pendulum_ClosedLoop_terminate();
}

/* Registration function */
RT_MODEL_sm_cart_double_pendu_T *sm_cart_double_pendulum_ClosedLoop(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)sm_cart_double_pendulum_Clos_M, 0,
                sizeof(RT_MODEL_sm_cart_double_pendu_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
                          &sm_cart_double_pendulum_Clos_M->Timing.simTimeStep);
    rtsiSetTPtr(&sm_cart_double_pendulum_Clos_M->solverInfo, &rtmGetTPtr
                (sm_cart_double_pendulum_Clos_M));
    rtsiSetStepSizePtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
                       &sm_cart_double_pendulum_Clos_M->Timing.stepSize0);
    rtsiSetdXPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
                 &sm_cart_double_pendulum_Clos_M->derivs);
    rtsiSetContStatesPtr(&sm_cart_double_pendulum_Clos_M->solverInfo, (real_T **)
                         &sm_cart_double_pendulum_Clos_M->contStates);
    rtsiSetNumContStatesPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
      &sm_cart_double_pendulum_Clos_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
      &sm_cart_double_pendulum_Clos_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&sm_cart_double_pendulum_Clos_M->solverInfo,
       &sm_cart_double_pendulum_Clos_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&sm_cart_double_pendulum_Clos_M->solverInfo,
       &sm_cart_double_pendulum_Clos_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
                          (&rtmGetErrorStatus(sm_cart_double_pendulum_Clos_M)));
    rtsiSetRTModelPtr(&sm_cart_double_pendulum_Clos_M->solverInfo,
                      sm_cart_double_pendulum_Clos_M);
  }

  rtsiSetSimTimeStep(&sm_cart_double_pendulum_Clos_M->solverInfo,
                     MAJOR_TIME_STEP);
  sm_cart_double_pendulum_Clos_M->intgData.y =
    sm_cart_double_pendulum_Clos_M->odeY;
  sm_cart_double_pendulum_Clos_M->intgData.f[0] =
    sm_cart_double_pendulum_Clos_M->odeF[0];
  sm_cart_double_pendulum_Clos_M->intgData.f[1] =
    sm_cart_double_pendulum_Clos_M->odeF[1];
  sm_cart_double_pendulum_Clos_M->intgData.f[2] =
    sm_cart_double_pendulum_Clos_M->odeF[2];
  sm_cart_double_pendulum_Clos_M->contStates = ((real_T *)
    &sm_cart_double_pendulum_Close_X);
  rtsiSetSolverData(&sm_cart_double_pendulum_Clos_M->solverInfo, (void *)
                    &sm_cart_double_pendulum_Clos_M->intgData);
  rtsiSetSolverName(&sm_cart_double_pendulum_Clos_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      sm_cart_double_pendulum_Clos_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    sm_cart_double_pendulum_Clos_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    sm_cart_double_pendulum_Clos_M->Timing.sampleTimes =
      (&sm_cart_double_pendulum_Clos_M->Timing.sampleTimesArray[0]);
    sm_cart_double_pendulum_Clos_M->Timing.offsetTimes =
      (&sm_cart_double_pendulum_Clos_M->Timing.offsetTimesArray[0]);

    /* task periods */
    sm_cart_double_pendulum_Clos_M->Timing.sampleTimes[0] = (0.0);
    sm_cart_double_pendulum_Clos_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    sm_cart_double_pendulum_Clos_M->Timing.offsetTimes[0] = (0.0);
    sm_cart_double_pendulum_Clos_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(sm_cart_double_pendulum_Clos_M,
             &sm_cart_double_pendulum_Clos_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = sm_cart_double_pendulum_Clos_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    sm_cart_double_pendulum_Clos_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(sm_cart_double_pendulum_Clos_M, 10.0);
  sm_cart_double_pendulum_Clos_M->Timing.stepSize0 = 0.001;
  sm_cart_double_pendulum_Clos_M->Timing.stepSize1 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    sm_cart_double_pendulum_Clos_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(sm_cart_double_pendulum_Clos_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(sm_cart_double_pendulum_Clos_M->rtwLogInfo, (NULL));
    rtliSetLogT(sm_cart_double_pendulum_Clos_M->rtwLogInfo, "");
    rtliSetLogX(sm_cart_double_pendulum_Clos_M->rtwLogInfo, "");
    rtliSetLogXFinal(sm_cart_double_pendulum_Clos_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(sm_cart_double_pendulum_Clos_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(sm_cart_double_pendulum_Clos_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(sm_cart_double_pendulum_Clos_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(sm_cart_double_pendulum_Clos_M->rtwLogInfo, 1);
    rtliSetLogY(sm_cart_double_pendulum_Clos_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(sm_cart_double_pendulum_Clos_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(sm_cart_double_pendulum_Clos_M->rtwLogInfo, (NULL));
  }

  sm_cart_double_pendulum_Clos_M->solverInfoPtr =
    (&sm_cart_double_pendulum_Clos_M->solverInfo);
  sm_cart_double_pendulum_Clos_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&sm_cart_double_pendulum_Clos_M->solverInfo, 0.001);
  rtsiSetSolverMode(&sm_cart_double_pendulum_Clos_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  sm_cart_double_pendulum_Clos_M->blockIO = ((void *)
    &sm_cart_double_pendulum_Close_B);
  (void) memset(((void *) &sm_cart_double_pendulum_Close_B), 0,
                sizeof(B_sm_cart_double_pendulum_Clo_T));

  /* states (continuous) */
  {
    real_T *x = (real_T *) &sm_cart_double_pendulum_Close_X;
    sm_cart_double_pendulum_Clos_M->contStates = (x);
    (void) memset((void *)&sm_cart_double_pendulum_Close_X, 0,
                  sizeof(X_sm_cart_double_pendulum_Clo_T));
  }

  /* states (dwork) */
  sm_cart_double_pendulum_Clos_M->dwork = ((void *)
    &sm_cart_double_pendulum_Clos_DW);
  (void) memset((void *)&sm_cart_double_pendulum_Clos_DW, 0,
                sizeof(DW_sm_cart_double_pendulum_Cl_T));

  /* external inputs */
  sm_cart_double_pendulum_Clos_M->inputs = (((void*)
    &sm_cart_double_pendulum_Close_U));
  sm_cart_double_pendulum_Close_U.f = 0.0;

  /* external outputs */
  sm_cart_double_pendulum_Clos_M->outputs = (&sm_cart_double_pendulum_Close_Y);
  (void) memset((void *)&sm_cart_double_pendulum_Close_Y, 0,
                sizeof(ExtY_sm_cart_double_pendulum__T));

  /* Initialize Sizes */
  sm_cart_double_pendulum_Clos_M->Sizes.numContStates = (6);/* Number of continuous states */
  sm_cart_double_pendulum_Clos_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  sm_cart_double_pendulum_Clos_M->Sizes.numY = (6);/* Number of model outputs */
  sm_cart_double_pendulum_Clos_M->Sizes.numU = (1);/* Number of model inputs */
  sm_cart_double_pendulum_Clos_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  sm_cart_double_pendulum_Clos_M->Sizes.numSampTimes = (2);/* Number of sample times */
  sm_cart_double_pendulum_Clos_M->Sizes.numBlocks = (61);/* Number of blocks */
  sm_cart_double_pendulum_Clos_M->Sizes.numBlockIO = (4);/* Number of block outputs */
  return sm_cart_double_pendulum_Clos_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
