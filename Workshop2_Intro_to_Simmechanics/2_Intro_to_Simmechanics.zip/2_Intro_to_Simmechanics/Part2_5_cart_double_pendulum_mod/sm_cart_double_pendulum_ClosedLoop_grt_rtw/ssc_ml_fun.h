/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#ifdef __cplusplus

extern "C" {

#endif

#ifndef SSC_ML_FUN_H
#define SSC_ML_FUN_H                   1
#endif

#ifdef __cplusplus

};

#endif
