/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cart_double_pendulum_ClosedLoop/Cart and Double Pendulum/Solver'.
 */

#ifndef __sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_h__
#define __sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void sm_cart_double_pendulum_ClosedLoop_8d3ba676_1_dae( NeDae **dae,
    const NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}
#endif
#endif
