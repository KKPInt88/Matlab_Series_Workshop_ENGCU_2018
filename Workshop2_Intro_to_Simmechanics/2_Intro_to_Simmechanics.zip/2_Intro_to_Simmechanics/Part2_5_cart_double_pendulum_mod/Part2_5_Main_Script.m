%% Part 2.5 Simmechanics + Control 

clc;
close all;
clear all;

fs = 1000;
Ts = 1/fs;  % Sampling Time


%% Obtain Linearize Model

mdl = 'sm_cart_double_pendulum_model';


% Get full state corresponding to operating point
% [~,X,~] = sim(mdl,0); 
% [time, states, outputs] = sim(...)

% Linearizing about inverted upright position
% [A0, B0, C0, D0] = linmod(mdl, X, 0);
[A0, B0, C0, D0] = linmod(mdl);

% Removing the discrete states from the state space model
A = A0(1:6,1:6);
B = B0(1:6,:);
C = C0(:,1:6);
D = D0;
% 
sys = ss(A, B, C, D);

sys_modal = canon(sys, 'modal');
A_modal = sys_modal.a; 
B_modal = sys_modal.b;
C_modal = sys_modal.c;
D_modal = sys_modal.d;





%% Utilize Linear Quadratic Regulator (LQR) Controller

Q = 10^-2*C_modal'*C_modal;
R = 10^-2*diag([1]);
N = [];

[Kx, S, Eigen_Value] = lqr(sys_modal, Q, R, N); % **********

sys_cl = ss(A_modal-B_modal*Kx, B_modal, C_modal, D_modal);
step(sys_cl);

% 
% sys_cl = ss(A-B*Kx, [], C, D)


%% Test Closed Loop Controller

open('sm_cart_double_pendulum_ClosedLoop.slx');

sim('sm_cart_double_pendulum_ClosedLoop.slx');









