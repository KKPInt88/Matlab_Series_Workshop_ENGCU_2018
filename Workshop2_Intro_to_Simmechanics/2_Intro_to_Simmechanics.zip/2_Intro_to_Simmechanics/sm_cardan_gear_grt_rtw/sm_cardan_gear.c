/*
 * sm_cardan_gear.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sm_cardan_gear".
 *
 * Model version              : 1.165
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Wed Oct 24 10:35:06 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sm_cardan_gear.h"
#include "sm_cardan_gear_private.h"

/* Block signals (default storage) */
B_sm_cardan_gear_T sm_cardan_gear_B;

/* Continuous states */
X_sm_cardan_gear_T sm_cardan_gear_X;

/* Block states (default storage) */
DW_sm_cardan_gear_T sm_cardan_gear_DW;

/* Real-time model */
RT_MODEL_sm_cardan_gear_T sm_cardan_gear_M_;
RT_MODEL_sm_cardan_gear_T *const sm_cardan_gear_M = &sm_cardan_gear_M_;

/* Projection for root system: '<Root>' */
void sm_cardan_gear_projection(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[4];
  int_T tmp_1[2];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T tmp_2;
  char *msg;

  /* Projection for SimscapeExecutionBlock: '<S9>/STATE_1' */
  simulationData = (NeslSimulationData *)
    sm_cardan_gear_DW.STATE_1_SimulationData;
  time = sm_cardan_gear_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 10;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cardan_gear_X.sm_cardan_gearSun_JointRzq;
  simulationData->mData->mDiscStates.mN = 2;
  simulationData->mData->mDiscStates.mX = (real_T *)
    &sm_cardan_gear_DW.STATE_1_DiscStates;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(sm_cardan_gear_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(&sm_cardan_gear_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cardan_gear_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cardan_gear_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cardan_gear_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cardan_gear_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  simulationData->mData->mInputValues.mN = 4;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 2;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cardan_gear_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method((NeslSimulator *)
    sm_cardan_gear_DW.STATE_1_Simulator, NESL_SIM_PROJECTION, simulationData,
    diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cardan_gear_M, msg);
    }
  }

  /* End of Projection for SimscapeExecutionBlock: '<S9>/STATE_1' */
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 10;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  sm_cardan_gear_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  sm_cardan_gear_step();
  sm_cardan_gear_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  sm_cardan_gear_step();
  sm_cardan_gear_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  sm_cardan_gear_step();
  sm_cardan_gear_projection();
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void sm_cardan_gear_step(void)
{
  if (rtmIsMajorTimeStep(sm_cardan_gear_M)) {
    /* set solver stop time */
    if (!(sm_cardan_gear_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&sm_cardan_gear_M->solverInfo,
                            ((sm_cardan_gear_M->Timing.clockTickH0 + 1) *
        sm_cardan_gear_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&sm_cardan_gear_M->solverInfo,
                            ((sm_cardan_gear_M->Timing.clockTick0 + 1) *
        sm_cardan_gear_M->Timing.stepSize0 +
        sm_cardan_gear_M->Timing.clockTickH0 *
        sm_cardan_gear_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(sm_cardan_gear_M)) {
    sm_cardan_gear_M->Timing.t[0] = rtsiGetT(&sm_cardan_gear_M->solverInfo);
  }

  {
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp;
    real_T tmp_0[4];
    int_T tmp_1[2];
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;

    /* SimscapeInputBlock: '<S9>/INPUT_1_1_1' incorporates:
     *  Constant: '<Root>/Torque'
     */
    sm_cardan_gear_B.INPUT_1_1_1[0] = sm_cardan_gear_P.Torque_Value;
    sm_cardan_gear_B.INPUT_1_1_1[1] = 0.0;
    sm_cardan_gear_B.INPUT_1_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(sm_cardan_gear_M)) {
      sm_cardan_gear_DW.INPUT_1_1_1_discrete[0] =
        !(sm_cardan_gear_B.INPUT_1_1_1[0] ==
          sm_cardan_gear_DW.INPUT_1_1_1_discrete[1]);
      sm_cardan_gear_DW.INPUT_1_1_1_discrete[1] = sm_cardan_gear_B.INPUT_1_1_1[0];
    }

    sm_cardan_gear_B.INPUT_1_1_1[0] = sm_cardan_gear_DW.INPUT_1_1_1_discrete[1];
    sm_cardan_gear_B.INPUT_1_1_1[3] = sm_cardan_gear_DW.INPUT_1_1_1_discrete[0];

    /* End of SimscapeInputBlock: '<S9>/INPUT_1_1_1' */

    /* SimscapeExecutionBlock: '<S9>/STATE_1' */
    simulationData = (NeslSimulationData *)
      sm_cardan_gear_DW.STATE_1_SimulationData;
    time = sm_cardan_gear_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 10;
    simulationData->mData->mContStates.mX = (real_T *)
      &sm_cardan_gear_X.sm_cardan_gearSun_JointRzq;
    simulationData->mData->mDiscStates.mN = 2;
    simulationData->mData->mDiscStates.mX = (real_T *)
      &sm_cardan_gear_DW.STATE_1_DiscStates;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (sm_cardan_gear_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(&sm_cardan_gear_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_1[0] = 0;
    tmp_0[0] = sm_cardan_gear_B.INPUT_1_1_1[0];
    tmp_0[1] = sm_cardan_gear_B.INPUT_1_1_1[1];
    tmp_0[2] = sm_cardan_gear_B.INPUT_1_1_1[2];
    tmp_0[3] = sm_cardan_gear_B.INPUT_1_1_1[3];
    tmp_1[1] = 4;
    simulationData->mData->mInputValues.mN = 4;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 2;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    simulationData->mData->mOutputs.mN = 12;
    simulationData->mData->mOutputs.mX = &sm_cardan_gear_B.STATE_1[0];
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cardan_gear_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      sm_cardan_gear_DW.STATE_1_Simulator, NESL_SIM_OUTPUTS, simulationData,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cardan_gear_M, msg);
      }
    }

    /* End of SimscapeExecutionBlock: '<S9>/STATE_1' */
  }

  if (rtmIsMajorTimeStep(sm_cardan_gear_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(sm_cardan_gear_M->rtwLogInfo,
                        (sm_cardan_gear_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(sm_cardan_gear_M)) {
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp;
    real_T tmp_0[4];
    int_T tmp_1[2];
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;

    /* Update for SimscapeExecutionBlock: '<S9>/STATE_1' */
    simulationData = (NeslSimulationData *)
      sm_cardan_gear_DW.STATE_1_SimulationData;
    time = sm_cardan_gear_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 10;
    simulationData->mData->mContStates.mX = (real_T *)
      &sm_cardan_gear_X.sm_cardan_gearSun_JointRzq;
    simulationData->mData->mDiscStates.mN = 2;
    simulationData->mData->mDiscStates.mX = (real_T *)
      &sm_cardan_gear_DW.STATE_1_DiscStates;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (sm_cardan_gear_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(&sm_cardan_gear_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_1[0] = 0;
    tmp_0[0] = sm_cardan_gear_B.INPUT_1_1_1[0];
    tmp_0[1] = sm_cardan_gear_B.INPUT_1_1_1[1];
    tmp_0[2] = sm_cardan_gear_B.INPUT_1_1_1[2];
    tmp_0[3] = sm_cardan_gear_B.INPUT_1_1_1[3];
    tmp_1[1] = 4;
    simulationData->mData->mInputValues.mN = 4;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 2;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cardan_gear_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      sm_cardan_gear_DW.STATE_1_Simulator, NESL_SIM_UPDATE, simulationData,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cardan_gear_M, msg);
      }
    }

    /* End of Update for SimscapeExecutionBlock: '<S9>/STATE_1' */
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(sm_cardan_gear_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(sm_cardan_gear_M)!=-1) &&
          !((rtmGetTFinal(sm_cardan_gear_M)-
             (((sm_cardan_gear_M->Timing.clockTick1+
                sm_cardan_gear_M->Timing.clockTickH1* 4294967296.0)) * 0.2)) >
            (((sm_cardan_gear_M->Timing.clockTick1+
               sm_cardan_gear_M->Timing.clockTickH1* 4294967296.0)) * 0.2) *
            (DBL_EPSILON))) {
        rtmSetErrorStatus(sm_cardan_gear_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&sm_cardan_gear_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++sm_cardan_gear_M->Timing.clockTick0)) {
      ++sm_cardan_gear_M->Timing.clockTickH0;
    }

    sm_cardan_gear_M->Timing.t[0] = rtsiGetSolverStopTime
      (&sm_cardan_gear_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.2s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.2, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      sm_cardan_gear_M->Timing.clockTick1++;
      if (!sm_cardan_gear_M->Timing.clockTick1) {
        sm_cardan_gear_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void sm_cardan_gear_derivatives(void)
{
  NeslSimulationData *simulationData;
  real_T time;
  boolean_T tmp;
  real_T tmp_0[4];
  int_T tmp_1[2];
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  int32_T tmp_2;
  char *msg;
  XDot_sm_cardan_gear_T *_rtXdot;
  _rtXdot = ((XDot_sm_cardan_gear_T *) sm_cardan_gear_M->derivs);

  /* Derivatives for SimscapeExecutionBlock: '<S9>/STATE_1' */
  simulationData = (NeslSimulationData *)
    sm_cardan_gear_DW.STATE_1_SimulationData;
  time = sm_cardan_gear_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 10;
  simulationData->mData->mContStates.mX = (real_T *)
    &sm_cardan_gear_X.sm_cardan_gearSun_JointRzq;
  simulationData->mData->mDiscStates.mN = 2;
  simulationData->mData->mDiscStates.mX = (real_T *)
    &sm_cardan_gear_DW.STATE_1_DiscStates;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX = NULL;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(sm_cardan_gear_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(&sm_cardan_gear_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_1[0] = 0;
  tmp_0[0] = sm_cardan_gear_B.INPUT_1_1_1[0];
  tmp_0[1] = sm_cardan_gear_B.INPUT_1_1_1[1];
  tmp_0[2] = sm_cardan_gear_B.INPUT_1_1_1[2];
  tmp_0[3] = sm_cardan_gear_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  simulationData->mData->mInputValues.mN = 4;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 2;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 10;
  simulationData->mData->mDx.mX = (real_T *)&_rtXdot->sm_cardan_gearSun_JointRzq;
  diagnosticManager = (NeuDiagnosticManager *)
    sm_cardan_gear_DW.STATE_1_DiagnosticManager;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method((NeslSimulator *)
    sm_cardan_gear_DW.STATE_1_Simulator, NESL_SIM_DERIVATIVES, simulationData,
    diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(sm_cardan_gear_M, msg);
    }
  }

  /* End of Derivatives for SimscapeExecutionBlock: '<S9>/STATE_1' */
}

/* Model initialize function */
void sm_cardan_gear_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)sm_cardan_gear_M, 0,
                sizeof(RT_MODEL_sm_cardan_gear_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&sm_cardan_gear_M->solverInfo,
                          &sm_cardan_gear_M->Timing.simTimeStep);
    rtsiSetTPtr(&sm_cardan_gear_M->solverInfo, &rtmGetTPtr(sm_cardan_gear_M));
    rtsiSetStepSizePtr(&sm_cardan_gear_M->solverInfo,
                       &sm_cardan_gear_M->Timing.stepSize0);
    rtsiSetdXPtr(&sm_cardan_gear_M->solverInfo, &sm_cardan_gear_M->derivs);
    rtsiSetContStatesPtr(&sm_cardan_gear_M->solverInfo, (real_T **)
                         &sm_cardan_gear_M->contStates);
    rtsiSetNumContStatesPtr(&sm_cardan_gear_M->solverInfo,
      &sm_cardan_gear_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&sm_cardan_gear_M->solverInfo,
      &sm_cardan_gear_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&sm_cardan_gear_M->solverInfo,
      &sm_cardan_gear_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&sm_cardan_gear_M->solverInfo,
      &sm_cardan_gear_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&sm_cardan_gear_M->solverInfo, (&rtmGetErrorStatus
      (sm_cardan_gear_M)));
    rtsiSetRTModelPtr(&sm_cardan_gear_M->solverInfo, sm_cardan_gear_M);
  }

  rtsiSetSimTimeStep(&sm_cardan_gear_M->solverInfo, MAJOR_TIME_STEP);
  sm_cardan_gear_M->intgData.y = sm_cardan_gear_M->odeY;
  sm_cardan_gear_M->intgData.f[0] = sm_cardan_gear_M->odeF[0];
  sm_cardan_gear_M->intgData.f[1] = sm_cardan_gear_M->odeF[1];
  sm_cardan_gear_M->intgData.f[2] = sm_cardan_gear_M->odeF[2];
  sm_cardan_gear_M->contStates = ((X_sm_cardan_gear_T *) &sm_cardan_gear_X);
  rtsiSetSolverData(&sm_cardan_gear_M->solverInfo, (void *)
                    &sm_cardan_gear_M->intgData);
  rtsiSetSolverName(&sm_cardan_gear_M->solverInfo,"ode3");
  rtmSetTPtr(sm_cardan_gear_M, &sm_cardan_gear_M->Timing.tArray[0]);
  rtmSetTFinal(sm_cardan_gear_M, 10.0);
  sm_cardan_gear_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    sm_cardan_gear_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(sm_cardan_gear_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(sm_cardan_gear_M->rtwLogInfo, (NULL));
    rtliSetLogT(sm_cardan_gear_M->rtwLogInfo, "tout");
    rtliSetLogX(sm_cardan_gear_M->rtwLogInfo, "");
    rtliSetLogXFinal(sm_cardan_gear_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(sm_cardan_gear_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(sm_cardan_gear_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(sm_cardan_gear_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(sm_cardan_gear_M->rtwLogInfo, 1);
    rtliSetLogY(sm_cardan_gear_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(sm_cardan_gear_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(sm_cardan_gear_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &sm_cardan_gear_B), 0,
                sizeof(B_sm_cardan_gear_T));

  /* states (continuous) */
  {
    (void) memset((void *)&sm_cardan_gear_X, 0,
                  sizeof(X_sm_cardan_gear_T));
  }

  /* states (dwork) */
  (void) memset((void *)&sm_cardan_gear_DW, 0,
                sizeof(DW_sm_cardan_gear_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(sm_cardan_gear_M->rtwLogInfo, 0.0,
    rtmGetTFinal(sm_cardan_gear_M), sm_cardan_gear_M->Timing.stepSize0,
    (&rtmGetErrorStatus(sm_cardan_gear_M)));

  {
    NeslSimulator *tmp;
    boolean_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeModelParameters modelParameters;
    real_T tmp_1;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;
    NeslSimulationData *simulationData;
    real_T time;
    NeParameterBundle expl_temp;

    /* Start for SimscapeExecutionBlock: '<S9>/STATE_1' */
    tmp = nesl_lease_simulator("sm_cardan_gear/Solver Configuration_1", 0, 0);
    sm_cardan_gear_DW.STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(sm_cardan_gear_DW.STATE_1_Simulator);
    if (tmp_0) {
      sm_cardan_gear_ffe27655_1_gateway();
      tmp = nesl_lease_simulator("sm_cardan_gear/Solver Configuration_1", 0, 0);
      sm_cardan_gear_DW.STATE_1_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    sm_cardan_gear_DW.STATE_1_SimulationData = (void *)simulationData;
    diagnosticManager = rtw_create_diagnostics();
    sm_cardan_gear_DW.STATE_1_DiagnosticManager = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverTolerance = 1.0E-6;
    modelParameters.mVariableStepSolver = false;
    modelParameters.mFixedStepSize = 0.001;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters.mRTWModifiedTimeStamp = 4.622781E+8;
    tmp_1 = 0.001;
    modelParameters.mSolverTolerance = tmp_1;
    tmp_1 = 0.2;
    modelParameters.mFixedStepSize = tmp_1;
    tmp_0 = false;
    modelParameters.mVariableStepSolver = tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cardan_gear_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      sm_cardan_gear_DW.STATE_1_Simulator, &modelParameters, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cardan_gear_M, msg);
      }
    }

    expl_temp.mRealParameters.mN = 0;
    expl_temp.mRealParameters.mX = NULL;
    expl_temp.mLogicalParameters.mN = 0;
    expl_temp.mLogicalParameters.mX = NULL;
    expl_temp.mIntegerParameters.mN = 0;
    expl_temp.mIntegerParameters.mX = NULL;
    expl_temp.mIndexParameters.mN = 0;
    expl_temp.mIndexParameters.mX = NULL;
    nesl_simulator_set_rtps((NeslSimulator *)sm_cardan_gear_DW.STATE_1_Simulator,
      expl_temp);
    simulationData = (NeslSimulationData *)
      sm_cardan_gear_DW.STATE_1_SimulationData;
    time = sm_cardan_gear_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 10;
    simulationData->mData->mContStates.mX = (real_T *)
      &sm_cardan_gear_X.sm_cardan_gearSun_JointRzq;
    simulationData->mData->mDiscStates.mN = 2;
    simulationData->mData->mDiscStates.mX = (real_T *)
      &sm_cardan_gear_DW.STATE_1_DiscStates;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp_0 = false;
    simulationData->mData->mFoundZcEvents = tmp_0;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (sm_cardan_gear_M);
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_0 = rtsiIsSolverComputingJacobian(&sm_cardan_gear_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_0;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)
      sm_cardan_gear_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      sm_cardan_gear_DW.STATE_1_Simulator, NESL_SIM_INITIALIZEONCE,
      simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus(sm_cardan_gear_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(sm_cardan_gear_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S9>/STATE_1' */
  }

  {
    boolean_T tmp;
    int_T tmp_0;
    char *tmp_1;

    /* InitializeConditions for SimscapeExecutionBlock: '<S9>/STATE_1' */
    tmp = false;
    if (tmp) {
      tmp_0 = strcmp("ode3", rtsiGetSolverName(&sm_cardan_gear_M->solverInfo));
      if (tmp_0 != 0) {
        tmp_1 = solver_mismatch_message("ode3", rtsiGetSolverName
          (&sm_cardan_gear_M->solverInfo));
        rtmSetErrorStatus(sm_cardan_gear_M, tmp_1);
      }
    }

    /* End of InitializeConditions for SimscapeExecutionBlock: '<S9>/STATE_1' */
  }
}

/* Model terminate function */
void sm_cardan_gear_terminate(void)
{
  /* Terminate for SimscapeExecutionBlock: '<S9>/STATE_1' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    sm_cardan_gear_DW.STATE_1_DiagnosticManager);
  nesl_destroy_simulation_data((NeslSimulationData *)
    sm_cardan_gear_DW.STATE_1_SimulationData);
  nesl_erase_simulator("sm_cardan_gear/Solver Configuration_1");
}
