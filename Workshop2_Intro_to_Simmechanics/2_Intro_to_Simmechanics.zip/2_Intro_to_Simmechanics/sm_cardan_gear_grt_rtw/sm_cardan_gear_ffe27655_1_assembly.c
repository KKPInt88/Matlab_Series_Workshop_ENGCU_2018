/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cardan_gear/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_CTarget.h"

static boolean_T checkTargets_0(const double *rtdv, const double *state)
{
  (void) rtdv;
  return fabs(state[2] - 0.1570796326794897) < 1.0e-5;
}

void sm_cardan_gear_ffe27655_1_checkTargets(const double *rtdv, const double
  *state)
{
  const char *msgId = "sm:compiler:state:UnsatisfiedDesiredTarget";
  if (!checkTargets_0(rtdv, state)) {
    pmf_preformatted_warning(
      msgId,
      "sm_cardan_gear/Planet A Joint Rz high priority position target not achieved");
    pmf_printf("[manual]sm_cardan_gear/Planet A Joint Rz high priority position target not achieved\n");
  }
}

void sm_cardan_gear_ffe27655_1_setTargets(const double *rtdv, CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void sm_cardan_gear_ffe27655_1_resetStateVector(const void *mech, double *state)
{
  double xx[1];
  (void) mech;
  xx[0] = 0.0;
  state[0] = xx[0];
  state[1] = xx[0];
  state[2] = xx[0];
  state[3] = xx[0];
  state[4] = xx[0];
  state[5] = xx[0];
  state[6] = xx[0];
  state[7] = xx[0];
  state[8] = xx[0];
  state[9] = xx[0];
  state[10] = xx[0];
  state[11] = xx[0];
}

static PmfMessageId initializeTrackedAngleState_0(const double *rtdv, const
  double *motionData, double *state, NeuDiagnosticManager *neDiagMgr)
{
  double xx[22];
  (void) rtdv;
  (void) neDiagMgr;
  xx[0] = 3.141592653589793;
  xx[1] = 2.0;
  xx[2] = motionData[15];
  xx[3] = motionData[16];
  xx[4] = motionData[17];
  xx[5] = 7.034264913192121e-3;
  xx[6] = 0.03468999503471949;
  xx[7] = xx[6] * motionData[17] + xx[5] * motionData[15];
  xx[8] = xx[6] * motionData[16];
  xx[9] = - (xx[5] * motionData[16]);
  xx[10] = xx[7];
  xx[11] = - xx[8];
  pm_math_cross3(xx + 2, xx + 9, xx + 12);
  xx[2] = motionData[8];
  xx[3] = motionData[9];
  xx[4] = motionData[10];
  xx[9] = 4.336171384355309e-17;
  xx[10] = xx[9] * motionData[10];
  xx[11] = 6.240732392112002e-18;
  xx[15] = xx[9] * motionData[8] + xx[11] * motionData[9];
  xx[16] = xx[10];
  xx[17] = xx[11] * motionData[10];
  xx[18] = - xx[15];
  pm_math_cross3(xx + 2, xx + 16, xx + 19);
  xx[2] = xx[1] * (xx[12] - xx[5] * motionData[14] * motionData[16]) +
    motionData[18] + xx[6] - (xx[1] * (xx[19] + xx[10] * motionData[7]) +
    motionData[11] + xx[11]);
  xx[3] = xx[1] * (xx[7] * motionData[14] + xx[13]) + motionData[19] - (xx[1] *
    (xx[11] * motionData[7] * motionData[10] + xx[20]) + motionData[12] - xx[9]);
  xx[4] = xx[1] * (xx[14] - xx[8] * motionData[14]) + motionData[20] - xx[5] -
    (xx[1] * (xx[21] - xx[15] * motionData[7]) + motionData[13]);
  xx[5] = 0.9985915472931449;
  xx[6] = 0.05305583544420572;
  xx[7] = xx[5] * motionData[9] - xx[6] * motionData[8];
  xx[8] = xx[5] * motionData[8] + xx[6] * motionData[9];
  xx[9] = xx[7] * xx[8];
  xx[10] = xx[5] * motionData[7] - xx[6] * motionData[10];
  xx[11] = xx[6] * motionData[7] + xx[5] * motionData[10];
  xx[5] = xx[10] * xx[11];
  xx[6] = 1.0;
  xx[12] = xx[11] * xx[11];
  xx[13] = xx[1] * (xx[9] - xx[5]);
  xx[14] = xx[6] - xx[1] * (xx[12] + xx[8] * xx[8]);
  xx[15] = xx[1] * (xx[10] * xx[8] + xx[7] * xx[11]);
  xx[16] = xx[6] - xx[1] * (xx[7] * xx[7] + xx[12]);
  xx[17] = xx[1] * (xx[5] + xx[9]);
  xx[18] = xx[1] * (xx[8] * xx[11] - xx[10] * xx[7]);
  xx[1] = atan2(pm_math_dot3(xx + 2, xx + 13), pm_math_dot3(xx + 2, xx + 16));
  xx[2] = (xx[1] < 0.0 ? -1.0 : +1.0);
  xx[3] = xx[10];
  xx[4] = xx[8];
  xx[5] = xx[7];
  xx[6] = xx[11];
  xx[7] = motionData[14];
  xx[8] = motionData[15];
  xx[9] = motionData[16];
  xx[10] = motionData[17];
  xx[11] = motionData[40];
  xx[12] = motionData[41];
  xx[13] = motionData[42];
  pm_math_quatXform(xx + 7, xx + 11, xx + 14);
  xx[7] = motionData[7];
  xx[8] = motionData[8];
  xx[9] = motionData[9];
  xx[10] = motionData[10];
  xx[11] = motionData[34];
  xx[12] = motionData[35];
  xx[13] = motionData[36];
  pm_math_quatXform(xx + 7, xx + 11, xx + 17);
  xx[7] = xx[14] - xx[17];
  xx[8] = xx[15] - xx[18];
  xx[9] = xx[16] - xx[19];
  pm_math_quatInverseXform(xx + 3, xx + 7, xx + 10);
  state[6] = (fmod(xx[0] + xx[2] * xx[1], 6.283185307179586) - xx[0]) * xx[2];
  state[7] = 0.5 * xx[12];
  return NULL;
}

static PmfMessageId initializeTrackedAngleState_1(const double *rtdv, const
  double *motionData, double *state, NeuDiagnosticManager *neDiagMgr)
{
  double xx[14];
  (void) rtdv;
  (void) neDiagMgr;
  xx[0] = 3.141592653589793;
  xx[1] = 2.0;
  xx[2] = 6.240732392112002e-18;
  xx[3] = motionData[22];
  xx[4] = motionData[23];
  xx[5] = motionData[24];
  xx[6] = 4.336171384355309e-17;
  xx[7] = xx[6] * motionData[24];
  xx[8] = xx[7];
  xx[9] = xx[2] * motionData[24];
  xx[10] = - (xx[6] * motionData[22] + xx[2] * motionData[23]);
  pm_math_cross3(xx + 3, xx + 8, xx + 11);
  xx[3] = atan2(xx[1] * (xx[2] * motionData[21] * motionData[24] + xx[12]) +
                motionData[26] - xx[6], xx[1] * (xx[11] + xx[7] * motionData[21])
                + motionData[25] + xx[2]);
  xx[1] = (xx[3] < 0.0 ? -1.0 : +1.0);
  xx[4] = motionData[21];
  xx[5] = motionData[22];
  xx[6] = motionData[23];
  xx[7] = motionData[24];
  xx[8] = motionData[34];
  xx[9] = motionData[35];
  xx[10] = motionData[36];
  pm_math_quatXform(xx + 4, xx + 8, xx + 11);
  state[8] = (fmod(xx[0] + xx[1] * xx[3], 6.283185307179586) - xx[0]) * xx[1];
  state[9] = 0.3333333333333333 * xx[13];
  return NULL;
}

void sm_cardan_gear_ffe27655_1_initializeTrackedAngleState(const void *mech,
  const double *rtdv, const double *motionData, double *state, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  initializeTrackedAngleState_0(rtdv, motionData, state, neDiagMgr);
  initializeTrackedAngleState_1(rtdv, motionData, state, neDiagMgr);
}

void sm_cardan_gear_ffe27655_1_computeDiscreteState(const void *mech, const
  double *rtdv, double *state)
{
  double xx[43];
  (void) mech;
  (void) rtdv;
  xx[0] = 2.0;
  xx[1] = 0.04089681274430031;
  xx[2] = 0.5;
  xx[3] = xx[2] * state[4];
  xx[4] = cos(xx[3]);
  xx[5] = 0.8709379761288196;
  xx[6] = sin(xx[3]);
  xx[3] = 0.182724714184937 * xx[6];
  xx[7] = 0.07994726428595826;
  xx[8] = 0.9831641159165814 * xx[6];
  xx[6] = xx[1] * xx[4] - xx[5] * xx[3] + xx[7] * xx[8];
  xx[9] = 0.4831179228482263;
  xx[10] = xx[7] * xx[4] + xx[9] * xx[3] - xx[1] * xx[8];
  xx[11] = xx[5] * xx[8] - xx[9] * xx[4] + xx[7] * xx[3];
  xx[12] = xx[6];
  xx[13] = xx[10];
  xx[14] = xx[11];
  xx[7] = 7.034264913192121e-3;
  xx[15] = xx[7] * xx[10];
  xx[16] = 0.03468999503471949;
  xx[17] = xx[16] * xx[11] + xx[7] * xx[6];
  xx[7] = xx[16] * xx[10];
  xx[18] = - xx[15];
  xx[19] = xx[17];
  xx[20] = - xx[7];
  pm_math_cross3(xx + 12, xx + 18, xx + 21);
  xx[16] = xx[5] * xx[4] + xx[1] * xx[3] + xx[9] * xx[8];
  xx[1] = 7.713196825556601e-3;
  xx[3] = xx[1] * xx[10];
  xx[4] = 0.03194912432194544;
  xx[5] = xx[4] * xx[11] - xx[1] * xx[6];
  xx[1] = xx[4] * xx[10];
  xx[18] = xx[3];
  xx[19] = xx[5];
  xx[20] = - xx[1];
  pm_math_cross3(xx + 12, xx + 18, xx + 24);
  xx[4] = 3.568507962179244e-3;
  xx[8] = xx[2] * state[2];
  xx[9] = cos(xx[8]);
  xx[12] = 5.699653188004584e-4;
  xx[13] = sin(xx[8]);
  xx[8] = xx[4] * xx[9] - xx[12] * xx[13];
  xx[14] = xx[12] * xx[9] + xx[4] * xx[13];
  xx[4] = - xx[14];
  xx[12] = 0.2621533222727515;
  xx[18] = 0.9650194694988377;
  xx[19] = xx[12] * xx[9] - xx[18] * xx[13];
  xx[27] = xx[8];
  xx[28] = xx[4];
  xx[29] = xx[19];
  xx[20] = 4.336171384355309e-17;
  xx[30] = xx[20] * xx[19];
  xx[31] = 6.240732392112002e-18;
  xx[32] = xx[31] * xx[19];
  xx[33] = xx[31] * xx[14] - xx[20] * xx[8];
  xx[34] = xx[30];
  xx[35] = xx[32];
  xx[36] = xx[33];
  pm_math_cross3(xx + 27, xx + 34, xx + 37);
  xx[14] = xx[18] * xx[9] + xx[12] * xx[13];
  xx[9] = xx[0] * (xx[37] - xx[30] * xx[14]);
  xx[12] = xx[31] + xx[9];
  xx[13] = xx[0] * (xx[38] - xx[32] * xx[14]);
  xx[18] = xx[13] - xx[20];
  xx[27] = xx[0] * (xx[39] - xx[14] * xx[33]);
  xx[28] = 0.01449907368972891;
  xx[32] = xx[0] * (xx[21] - xx[15] * xx[16]) - xx[0] * (xx[3] * xx[16] + xx[24])
    + 0.08092328375554529 - (xx[9] - xx[12] + 0.03696626849097064);
  xx[33] = xx[0] * (xx[16] * xx[17] + xx[22]) - xx[0] * (xx[16] * xx[5] + xx[25])
    + 0.03914259083055165 - (xx[13] - xx[18] - 0.05208460108431659);
  xx[34] = xx[0] * (xx[23] - xx[7] * xx[16]) - xx[0] * (xx[26] - xx[1] * xx[16])
    - 0.01496967009981087 - (xx[27] - xx[27] - xx[28]);
  xx[21] = xx[16];
  xx[22] = xx[6];
  xx[23] = xx[10];
  xx[24] = xx[11];
  xx[35] = - 0.9530551403624588;
  xx[36] = 0.02658750541312705;
  xx[37] = 0.08781256514654519;
  xx[38] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 21, xx + 35, xx + 39);
  xx[1] = xx[40] * xx[41];
  xx[3] = xx[39] * xx[42];
  xx[5] = 1.0;
  xx[6] = xx[42] * xx[42];
  xx[9] = xx[0] * (xx[1] - xx[3]);
  xx[10] = xx[5] - xx[0] * (xx[6] + xx[40] * xx[40]);
  xx[11] = xx[0] * (xx[39] * xx[40] + xx[41] * xx[42]);
  xx[15] = xx[5] - xx[0] * (xx[41] * xx[41] + xx[6]);
  xx[16] = xx[0] * (xx[3] + xx[1]);
  xx[17] = xx[0] * (xx[40] * xx[42] - xx[39] * xx[41]);
  xx[21] = 0.9775690487425092;
  xx[22] = 3.533241901317298e-3;
  xx[23] = - 7.584927208271003e-4;
  xx[24] = 0.2105841775422004;
  xx[1] = xx[2] * state[0];
  xx[3] = sin(xx[1]);
  xx[35] = cos(xx[1]);
  xx[36] = 2.971047694847219e-3 * xx[3];
  xx[37] = 6.588522717321608e-3 * xx[3];
  xx[38] = 0.9999738817809185 * xx[3];
  pm_math_quatCompose(xx + 21, xx + 35, xx + 39);
  xx[21] = - xx[14];
  xx[22] = xx[8];
  xx[23] = xx[4];
  xx[24] = xx[19];
  pm_math_quatCompose(xx + 39, xx + 21, xx + 35);
  xx[1] = xx[20] * xx[38];
  xx[3] = xx[20] * xx[36] + xx[31] * xx[37];
  xx[6] = xx[1];
  xx[7] = xx[31] * xx[38];
  xx[8] = - xx[3];
  pm_math_cross3(xx + 36, xx + 6, xx + 21);
  xx[6] = 0.03696626849097063 - xx[12];
  xx[7] = - (0.05208460108431655 + xx[18]);
  xx[8] = - (xx[28] + xx[27]);
  pm_math_quatXform(xx + 39, xx + 6, xx + 12);
  xx[6] = - 0.09972985016632961;
  xx[7] = 9.674375133208124e-3;
  xx[8] = - 0.01449984343940976;
  pm_math_quatXform(xx + 39, xx + 6, xx + 24);
  xx[6] = xx[31] + xx[0] * (xx[21] + xx[1] * xx[35]) + xx[12] - xx[24];
  xx[7] = xx[0] * (xx[31] * xx[35] * xx[38] + xx[22]) - xx[20] + xx[13] - xx[25];
  xx[8] = xx[0] * (xx[23] - xx[3] * xx[35]) + xx[14] - xx[26];
  xx[1] = 0.9985915472931449;
  xx[3] = 0.05305583544420572;
  xx[4] = xx[1] * xx[37] - xx[3] * xx[36];
  xx[12] = xx[1] * xx[36] + xx[3] * xx[37];
  xx[13] = xx[4] * xx[12];
  xx[14] = xx[1] * xx[35] - xx[3] * xx[38];
  xx[18] = xx[3] * xx[35] + xx[1] * xx[38];
  xx[1] = xx[14] * xx[18];
  xx[3] = xx[18] * xx[18];
  xx[19] = xx[0] * (xx[13] - xx[1]);
  xx[20] = xx[5] - xx[0] * (xx[3] + xx[12] * xx[12]);
  xx[21] = xx[0] * (xx[14] * xx[12] + xx[4] * xx[18]);
  xx[22] = xx[5] - xx[0] * (xx[4] * xx[4] + xx[3]);
  xx[23] = xx[0] * (xx[1] + xx[13]);
  xx[24] = xx[0] * (xx[18] * xx[12] - xx[14] * xx[4]);
  state[10] = state[6] + atan2(pm_math_dot3(xx + 32, xx + 9), pm_math_dot3(xx +
    32, xx + 15));
  state[11] = state[8] + xx[2] * atan2(pm_math_dot3(xx + 6, xx + 19),
    pm_math_dot3(xx + 6, xx + 22));
}

void sm_cardan_gear_ffe27655_1_adjustPosition(const void *mech, const double
  *dofDeltas, double *state)
{
  (void) mech;
  state[0] = state[0] + dofDeltas[0];
  state[2] = state[2] + dofDeltas[1];
  state[4] = state[4] + dofDeltas[2];
}

static void perturbJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[1] = state[1] - 0.875 * mag;
}

static void perturbJointPrimitiveState_1_0(double mag, double *state)
{
  state[2] = state[2] + mag;
}

static void perturbJointPrimitiveState_1_0v(double mag, double *state)
{
  state[2] = state[2] + mag;
  state[3] = state[3] - 0.875 * mag;
}

static void perturbJointPrimitiveState_2_0(double mag, double *state)
{
  state[4] = state[4] + mag;
}

static void perturbJointPrimitiveState_2_0v(double mag, double *state)
{
  state[4] = state[4] + mag;
  state[5] = state[5] - 0.875 * mag;
}

void sm_cardan_gear_ffe27655_1_perturbJointPrimitiveState(const void *mech,
  size_t stageIdx, size_t primIdx, double mag, boolean_T doPerturbVelocity,
  double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbJointPrimitiveState_0_0v(mag, state);
    break;

   case 12:
    perturbJointPrimitiveState_1_0(mag, state);
    break;

   case 13:
    perturbJointPrimitiveState_1_0v(mag, state);
    break;

   case 24:
    perturbJointPrimitiveState_2_0(mag, state);
    break;

   case 25:
    perturbJointPrimitiveState_2_0v(mag, state);
    break;
  }
}

void sm_cardan_gear_ffe27655_1_perturbFlexibleBodyState(const void *mech, size_t
  stageIdx, double mag, boolean_T doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch (stageIdx * 2 + (doPerturbVelocity ? 1 : 0))
  {
  }
}

void sm_cardan_gear_ffe27655_1_computeDofBlendMatrix(const void *mech, size_t
  stageIdx, size_t primIdx, const double *state, int partialType, double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void sm_cardan_gear_ffe27655_1_projectPartiallyTargetedPos(const void *mech,
  size_t stageIdx, size_t primIdx, const double *origState, int partialType,
  double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void sm_cardan_gear_ffe27655_1_propagateMotion(const void *mech, const double
  *rtdv, const double *state, double *motionData)
{
  double xx[61];
  (void) mech;
  (void) rtdv;
  xx[0] = 0.9775690487425092;
  xx[1] = 3.533241901317298e-3;
  xx[2] = - 7.584927208271003e-4;
  xx[3] = 0.2105841775422004;
  xx[4] = 0.5;
  xx[5] = xx[4] * state[0];
  xx[6] = 2.971047694847219e-3;
  xx[7] = sin(xx[5]);
  xx[8] = 6.588522717321608e-3;
  xx[9] = 0.9999738817809185;
  xx[10] = cos(xx[5]);
  xx[11] = xx[6] * xx[7];
  xx[12] = xx[8] * xx[7];
  xx[13] = xx[9] * xx[7];
  pm_math_quatCompose(xx + 0, xx + 10, xx + 14);
  xx[0] = - 0.09972985016632961;
  xx[1] = 9.674375133208124e-3;
  xx[2] = - 0.01449984343940976;
  pm_math_quatXform(xx + 14, xx + 0, xx + 10);
  xx[0] = 0.9650194694988377;
  xx[1] = xx[4] * state[2];
  xx[2] = cos(xx[1]);
  xx[3] = 0.2621533222727515;
  xx[5] = sin(xx[1]);
  xx[1] = xx[0] * xx[2] + xx[3] * xx[5];
  xx[7] = - xx[1];
  xx[13] = 3.568507962179244e-3;
  xx[18] = 5.699653188004584e-4;
  xx[19] = xx[13] * xx[2] - xx[18] * xx[5];
  xx[20] = xx[18] * xx[2] + xx[13] * xx[5];
  xx[13] = - xx[20];
  xx[18] = xx[3] * xx[2] - xx[0] * xx[5];
  xx[0] = 6.240732392112002e-18;
  xx[2] = 2.0;
  xx[21] = xx[19];
  xx[22] = xx[13];
  xx[23] = xx[18];
  xx[3] = 4.336171384355309e-17;
  xx[5] = xx[3] * xx[18];
  xx[24] = xx[0] * xx[18];
  xx[25] = xx[0] * xx[20] - xx[3] * xx[19];
  xx[26] = xx[5];
  xx[27] = xx[24];
  xx[28] = xx[25];
  pm_math_cross3(xx + 21, xx + 26, xx + 29);
  xx[20] = 0.03696626849097063 - (xx[0] + xx[2] * (xx[29] - xx[5] * xx[1]));
  xx[5] = - (0.05208460108431655 + xx[2] * (xx[30] - xx[24] * xx[1]) - xx[3]);
  xx[21] = - (0.01449907368972891 + xx[2] * (xx[31] - xx[1] * xx[25]));
  xx[1] = 0.8709379761288196;
  xx[22] = xx[4] * state[4];
  xx[4] = cos(xx[22]);
  xx[23] = 0.04089681274430031;
  xx[24] = 0.182724714184937;
  xx[25] = sin(xx[22]);
  xx[22] = xx[24] * xx[25];
  xx[26] = 0.4831179228482263;
  xx[27] = 0.9831641159165814;
  xx[28] = xx[27] * xx[25];
  xx[25] = xx[1] * xx[4] + xx[23] * xx[22] + xx[26] * xx[28];
  xx[29] = 0.07994726428595826;
  xx[30] = xx[23] * xx[4] - xx[1] * xx[22] + xx[29] * xx[28];
  xx[31] = xx[29] * xx[4] + xx[26] * xx[22] - xx[23] * xx[28];
  xx[23] = xx[1] * xx[28] - xx[26] * xx[4] + xx[29] * xx[22];
  xx[1] = 0.03194912432194544;
  xx[4] = 7.713196825556601e-3;
  xx[22] = xx[4] * xx[31];
  xx[32] = xx[30];
  xx[33] = xx[31];
  xx[34] = xx[23];
  xx[26] = xx[1] * xx[23] - xx[4] * xx[30];
  xx[28] = xx[1] * xx[31];
  xx[35] = xx[22];
  xx[36] = xx[26];
  xx[37] = - xx[28];
  pm_math_cross3(xx + 32, xx + 35, xx + 38);
  xx[29] = 0.07818241304277124 - (xx[1] + xx[2] * (xx[22] * xx[25] + xx[38]));
  xx[1] = 0.03914259083055165 - xx[2] * (xx[25] * xx[26] + xx[39]);
  xx[22] = - (2.222083610621452e-4 + xx[4] + xx[2] * (xx[40] - xx[28] * xx[25]));
  xx[32] = xx[7];
  xx[33] = xx[19];
  xx[34] = xx[13];
  xx[35] = xx[18];
  pm_math_quatCompose(xx + 14, xx + 32, xx + 36);
  xx[40] = xx[20];
  xx[41] = xx[5];
  xx[42] = xx[21];
  pm_math_quatXform(xx + 14, xx + 40, xx + 43);
  xx[2] = xx[6] * state[1];
  xx[4] = xx[8] * state[1];
  xx[6] = xx[9] * state[1];
  xx[8] = 9.769655003657077e-3 * state[1];
  xx[9] = 0.09968416567382769 * state[1];
  xx[26] = 6.85815413354548e-4 * state[1];
  xx[46] = xx[2];
  xx[47] = xx[4];
  xx[48] = xx[6];
  pm_math_quatInverseXform(xx + 32, xx + 46, xx + 49);
  pm_math_cross3(xx + 46, xx + 40, xx + 52);
  xx[40] = xx[52] + xx[8];
  xx[41] = xx[53] + xx[9];
  xx[42] = xx[54] - xx[26];
  pm_math_quatInverseXform(xx + 32, xx + 40, xx + 52);
  xx[32] = xx[25];
  xx[33] = xx[30];
  xx[34] = xx[31];
  xx[35] = xx[23];
  pm_math_quatInverseXform(xx + 32, xx + 46, xx + 40);
  xx[55] = xx[29];
  xx[56] = xx[1];
  xx[57] = xx[22];
  pm_math_cross3(xx + 46, xx + 55, xx + 58);
  xx[46] = xx[58] + xx[8];
  xx[47] = xx[59] + xx[9];
  xx[48] = xx[60] - xx[26];
  pm_math_quatInverseXform(xx + 32, xx + 46, xx + 55);
  motionData[0] = xx[14];
  motionData[1] = xx[15];
  motionData[2] = xx[16];
  motionData[3] = xx[17];
  motionData[4] = - xx[10];
  motionData[5] = - xx[11];
  motionData[6] = - xx[12];
  motionData[7] = xx[7];
  motionData[8] = xx[19];
  motionData[9] = xx[13];
  motionData[10] = xx[18];
  motionData[11] = xx[20];
  motionData[12] = xx[5];
  motionData[13] = xx[21];
  motionData[14] = xx[25];
  motionData[15] = xx[30];
  motionData[16] = xx[31];
  motionData[17] = xx[23];
  motionData[18] = xx[29];
  motionData[19] = xx[1];
  motionData[20] = xx[22];
  motionData[21] = xx[36];
  motionData[22] = xx[37];
  motionData[23] = xx[38];
  motionData[24] = xx[39];
  motionData[25] = xx[43] - xx[10];
  motionData[26] = xx[44] - xx[11];
  motionData[27] = xx[45] - xx[12];
  motionData[28] = xx[2];
  motionData[29] = xx[4];
  motionData[30] = xx[6];
  motionData[31] = xx[8];
  motionData[32] = xx[9];
  motionData[33] = - xx[26];
  motionData[34] = xx[49];
  motionData[35] = xx[50];
  motionData[36] = xx[51] + state[3];
  motionData[37] = xx[52] - xx[3] * state[3];
  motionData[38] = xx[53] - xx[0] * state[3];
  motionData[39] = xx[54];
  motionData[40] = xx[40] - xx[24] * state[5];
  motionData[41] = xx[41];
  motionData[42] = xx[42] + xx[27] * state[5];
  motionData[43] = xx[55];
  motionData[44] = xx[56] - 0.03282062425369643 * state[5];
  motionData[45] = xx[57];
}

static size_t computeAssemblyError_0(const double *rtdv, const double *state,
  const double *motionData, double *error)
{
  double xx[27];
  (void) rtdv;
  (void) state;
  xx[0] = 0.9985915472931449;
  xx[1] = 0.05305583544420572;
  xx[2] = xx[0] * motionData[7] - xx[1] * motionData[10];
  xx[3] = xx[0] * motionData[8] + xx[1] * motionData[9];
  xx[4] = xx[0] * motionData[9] - xx[1] * motionData[8];
  xx[5] = xx[1] * motionData[7] + xx[0] * motionData[10];
  xx[6] = motionData[14];
  xx[7] = motionData[15];
  xx[8] = motionData[16];
  xx[9] = motionData[17];
  xx[10] = - 0.9530551403624588;
  xx[11] = 0.02658750541312705;
  xx[12] = 0.08781256514654519;
  xx[13] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 6, xx + 10, xx + 14);
  pm_math_quatInverseCompose(xx + 2, xx + 14, xx + 6);
  xx[0] = 2.0;
  xx[9] = motionData[15];
  xx[10] = motionData[16];
  xx[11] = motionData[17];
  xx[1] = 7.034264913192121e-3;
  xx[6] = 0.03468999503471949;
  xx[12] = xx[6] * motionData[17] + xx[1] * motionData[15];
  xx[13] = xx[6] * motionData[16];
  xx[14] = - (xx[1] * motionData[16]);
  xx[15] = xx[12];
  xx[16] = - xx[13];
  pm_math_cross3(xx + 9, xx + 14, xx + 17);
  xx[9] = motionData[8];
  xx[10] = motionData[9];
  xx[11] = motionData[10];
  xx[14] = 4.336171384355309e-17;
  xx[15] = xx[14] * motionData[10];
  xx[16] = 6.240732392112002e-18;
  xx[20] = xx[14] * motionData[8] + xx[16] * motionData[9];
  xx[21] = xx[15];
  xx[22] = xx[16] * motionData[10];
  xx[23] = - xx[20];
  pm_math_cross3(xx + 9, xx + 21, xx + 24);
  xx[9] = xx[0] * (xx[17] - xx[1] * motionData[14] * motionData[16]) +
    motionData[18] + xx[6] - (xx[0] * (xx[24] + xx[15] * motionData[7]) +
    motionData[11] + xx[16]);
  xx[6] = xx[0] * (xx[12] * motionData[14] + xx[18]) + motionData[19] - (xx[0] *
    (xx[16] * motionData[7] * motionData[10] + xx[25]) + motionData[12] - xx[14]);
  xx[10] = xx[0] * (xx[19] - xx[13] * motionData[14]) + motionData[20] - xx[1] -
    (xx[0] * (xx[26] - xx[20] * motionData[7]) + motionData[13]);
  xx[11] = xx[9];
  xx[12] = xx[6];
  xx[13] = xx[10];
  xx[14] = xx[0] * (xx[2] * xx[4] + xx[3] * xx[5]);
  xx[15] = xx[0] * (xx[4] * xx[5] - xx[2] * xx[3]);
  xx[16] = 1.0 - xx[0] * (xx[3] * xx[3] + xx[4] * xx[4]);
  error[0] = xx[7];
  error[1] = xx[8];
  error[2] = sqrt(xx[9] * xx[9] + xx[6] * xx[6] + xx[10] * xx[10]) - 0.1;
  error[3] = pm_math_dot3(xx + 11, xx + 14);
  return 4;
}

static size_t computeAssemblyError_1(const double *rtdv, const double *state,
  const double *motionData, double *error)
{
  double xx[16];
  (void) rtdv;
  (void) state;
  xx[0] = 0.9985915472931449;
  xx[1] = 0.05305583544420572;
  xx[2] = 2.0;
  xx[3] = motionData[22];
  xx[4] = motionData[23];
  xx[5] = motionData[24];
  xx[6] = 4.336171384355309e-17;
  xx[7] = xx[6] * motionData[24];
  xx[8] = 6.240732392112002e-18;
  xx[9] = xx[6] * motionData[22] + xx[8] * motionData[23];
  xx[10] = xx[7];
  xx[11] = xx[8] * motionData[24];
  xx[12] = - xx[9];
  pm_math_cross3(xx + 3, xx + 10, xx + 13);
  xx[3] = xx[2] * (xx[13] + xx[7] * motionData[21]) + motionData[25] + xx[8];
  xx[4] = xx[2] * (xx[8] * motionData[21] * motionData[24] + xx[14]) +
    motionData[26] - xx[6];
  xx[5] = xx[2] * (xx[15] - xx[9] * motionData[21]) + motionData[27];
  error[0] = - (xx[0] * motionData[22] + xx[1] * motionData[23]);
  error[1] = xx[1] * motionData[22] - xx[0] * motionData[23];
  error[2] = sqrt(xx[3] * xx[3] + xx[4] * xx[4] + xx[5] * xx[5]) - 0.15;
  error[3] = xx[5];
  return 4;
}

size_t sm_cardan_gear_ffe27655_1_computeAssemblyError(const void *mech, const
  double *rtdv, size_t constraintIdx, const double *state, const double
  *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) state;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
   case 0:
    return computeAssemblyError_0(rtdv, state, motionData, error);

   case 1:
    return computeAssemblyError_1(rtdv, state, motionData, error);
  }

  return 0;
}

static size_t computeAssemblyJacobian_0p(const double *rtdv, const double *state,
  const double *motionData, double *J)
{
  double xx[38];
  (void) rtdv;
  xx[0] = 0.0;
  xx[1] = 0.9985915472931449;
  xx[2] = 0.05305583544420572;
  xx[3] = xx[1] * motionData[7] - xx[2] * motionData[10];
  xx[4] = xx[1] * motionData[8] + xx[2] * motionData[9];
  xx[5] = xx[1] * motionData[9] - xx[2] * motionData[8];
  xx[6] = xx[2] * motionData[7] + xx[1] * motionData[10];
  xx[7] = motionData[14];
  xx[8] = motionData[15];
  xx[9] = motionData[16];
  xx[10] = motionData[17];
  xx[11] = - 0.9530551403624588;
  xx[12] = 0.02658750541312705;
  xx[13] = 0.08781256514654519;
  xx[14] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 7, xx + 11, xx + 15);
  pm_math_quatInverseCompose(xx + 3, xx + 15, xx + 7);
  xx[1] = 2.0;
  xx[2] = 1.0;
  xx[11] = xx[1] * (motionData[7] * motionData[9] + motionData[8] * motionData
                    [10]);
  xx[12] = xx[1] * (motionData[9] * motionData[10] - motionData[7] * motionData
                    [8]);
  xx[13] = xx[2] - xx[1] * (motionData[8] * motionData[8] + motionData[9] *
    motionData[9]);
  pm_math_quatInverseXform(xx + 15, xx + 11, xx + 19);
  xx[11] = - xx[19];
  xx[12] = - xx[20];
  xx[13] = - xx[21];
  pm_math_quatDeriv(xx + 7, xx + 11, xx + 14);
  xx[11] = 5.273559366969494e-16;
  xx[12] = 8.118505867571457e-16;
  xx[13] = xx[2];
  pm_math_quatDeriv(xx + 7, xx + 11, xx + 18);
  xx[7] = 4.336171384355309e-17;
  xx[8] = 3.568507962179244e-3;
  xx[9] = 0.5;
  xx[10] = xx[9] * state[2];
  xx[11] = cos(xx[10]);
  xx[12] = 5.699653188004584e-4;
  xx[13] = sin(xx[10]);
  xx[10] = xx[8] * xx[11] - xx[12] * xx[13];
  xx[14] = xx[12] * xx[11] + xx[8] * xx[13];
  xx[8] = 0.2621533222727515;
  xx[12] = 0.9650194694988377;
  xx[17] = xx[8] * xx[11] - xx[12] * xx[13];
  xx[21] = xx[10];
  xx[22] = - xx[14];
  xx[23] = xx[17];
  xx[18] = 6.240732392112002e-18;
  xx[24] = xx[18] * xx[17];
  xx[25] = xx[7] * xx[17];
  xx[17] = xx[18] * xx[10];
  xx[10] = xx[7] * xx[14];
  xx[14] = xx[17] + xx[10];
  xx[26] = - xx[24];
  xx[27] = xx[25];
  xx[28] = xx[14];
  pm_math_cross3(xx + 21, xx + 26, xx + 29);
  xx[26] = xx[12] * xx[11] + xx[8] * xx[13];
  xx[8] = xx[24] * xx[26];
  xx[11] = xx[17] + xx[10];
  xx[32] = xx[24];
  xx[33] = - xx[25];
  xx[34] = - xx[11];
  pm_math_cross3(xx + 21, xx + 32, xx + 35);
  xx[10] = xx[25] * xx[26];
  xx[21] = xx[7] + xx[1] * (xx[29] + xx[8]) + xx[1] * (xx[35] - xx[8]) - xx[7];
  xx[22] = xx[18] + xx[1] * (xx[30] - xx[10]) + xx[1] * (xx[10] + xx[36]) - xx
    [18];
  xx[23] = xx[1] * (xx[31] - xx[14] * xx[26]) + xx[1] * (xx[26] * xx[11] + xx[37]);
  xx[10] = motionData[15];
  xx[11] = motionData[16];
  xx[12] = motionData[17];
  xx[8] = 7.034264913192121e-3;
  xx[13] = 0.03468999503471949;
  xx[14] = xx[13] * motionData[17] + xx[8] * motionData[15];
  xx[17] = xx[13] * motionData[16];
  xx[24] = - (xx[8] * motionData[16]);
  xx[25] = xx[14];
  xx[26] = - xx[17];
  pm_math_cross3(xx + 10, xx + 24, xx + 27);
  xx[10] = motionData[8];
  xx[11] = motionData[9];
  xx[12] = motionData[10];
  xx[13] = xx[7] * motionData[10];
  xx[24] = xx[7] * motionData[8] + xx[18] * motionData[9];
  xx[30] = xx[13];
  xx[31] = xx[18] * motionData[10];
  xx[32] = - xx[24];
  pm_math_cross3(xx + 10, xx + 30, xx + 33);
  xx[10] = xx[1] * (xx[27] - xx[8] * motionData[14] * motionData[16]) +
    motionData[18] - (xx[1] * (xx[33] + xx[13] * motionData[7]) + motionData[11])
    + 0.03468999503471949;
  xx[11] = xx[1] * (xx[14] * motionData[14] + xx[28]) + motionData[19] - (xx[1] *
    (xx[18] * motionData[7] * motionData[10] + xx[34]) + motionData[12]) + xx[7];
  xx[7] = xx[1] * (xx[29] - xx[17] * motionData[14]) + motionData[20] - (xx[1] *
    (xx[35] - xx[24] * motionData[7]) + motionData[13]) - xx[8];
  xx[8] = sqrt(xx[10] * xx[10] + xx[11] * xx[11] + xx[7] * xx[7]);
  xx[12] = xx[8] == 0.0 ? 0.0 : xx[10] / xx[8];
  xx[10] = xx[8] == 0.0 ? 0.0 : xx[11] / xx[8];
  xx[11] = xx[8] == 0.0 ? 0.0 : xx[7] / xx[8];
  xx[24] = xx[12];
  xx[25] = xx[10];
  xx[26] = xx[11];
  xx[7] = 0.03282062425369642;
  xx[8] = 0.04089681274430031;
  xx[10] = xx[9] * state[4];
  xx[9] = cos(xx[10]);
  xx[11] = 0.8709379761288196;
  xx[12] = sin(xx[10]);
  xx[10] = 0.182724714184937 * xx[12];
  xx[13] = 0.07994726428595826;
  xx[14] = 0.9831641159165814 * xx[12];
  xx[12] = xx[8] * xx[9] - xx[11] * xx[10] + xx[13] * xx[14];
  xx[17] = xx[7] * xx[12];
  xx[18] = 0.4831179228482263;
  xx[27] = xx[13] * xx[9] + xx[18] * xx[10] - xx[8] * xx[14];
  xx[28] = xx[11] * xx[14] - xx[18] * xx[9] + xx[13] * xx[10];
  xx[13] = xx[7] * xx[28];
  xx[29] = xx[11] * xx[9] + xx[8] * xx[10] + xx[18] * xx[14];
  xx[8] = 0.03282062425369643;
  xx[9] = xx[8] * xx[28];
  xx[10] = xx[8] * xx[12];
  xx[30] = xx[1] * (xx[17] * xx[27] - xx[13] * xx[29]) + xx[1] * (xx[9] * xx[29]
    - xx[10] * xx[27]);
  xx[31] = xx[7] - xx[1] * (xx[13] * xx[28] + xx[17] * xx[12]) + xx[1] * (xx[9] *
    xx[28] + xx[10] * xx[12]) - xx[8];
  xx[32] = xx[1] * (xx[17] * xx[29] + xx[13] * xx[27]) - xx[1] * (xx[10] * xx[29]
    + xx[9] * xx[27]);
  xx[7] = xx[1] * (xx[5] * xx[3] + xx[4] * xx[6]);
  xx[8] = xx[1] * (xx[5] * xx[6] - xx[3] * xx[4]);
  xx[9] = xx[2] - xx[1] * (xx[4] * xx[4] + xx[5] * xx[5]);
  J[1] = xx[15];
  J[2] = xx[19];
  J[4] = xx[16];
  J[5] = xx[20];
  J[7] = - pm_math_dot3(xx + 21, xx + 24);
  J[8] = pm_math_dot3(xx + 30, xx + 24);
  J[10] = - pm_math_dot3(xx + 21, xx + 7);
  J[11] = pm_math_dot3(xx + 30, xx + 7);
  return 4;
}

static size_t computeAssemblyJacobian_0v(const double *rtdv, const double *state,
  const double *motionData, double *J)
{
  double xx[59];
  (void) rtdv;
  xx[0] = 0.0;
  xx[1] = 2.0;
  xx[2] = motionData[15];
  xx[3] = motionData[16];
  xx[4] = motionData[17];
  xx[5] = 7.034264913192121e-3;
  xx[6] = 0.03468999503471949;
  xx[7] = xx[6] * motionData[17] + xx[5] * motionData[15];
  xx[8] = xx[6] * motionData[16];
  xx[9] = - (xx[5] * motionData[16]);
  xx[10] = xx[7];
  xx[11] = - xx[8];
  pm_math_cross3(xx + 2, xx + 9, xx + 12);
  xx[2] = motionData[8];
  xx[3] = motionData[9];
  xx[4] = motionData[10];
  xx[9] = 4.336171384355309e-17;
  xx[10] = xx[9] * motionData[10];
  xx[11] = 6.240732392112002e-18;
  xx[15] = xx[9] * motionData[8] + xx[11] * motionData[9];
  xx[16] = xx[10];
  xx[17] = xx[11] * motionData[10];
  xx[18] = - xx[15];
  pm_math_cross3(xx + 2, xx + 16, xx + 19);
  xx[2] = xx[1] * (xx[12] - xx[5] * motionData[14] * motionData[16]) +
    motionData[18] + xx[6] - (xx[1] * (xx[19] + xx[10] * motionData[7]) +
    motionData[11] + xx[11]);
  xx[3] = xx[1] * (xx[7] * motionData[14] + xx[13]) + motionData[19] - (xx[1] *
    (xx[11] * motionData[7] * motionData[10] + xx[20]) + motionData[12] - xx[9]);
  xx[4] = xx[1] * (xx[14] - xx[8] * motionData[14]) + motionData[20] - xx[5] -
    (xx[1] * (xx[21] - xx[15] * motionData[7]) + motionData[13]);
  xx[5] = 1.0;
  xx[6] = 0.9985915472931449;
  xx[7] = 0.05305583544420572;
  xx[8] = xx[6] * motionData[9] - xx[7] * motionData[8];
  xx[10] = xx[8] * xx[8];
  xx[12] = xx[7] * motionData[7] + xx[6] * motionData[10];
  xx[13] = xx[12] * xx[12];
  xx[14] = xx[6] * motionData[7] - xx[7] * motionData[10];
  xx[15] = xx[14] * xx[12];
  xx[16] = xx[6] * motionData[8] + xx[7] * motionData[9];
  xx[6] = xx[8] * xx[16];
  xx[7] = xx[16] * xx[12];
  xx[17] = xx[14] * xx[8];
  xx[18] = xx[5] - xx[1] * (xx[10] + xx[13]);
  xx[19] = xx[1] * (xx[15] + xx[6]);
  xx[20] = xx[1] * (xx[7] - xx[17]);
  xx[21] = pm_math_dot3(xx + 2, xx + 18);
  xx[22] = 3.568507962179244e-3;
  xx[23] = 0.5;
  xx[24] = xx[23] * state[2];
  xx[25] = cos(xx[24]);
  xx[26] = 5.699653188004584e-4;
  xx[27] = sin(xx[24]);
  xx[24] = xx[22] * xx[25] - xx[26] * xx[27];
  xx[28] = xx[26] * xx[25] + xx[22] * xx[27];
  xx[22] = 0.2621533222727515;
  xx[26] = 0.9650194694988377;
  xx[29] = xx[22] * xx[25] - xx[26] * xx[27];
  xx[30] = xx[24];
  xx[31] = - xx[28];
  xx[32] = xx[29];
  xx[33] = 0.1059622176183197;
  xx[34] = xx[33] * xx[29];
  xx[35] = 0.9943701566506347;
  xx[36] = xx[35] * xx[29];
  xx[37] = - xx[36];
  xx[38] = xx[33] * xx[24] + xx[35] * xx[28];
  xx[39] = xx[34];
  xx[40] = xx[37];
  xx[41] = - xx[38];
  pm_math_cross3(xx + 30, xx + 39, xx + 42);
  xx[39] = xx[26] * xx[25] + xx[22] * xx[27];
  xx[22] = xx[34] * xx[39];
  xx[25] = xx[36] * xx[39];
  xx[45] = xx[1] * (xx[42] - xx[22]) - xx[35];
  xx[46] = xx[1] * (xx[25] + xx[43]) - xx[33];
  xx[47] = xx[1] * (xx[39] * xx[38] + xx[44]);
  xx[26] = xx[11] * xx[29];
  xx[27] = xx[9] * xx[29];
  xx[29] = xx[11] * xx[24];
  xx[36] = xx[9] * xx[28];
  xx[38] = xx[29] + xx[36];
  xx[40] = - xx[26];
  xx[41] = xx[27];
  xx[42] = xx[38];
  pm_math_cross3(xx + 30, xx + 40, xx + 48);
  xx[40] = xx[26] * xx[39];
  xx[41] = xx[29] + xx[36];
  xx[42] = xx[26];
  xx[43] = - xx[27];
  xx[44] = - xx[41];
  pm_math_cross3(xx + 30, xx + 42, xx + 51);
  xx[26] = xx[27] * xx[39];
  xx[42] = xx[9] + xx[1] * (xx[48] + xx[40]) + xx[1] * (xx[51] - xx[40]) - xx[9];
  xx[43] = xx[11] + xx[1] * (xx[49] - xx[26]) + xx[1] * (xx[26] + xx[52]) - xx
    [11];
  xx[44] = xx[1] * (xx[50] - xx[38] * xx[39]) + xx[1] * (xx[41] * xx[39] + xx[53]);
  xx[9] = xx[16] * xx[16];
  xx[11] = xx[14] * xx[16];
  xx[26] = xx[8] * xx[12];
  xx[48] = xx[1] * (xx[6] - xx[15]);
  xx[49] = xx[5] - xx[1] * (xx[13] + xx[9]);
  xx[50] = xx[1] * (xx[11] + xx[26]);
  xx[6] = pm_math_dot3(xx + 2, xx + 48);
  xx[13] = xx[35] * xx[24] - xx[33] * xx[28];
  xx[27] = xx[37];
  xx[28] = - xx[34];
  xx[29] = xx[13];
  pm_math_cross3(xx + 30, xx + 27, xx + 36);
  xx[27] = xx[1] * (xx[36] + xx[25]) - xx[33];
  xx[28] = xx[35] + xx[1] * (xx[22] + xx[37]);
  xx[29] = xx[1] * (xx[38] - xx[13] * xx[39]);
  xx[13] = 1.0e-4;
  xx[15] = xx[21] * xx[21] + xx[6] * xx[6];
  if (xx[13] > xx[15])
    xx[15] = xx[13];
  xx[22] = xx[15] == 0.0 ? 0.0 : (xx[21] * (pm_math_dot3(xx + 2, xx + 45) -
    pm_math_dot3(xx + 42, xx + 48)) - xx[6] * (pm_math_dot3(xx + 2, xx + 27) -
    pm_math_dot3(xx + 42, xx + 18))) / xx[15];
  xx[27] = motionData[14];
  xx[28] = motionData[15];
  xx[29] = motionData[16];
  xx[30] = motionData[17];
  xx[31] = - 0.9530551403624588;
  xx[32] = 0.02658750541312705;
  xx[33] = 0.08781256514654519;
  xx[34] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 27, xx + 31, xx + 35);
  xx[24] = xx[36] * xx[37];
  xx[25] = xx[35] * xx[38];
  xx[27] = xx[38] * xx[38];
  xx[28] = xx[1] * (xx[24] - xx[25]);
  xx[29] = xx[5] - xx[1] * (xx[27] + xx[36] * xx[36]);
  xx[30] = xx[1] * (xx[35] * xx[36] + xx[37] * xx[38]);
  xx[31] = pm_math_dot3(xx + 2, xx + 28);
  xx[32] = xx[5] - xx[1] * (xx[37] * xx[37] + xx[27]);
  xx[33] = xx[1] * (xx[25] + xx[24]);
  xx[34] = xx[1] * (xx[36] * xx[38] - xx[35] * xx[37]);
  xx[24] = pm_math_dot3(xx + 2, xx + 32);
  xx[25] = xx[24] * xx[24] + xx[31] * xx[31];
  if (xx[13] > xx[25])
    xx[25] = xx[13];
  xx[13] = xx[25] == 0.0 ? 0.0 : (xx[31] * pm_math_dot3(xx + 42, xx + 32) - xx
    [24] * pm_math_dot3(xx + 42, xx + 28)) / xx[25];
  xx[27] = 0.03282062425369642;
  xx[39] = 0.04089681274430031;
  xx[40] = xx[23] * state[4];
  xx[23] = cos(xx[40]);
  xx[41] = 0.8709379761288196;
  xx[45] = sin(xx[40]);
  xx[40] = 0.182724714184937 * xx[45];
  xx[46] = 0.07994726428595826;
  xx[47] = 0.9831641159165814 * xx[45];
  xx[45] = xx[39] * xx[23] - xx[41] * xx[40] + xx[46] * xx[47];
  xx[51] = xx[27] * xx[45];
  xx[52] = 0.4831179228482263;
  xx[53] = xx[46] * xx[23] + xx[52] * xx[40] - xx[39] * xx[47];
  xx[54] = xx[41] * xx[47] - xx[52] * xx[23] + xx[46] * xx[40];
  xx[46] = xx[27] * xx[54];
  xx[55] = xx[41] * xx[23] + xx[39] * xx[40] + xx[52] * xx[47];
  xx[23] = 0.03282062425369643;
  xx[39] = xx[23] * xx[54];
  xx[40] = xx[23] * xx[45];
  xx[56] = xx[1] * (xx[51] * xx[53] - xx[46] * xx[55]) + xx[1] * (xx[39] * xx[55]
    - xx[40] * xx[53]);
  xx[57] = xx[27] - xx[1] * (xx[46] * xx[54] + xx[51] * xx[45]) + xx[1] * (xx[39]
    * xx[54] + xx[40] * xx[45]) - xx[23];
  xx[58] = xx[1] * (xx[51] * xx[55] + xx[46] * xx[53]) - xx[1] * (xx[40] * xx[55]
    + xx[39] * xx[53]);
  xx[23] = xx[15] == 0.0 ? 0.0 : (xx[21] * pm_math_dot3(xx + 56, xx + 48) - xx[6]
    * pm_math_dot3(xx + 56, xx + 18)) / xx[15];
  xx[18] = xx[55];
  xx[19] = xx[45];
  xx[20] = xx[53];
  xx[21] = xx[54];
  xx[39] = - 0.818041992030798;
  xx[40] = - 0.5547001962252291;
  xx[41] = - 0.1520361522203753;
  pm_math_quatXform(xx + 18, xx + 39, xx + 45);
  xx[39] = - 0.5453613280205316;
  xx[40] = 0.8320502943378444;
  xx[41] = - 0.1013574348135835;
  pm_math_quatXform(xx + 18, xx + 39, xx + 48);
  xx[6] = xx[25] == 0.0 ? 0.0 : (xx[24] * (pm_math_dot3(xx + 56, xx + 28) +
    pm_math_dot3(xx + 2, xx + 45)) - xx[31] * (pm_math_dot3(xx + 56, xx + 32) +
    pm_math_dot3(xx + 2, xx + 48))) / xx[25];
  xx[18] = xx[14];
  xx[19] = xx[16];
  xx[20] = xx[8];
  xx[21] = xx[12];
  pm_math_quatInverseCompose(xx + 18, xx + 35, xx + 27);
  xx[14] = xx[1] * (motionData[7] * motionData[9] + motionData[8] * motionData
                    [10]);
  xx[15] = xx[1] * (motionData[9] * motionData[10] - motionData[7] * motionData
                    [8]);
  xx[16] = xx[5] - xx[1] * (motionData[8] * motionData[8] + motionData[9] *
    motionData[9]);
  pm_math_quatInverseXform(xx + 35, xx + 14, xx + 18);
  xx[14] = - xx[18];
  xx[15] = - xx[19];
  xx[16] = - xx[20];
  pm_math_quatDeriv(xx + 27, xx + 14, xx + 18);
  xx[14] = 5.273559366969494e-16;
  xx[15] = 8.118505867571457e-16;
  xx[16] = xx[5];
  pm_math_quatDeriv(xx + 27, xx + 14, xx + 31);
  xx[8] = sqrt(xx[2] * xx[2] + xx[3] * xx[3] + xx[4] * xx[4]);
  xx[12] = xx[8] == 0.0 ? 0.0 : xx[2] / xx[8];
  xx[2] = xx[8] == 0.0 ? 0.0 : xx[3] / xx[8];
  xx[3] = xx[8] == 0.0 ? 0.0 : xx[4] / xx[8];
  xx[14] = xx[12];
  xx[15] = xx[2];
  xx[16] = xx[3];
  xx[2] = xx[1] * (xx[17] + xx[7]);
  xx[3] = xx[1] * (xx[26] - xx[11]);
  xx[4] = xx[5] - xx[1] * (xx[9] + xx[10]);
  J[1] = xx[22] + xx[13];
  J[2] = xx[23] + xx[6];
  J[4] = xx[19];
  J[5] = xx[32];
  J[7] = xx[20];
  J[8] = xx[33];
  J[10] = - pm_math_dot3(xx + 42, xx + 14);
  J[11] = pm_math_dot3(xx + 56, xx + 14);
  J[13] = - pm_math_dot3(xx + 42, xx + 2);
  J[14] = pm_math_dot3(xx + 56, xx + 2);
  return 5;
}

static size_t computeAssemblyJacobian_1p(const double *rtdv, const double *state,
  const double *motionData, double *J)
{
  double xx[46];
  (void) rtdv;
  xx[0] = 0.9985915472931449;
  xx[1] = 0.05305583544420572;
  xx[2] = - (xx[0] * motionData[21] - xx[1] * motionData[24]);
  xx[3] = - (xx[0] * motionData[22] + xx[1] * motionData[23]);
  xx[4] = - (xx[0] * motionData[23] - xx[1] * motionData[22]);
  xx[5] = - (xx[1] * motionData[21] + xx[0] * motionData[24]);
  xx[6] = motionData[7];
  xx[7] = motionData[8];
  xx[8] = motionData[9];
  xx[9] = motionData[10];
  xx[10] = 2.971047694847219e-3;
  xx[11] = 6.588522717321608e-3;
  xx[12] = 0.9999738817809185;
  pm_math_quatInverseXform(xx + 6, xx + 10, xx + 13);
  xx[16] = 2.0;
  xx[17] = xx[1] * xx[13];
  xx[18] = xx[1] * xx[14];
  xx[19] = xx[13] - xx[16] * (xx[1] * xx[17] - xx[0] * xx[18]);
  xx[20] = xx[14] - xx[16] * (xx[0] * xx[17] + xx[1] * xx[18]);
  xx[21] = xx[15];
  pm_math_quatDeriv(xx + 2, xx + 19, xx + 22);
  xx[0] = 0.0;
  xx[17] = xx[0];
  xx[18] = xx[0];
  xx[19] = 1.0;
  pm_math_quatDeriv(xx + 2, xx + 17, xx + 26);
  xx[0] = 0.0;
  xx[1] = 0.9775690487425092;
  xx[2] = 3.533241901317298e-3;
  xx[3] = - 7.584927208271003e-4;
  xx[4] = 0.2105841775422004;
  xx[5] = 0.5;
  xx[17] = xx[5] * state[0];
  xx[18] = sin(xx[17]);
  xx[19] = cos(xx[17]);
  xx[20] = xx[10] * xx[18];
  xx[21] = xx[11] * xx[18];
  xx[22] = xx[12] * xx[18];
  pm_math_quatCompose(xx + 1, xx + 19, xx + 29);
  pm_math_quatCompose(xx + 29, xx + 6, xx + 1);
  xx[6] = 4.336171384355309e-17;
  xx[7] = 6.240732392112002e-18;
  xx[17] = xx[6] * xx[15];
  xx[18] = xx[7] * xx[15];
  xx[19] = - (xx[6] * xx[13] + xx[7] * xx[14]);
  pm_math_quatXform(xx + 1, xx + 17, xx + 13);
  xx[1] = motionData[11];
  xx[2] = motionData[12];
  xx[3] = motionData[13];
  pm_math_cross3(xx + 10, xx + 1, xx + 17);
  pm_math_quatXform(xx + 29, xx + 17, xx + 1);
  xx[8] = 9.769655003657077e-3;
  xx[9] = 0.09968416567382769;
  xx[10] = - 6.85815413354548e-4;
  pm_math_quatXform(xx + 29, xx + 8, xx + 17);
  xx[4] = xx[15] + xx[3] + xx[19];
  xx[8] = xx[13] + xx[1] + xx[17];
  xx[9] = xx[14] + xx[2] + xx[18];
  xx[10] = xx[4];
  xx[1] = motionData[22];
  xx[2] = motionData[23];
  xx[3] = motionData[24];
  xx[11] = xx[6] * motionData[24];
  xx[12] = xx[6] * motionData[22] + xx[7] * motionData[23];
  xx[13] = xx[11];
  xx[14] = xx[7] * motionData[24];
  xx[15] = - xx[12];
  pm_math_cross3(xx + 1, xx + 13, xx + 17);
  xx[1] = xx[16] * (xx[17] + xx[11] * motionData[21]) + motionData[25] + xx[7];
  xx[2] = xx[16] * (xx[7] * motionData[21] * motionData[24] + xx[18]) +
    motionData[26] - xx[6];
  xx[3] = xx[16] * (xx[19] - xx[12] * motionData[21]) + motionData[27];
  xx[11] = sqrt(xx[1] * xx[1] + xx[2] * xx[2] + xx[3] * xx[3]);
  xx[12] = xx[11] == 0.0 ? 0.0 : xx[1] / xx[11];
  xx[1] = xx[11] == 0.0 ? 0.0 : xx[2] / xx[11];
  xx[2] = xx[11] == 0.0 ? 0.0 : xx[3] / xx[11];
  xx[13] = xx[12];
  xx[14] = xx[1];
  xx[15] = xx[2];
  xx[17] = motionData[0];
  xx[18] = motionData[1];
  xx[19] = motionData[2];
  xx[20] = motionData[3];
  xx[1] = 0.9650194694988377;
  xx[2] = xx[5] * state[2];
  xx[3] = cos(xx[2]);
  xx[5] = 0.2621533222727515;
  xx[11] = sin(xx[2]);
  xx[2] = xx[1] * xx[3] + xx[5] * xx[11];
  xx[12] = 3.568507962179244e-3;
  xx[21] = 5.699653188004584e-4;
  xx[22] = xx[12] * xx[3] - xx[21] * xx[11];
  xx[25] = xx[21] * xx[3] + xx[12] * xx[11];
  xx[12] = - xx[25];
  xx[21] = xx[5] * xx[3] - xx[1] * xx[11];
  xx[29] = - xx[2];
  xx[30] = xx[22];
  xx[31] = xx[12];
  xx[32] = xx[21];
  pm_math_quatCompose(xx + 17, xx + 29, xx + 33);
  xx[1] = xx[7] * xx[36];
  xx[3] = xx[7] * xx[34] - xx[6] * xx[35];
  xx[29] = - xx[1];
  xx[30] = xx[6] * xx[36];
  xx[31] = xx[3];
  pm_math_cross3(xx + 34, xx + 29, xx + 37);
  xx[29] = xx[22];
  xx[30] = xx[12];
  xx[31] = xx[21];
  xx[5] = xx[7] * xx[21];
  xx[11] = xx[6] * xx[21];
  xx[12] = xx[7] * xx[22] + xx[6] * xx[25];
  xx[40] = xx[5];
  xx[41] = - xx[11];
  xx[42] = - xx[12];
  pm_math_cross3(xx + 29, xx + 40, xx + 43);
  xx[29] = xx[16] * (xx[43] - xx[5] * xx[2]) - xx[6];
  xx[30] = xx[16] * (xx[11] * xx[2] + xx[44]) - xx[7];
  xx[31] = xx[16] * (xx[12] * xx[2] + xx[45]);
  pm_math_quatXform(xx + 17, xx + 29, xx + 40);
  xx[2] = xx[16] * (xx[3] * xx[33] + xx[39]) + xx[42];
  xx[17] = xx[16] * (xx[37] - xx[1] * xx[33]) + xx[40] + xx[6];
  xx[18] = xx[16] * (xx[6] * xx[33] * xx[36] + xx[38]) + xx[41] + xx[7];
  xx[19] = xx[2];
  J[0] = xx[23];
  J[1] = xx[27];
  J[3] = xx[24];
  J[4] = xx[28];
  J[6] = pm_math_dot3(xx + 8, xx + 13);
  J[7] = pm_math_dot3(xx + 17, xx + 13);
  J[9] = xx[4];
  J[10] = xx[2];
  return 4;
}

static size_t computeAssemblyJacobian_1v(const double *rtdv, const double *state,
  const double *motionData, double *J)
{
  double xx[69];
  (void) rtdv;
  xx[0] = 6.240732392112002e-18;
  xx[1] = 2.0;
  xx[2] = motionData[22];
  xx[3] = motionData[23];
  xx[4] = motionData[24];
  xx[5] = 4.336171384355309e-17;
  xx[6] = xx[5] * motionData[24];
  xx[7] = xx[5] * motionData[22] + xx[0] * motionData[23];
  xx[8] = xx[6];
  xx[9] = xx[0] * motionData[24];
  xx[10] = - xx[7];
  pm_math_cross3(xx + 2, xx + 8, xx + 11);
  xx[2] = xx[0] + xx[1] * (xx[11] + xx[6] * motionData[21]) + motionData[25];
  xx[14] = 0.9775690487425092;
  xx[15] = 3.533241901317298e-3;
  xx[16] = - 7.584927208271003e-4;
  xx[17] = 0.2105841775422004;
  xx[3] = 0.5;
  xx[4] = xx[3] * state[0];
  xx[6] = 2.971047694847219e-3;
  xx[8] = sin(xx[4]);
  xx[9] = 6.588522717321608e-3;
  xx[10] = 0.9999738817809185;
  xx[18] = cos(xx[4]);
  xx[19] = xx[6] * xx[8];
  xx[20] = xx[9] * xx[8];
  xx[21] = xx[10] * xx[8];
  pm_math_quatCompose(xx + 14, xx + 18, xx + 22);
  xx[14] = motionData[7];
  xx[15] = motionData[8];
  xx[16] = motionData[9];
  xx[17] = motionData[10];
  pm_math_quatCompose(xx + 22, xx + 14, xx + 18);
  xx[26] = xx[6];
  xx[27] = xx[9];
  xx[28] = xx[10];
  pm_math_quatInverseXform(xx + 14, xx + 26, xx + 8);
  xx[14] = xx[5] * xx[10];
  xx[15] = xx[0] * xx[10];
  xx[16] = - (xx[5] * xx[8] + xx[0] * xx[9]);
  pm_math_quatXform(xx + 18, xx + 14, xx + 29);
  xx[14] = motionData[11];
  xx[15] = motionData[12];
  xx[16] = motionData[13];
  pm_math_cross3(xx + 26, xx + 14, xx + 32);
  pm_math_quatXform(xx + 22, xx + 32, xx + 14);
  xx[26] = 9.769655003657077e-3;
  xx[27] = 0.09968416567382769;
  xx[28] = - 6.85815413354548e-4;
  pm_math_quatXform(xx + 22, xx + 26, xx + 32);
  xx[4] = xx[30] + xx[15] + xx[33];
  xx[6] = xx[1] * (xx[0] * motionData[21] * motionData[24] + xx[12]) - xx[5] +
    motionData[26];
  xx[17] = xx[29] + xx[14] + xx[32];
  xx[22] = xx[2] * xx[2] + xx[6] * xx[6];
  xx[23] = 2.250000000000001e-4;
  xx[24] = xx[22];
  if (xx[23] > xx[24])
    xx[24] = xx[23];
  xx[25] = xx[24] == 0.0 ? 0.0 : (xx[2] * xx[4] - xx[6] * xx[17]) / xx[24];
  xx[11] = xx[1] * (xx[13] - xx[7] * motionData[21]) + motionData[27];
  xx[26] = xx[2];
  xx[27] = xx[6];
  xx[28] = xx[11];
  xx[7] = 1.0;
  xx[12] = 0.9985915472931449;
  xx[13] = 0.05305583544420572;
  xx[35] = xx[12] * motionData[23] - xx[13] * motionData[22];
  xx[36] = xx[13] * motionData[21] + xx[12] * motionData[24];
  xx[37] = xx[36] * xx[36];
  xx[38] = xx[12] * motionData[21] - xx[13] * motionData[24];
  xx[39] = xx[38] * xx[36];
  xx[40] = xx[12] * motionData[22] + xx[13] * motionData[23];
  xx[41] = xx[35] * xx[40];
  xx[42] = xx[7] - xx[1] * (xx[35] * xx[35] + xx[37]);
  xx[43] = xx[1] * (xx[39] + xx[41]);
  xx[44] = xx[1] * (xx[40] * xx[36] - xx[35] * xx[38]);
  xx[45] = pm_math_dot3(xx + 26, xx + 42);
  xx[14] = xx[31] + xx[16] + xx[34];
  xx[29] = xx[17];
  xx[30] = xx[4];
  xx[31] = xx[14];
  xx[15] = xx[1] * (xx[41] - xx[39]);
  xx[16] = xx[7] - xx[1] * (xx[37] + xx[40] * xx[40]);
  xx[17] = xx[1] * (xx[38] * xx[40] + xx[35] * xx[36]);
  xx[4] = 0.9943701566506347;
  xx[32] = xx[4] * xx[10];
  xx[33] = 0.1059622176183197;
  xx[34] = - (xx[33] * xx[10]);
  xx[46] = - xx[32];
  xx[47] = xx[34];
  xx[48] = xx[4] * xx[8] + xx[33] * xx[9];
  pm_math_quatXform(xx + 18, xx + 46, xx + 49);
  xx[37] = pm_math_dot3(xx + 26, xx + 15);
  xx[46] = xx[34];
  xx[47] = xx[32];
  xx[48] = xx[33] * xx[8] - xx[4] * xx[9];
  pm_math_quatXform(xx + 18, xx + 46, xx + 52);
  xx[18] = xx[45] * xx[45] + xx[37] * xx[37];
  if (xx[23] > xx[18])
    xx[18] = xx[23];
  xx[19] = xx[18] == 0.0 ? 0.0 : (xx[45] * (pm_math_dot3(xx + 29, xx + 15) +
    pm_math_dot3(xx + 26, xx + 49)) - xx[37] * (pm_math_dot3(xx + 29, xx + 42) +
    pm_math_dot3(xx + 26, xx + 52))) / xx[18];
  xx[46] = motionData[0];
  xx[47] = motionData[1];
  xx[48] = motionData[2];
  xx[49] = motionData[3];
  xx[20] = 0.9650194694988377;
  xx[21] = xx[3] * state[2];
  xx[23] = cos(xx[21]);
  xx[32] = 0.2621533222727515;
  xx[34] = sin(xx[21]);
  xx[21] = xx[20] * xx[23] + xx[32] * xx[34];
  xx[39] = 3.568507962179244e-3;
  xx[41] = 5.699653188004584e-4;
  xx[50] = xx[39] * xx[23] - xx[41] * xx[34];
  xx[51] = xx[41] * xx[23] + xx[39] * xx[34];
  xx[39] = - xx[51];
  xx[41] = xx[32] * xx[23] - xx[20] * xx[34];
  xx[52] = - xx[21];
  xx[53] = xx[50];
  xx[54] = xx[39];
  xx[55] = xx[41];
  pm_math_quatCompose(xx + 46, xx + 52, xx + 56);
  xx[20] = xx[56] * xx[59];
  xx[23] = xx[0] * xx[59];
  xx[32] = xx[0] * xx[57] - xx[5] * xx[58];
  xx[52] = - xx[23];
  xx[53] = xx[5] * xx[59];
  xx[54] = xx[32];
  pm_math_cross3(xx + 57, xx + 52, xx + 60);
  xx[52] = xx[50];
  xx[53] = xx[39];
  xx[54] = xx[41];
  xx[34] = xx[0] * xx[41];
  xx[39] = xx[5] * xx[41];
  xx[41] = xx[0] * xx[50] + xx[5] * xx[51];
  xx[63] = xx[34];
  xx[64] = - xx[39];
  xx[65] = - xx[41];
  pm_math_cross3(xx + 52, xx + 63, xx + 66);
  xx[50] = xx[1] * (xx[66] - xx[34] * xx[21]) - xx[5];
  xx[51] = xx[1] * (xx[39] * xx[21] + xx[67]) - xx[0];
  xx[52] = xx[1] * (xx[21] * xx[41] + xx[68]);
  pm_math_quatXform(xx + 46, xx + 50, xx + 53);
  xx[21] = xx[0] + xx[1] * (xx[5] * xx[20] + xx[61]) + xx[54];
  xx[0] = xx[5] + xx[1] * (xx[60] - xx[23] * xx[56]) + xx[53];
  xx[5] = xx[24] == 0.0 ? 0.0 : (xx[2] * xx[21] - xx[6] * xx[0]) / xx[24];
  xx[23] = xx[1] * (xx[32] * xx[56] + xx[62]) + xx[55];
  xx[46] = xx[0];
  xx[47] = xx[21];
  xx[48] = xx[23];
  xx[0] = xx[33] * xx[59];
  xx[21] = xx[4] * xx[59];
  xx[24] = - xx[21];
  xx[32] = xx[4] * xx[58] - xx[33] * xx[57];
  xx[49] = xx[0];
  xx[50] = xx[24];
  xx[51] = xx[32];
  pm_math_cross3(xx + 57, xx + 49, xx + 52);
  xx[49] = xx[1] * (xx[52] + xx[0] * xx[56]) - xx[4];
  xx[50] = xx[1] * (xx[53] - xx[4] * xx[20]) - xx[33];
  xx[51] = xx[1] * (xx[32] * xx[56] + xx[54]);
  xx[32] = xx[4] * xx[57] + xx[33] * xx[58];
  xx[52] = xx[24];
  xx[53] = - xx[0];
  xx[54] = xx[32];
  pm_math_cross3(xx + 57, xx + 52, xx + 60);
  xx[52] = xx[1] * (xx[60] - xx[21] * xx[56]) - xx[33];
  xx[53] = xx[4] + xx[1] * (xx[61] - xx[33] * xx[20]);
  xx[54] = xx[1] * (xx[32] * xx[56] + xx[62]);
  xx[0] = xx[18] == 0.0 ? 0.0 : (xx[45] * (pm_math_dot3(xx + 46, xx + 15) +
    pm_math_dot3(xx + 26, xx + 49)) - xx[37] * (pm_math_dot3(xx + 46, xx + 42) +
    pm_math_dot3(xx + 26, xx + 52))) / xx[18];
  xx[4] = 0.0;
  xx[15] = - xx[38];
  xx[16] = - xx[40];
  xx[17] = - xx[35];
  xx[18] = - xx[36];
  xx[20] = xx[13] * xx[8];
  xx[21] = xx[13] * xx[9];
  xx[26] = xx[8] - xx[1] * (xx[13] * xx[20] - xx[12] * xx[21]);
  xx[27] = xx[9] - xx[1] * (xx[12] * xx[20] + xx[13] * xx[21]);
  xx[28] = xx[10];
  pm_math_quatDeriv(xx + 15, xx + 26, xx + 32);
  xx[1] = 0.0;
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[10] = xx[7];
  pm_math_quatDeriv(xx + 15, xx + 8, xx + 36);
  xx[1] = sqrt(xx[22] + xx[11] * xx[11]);
  xx[7] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[2] = xx[1] == 0.0 ? 0.0 : xx[6] / xx[1];
  xx[6] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[8] = xx[7];
  xx[9] = xx[2];
  xx[10] = xx[6];
  J[0] = xx[25] + xx[3] * xx[19];
  J[1] = xx[5] + xx[3] * xx[0];
  J[3] = xx[33];
  J[4] = xx[37];
  J[6] = xx[34];
  J[7] = xx[38];
  J[9] = pm_math_dot3(xx + 29, xx + 8);
  J[10] = pm_math_dot3(xx + 46, xx + 8);
  J[12] = xx[14];
  J[13] = xx[23];
  return 5;
}

size_t sm_cardan_gear_ffe27655_1_computeAssemblyJacobian(const void *mech, const
  double *rtdv, size_t constraintIdx, boolean_T forVelocitySatisfaction, const
  double *state, const double *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
   case 0:
    return forVelocitySatisfaction ? computeAssemblyJacobian_0v(rtdv, state,
      motionData, J) : computeAssemblyJacobian_0p(rtdv, state, motionData, J);

   case 1:
    return forVelocitySatisfaction ? computeAssemblyJacobian_1v(rtdv, state,
      motionData, J) : computeAssemblyJacobian_1p(rtdv, state, motionData, J);
  }

  return 0;
}

size_t sm_cardan_gear_ffe27655_1_computeFullAssemblyJacobian(const void *mech,
  const double *rtdv, const double *state, const double *motionData, double *J)
{
  double xx[90];
  (void) mech;
  (void) rtdv;
  xx[0] = 0.0;
  xx[1] = 2.0;
  xx[2] = motionData[15];
  xx[3] = motionData[16];
  xx[4] = motionData[17];
  xx[5] = 7.034264913192121e-3;
  xx[6] = 0.03468999503471949;
  xx[7] = xx[6] * motionData[17] + xx[5] * motionData[15];
  xx[8] = xx[6] * motionData[16];
  xx[9] = - (xx[5] * motionData[16]);
  xx[10] = xx[7];
  xx[11] = - xx[8];
  pm_math_cross3(xx + 2, xx + 9, xx + 12);
  xx[2] = motionData[8];
  xx[3] = motionData[9];
  xx[4] = motionData[10];
  xx[9] = 4.336171384355309e-17;
  xx[10] = xx[9] * motionData[10];
  xx[11] = 6.240732392112002e-18;
  xx[15] = xx[9] * motionData[8] + xx[11] * motionData[9];
  xx[16] = xx[10];
  xx[17] = xx[11] * motionData[10];
  xx[18] = - xx[15];
  pm_math_cross3(xx + 2, xx + 16, xx + 19);
  xx[2] = xx[1] * (xx[12] - xx[5] * motionData[14] * motionData[16]) +
    motionData[18] + xx[6] - (xx[1] * (xx[19] + xx[10] * motionData[7]) +
    motionData[11] + xx[11]);
  xx[3] = xx[1] * (xx[7] * motionData[14] + xx[13]) + motionData[19] - (xx[1] *
    (xx[11] * motionData[7] * motionData[10] + xx[20]) + motionData[12] - xx[9]);
  xx[4] = xx[1] * (xx[14] - xx[8] * motionData[14]) + motionData[20] - xx[5] -
    (xx[1] * (xx[21] - xx[15] * motionData[7]) + motionData[13]);
  xx[5] = 1.0;
  xx[6] = 0.9985915472931449;
  xx[7] = 0.05305583544420572;
  xx[8] = xx[6] * motionData[9] - xx[7] * motionData[8];
  xx[10] = xx[8] * xx[8];
  xx[12] = xx[7] * motionData[7] + xx[6] * motionData[10];
  xx[13] = xx[12] * xx[12];
  xx[14] = xx[6] * motionData[7] - xx[7] * motionData[10];
  xx[15] = xx[14] * xx[12];
  xx[16] = xx[6] * motionData[8] + xx[7] * motionData[9];
  xx[17] = xx[8] * xx[16];
  xx[18] = xx[12] * xx[16];
  xx[19] = xx[8] * xx[14];
  xx[20] = xx[5] - xx[1] * (xx[10] + xx[13]);
  xx[21] = xx[1] * (xx[15] + xx[17]);
  xx[22] = xx[1] * (xx[18] - xx[19]);
  xx[23] = pm_math_dot3(xx + 2, xx + 20);
  xx[24] = 3.568507962179244e-3;
  xx[25] = 0.5;
  xx[26] = xx[25] * state[2];
  xx[27] = cos(xx[26]);
  xx[28] = 5.699653188004584e-4;
  xx[29] = sin(xx[26]);
  xx[26] = xx[24] * xx[27] - xx[28] * xx[29];
  xx[30] = xx[28] * xx[27] + xx[24] * xx[29];
  xx[24] = - xx[30];
  xx[28] = 0.2621533222727515;
  xx[31] = 0.9650194694988377;
  xx[32] = xx[28] * xx[27] - xx[31] * xx[29];
  xx[33] = xx[26];
  xx[34] = xx[24];
  xx[35] = xx[32];
  xx[36] = 0.1059622176183197;
  xx[37] = xx[36] * xx[32];
  xx[38] = 0.9943701566506347;
  xx[39] = xx[38] * xx[32];
  xx[40] = - xx[39];
  xx[41] = xx[36] * xx[26] + xx[38] * xx[30];
  xx[42] = xx[37];
  xx[43] = xx[40];
  xx[44] = - xx[41];
  pm_math_cross3(xx + 33, xx + 42, xx + 45);
  xx[42] = xx[31] * xx[27] + xx[28] * xx[29];
  xx[27] = xx[37] * xx[42];
  xx[28] = xx[39] * xx[42];
  xx[48] = xx[1] * (xx[45] - xx[27]) - xx[38];
  xx[49] = xx[1] * (xx[28] + xx[46]) - xx[36];
  xx[50] = xx[1] * (xx[41] * xx[42] + xx[47]);
  xx[29] = xx[11] * xx[32];
  xx[31] = xx[9] * xx[32];
  xx[39] = xx[11] * xx[26];
  xx[41] = xx[9] * xx[30];
  xx[43] = xx[39] + xx[41];
  xx[44] = - xx[29];
  xx[45] = xx[31];
  xx[46] = xx[43];
  pm_math_cross3(xx + 33, xx + 44, xx + 51);
  xx[44] = xx[29] * xx[42];
  xx[45] = xx[39] + xx[41];
  xx[54] = xx[29];
  xx[55] = - xx[31];
  xx[56] = - xx[45];
  pm_math_cross3(xx + 33, xx + 54, xx + 57);
  xx[29] = xx[1] * (xx[57] - xx[44]) - xx[9];
  xx[39] = xx[31] * xx[42];
  xx[31] = xx[1] * (xx[39] + xx[58]) - xx[11];
  xx[41] = xx[1] * (xx[42] * xx[45] + xx[59]);
  xx[45] = xx[9] + xx[1] * (xx[51] + xx[44]) + xx[29];
  xx[46] = xx[11] + xx[1] * (xx[52] - xx[39]) + xx[31];
  xx[47] = xx[1] * (xx[53] - xx[43] * xx[42]) + xx[41];
  xx[39] = xx[16] * xx[16];
  xx[43] = xx[14] * xx[16];
  xx[44] = xx[8] * xx[12];
  xx[51] = xx[1] * (xx[17] - xx[15]);
  xx[52] = xx[5] - xx[1] * (xx[13] + xx[39]);
  xx[53] = xx[1] * (xx[43] + xx[44]);
  xx[13] = pm_math_dot3(xx + 2, xx + 51);
  xx[15] = xx[38] * xx[26] - xx[36] * xx[30];
  xx[54] = xx[40];
  xx[55] = - xx[37];
  xx[56] = xx[15];
  pm_math_cross3(xx + 33, xx + 54, xx + 57);
  xx[33] = xx[1] * (xx[57] + xx[28]) - xx[36];
  xx[34] = xx[38] + xx[1] * (xx[27] + xx[58]);
  xx[35] = xx[1] * (xx[59] - xx[42] * xx[15]);
  xx[15] = 1.0e-4;
  xx[17] = xx[23] * xx[23] + xx[13] * xx[13];
  if (xx[15] > xx[17])
    xx[17] = xx[15];
  xx[27] = xx[17] == 0.0 ? 0.0 : (xx[23] * (pm_math_dot3(xx + 2, xx + 48) -
    pm_math_dot3(xx + 45, xx + 51)) - xx[13] * (pm_math_dot3(xx + 2, xx + 33) -
    pm_math_dot3(xx + 45, xx + 20))) / xx[17];
  xx[54] = motionData[14];
  xx[55] = motionData[15];
  xx[56] = motionData[16];
  xx[57] = motionData[17];
  xx[58] = - 0.9530551403624588;
  xx[59] = 0.02658750541312705;
  xx[60] = 0.08781256514654519;
  xx[61] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 54, xx + 58, xx + 62);
  xx[28] = xx[65] * xx[65];
  xx[30] = xx[62] * xx[65];
  xx[33] = xx[63] * xx[64];
  xx[48] = xx[5] - xx[1] * (xx[64] * xx[64] + xx[28]);
  xx[49] = xx[1] * (xx[30] + xx[33]);
  xx[50] = xx[1] * (xx[63] * xx[65] - xx[62] * xx[64]);
  xx[54] = xx[1] * (xx[33] - xx[30]);
  xx[55] = xx[5] - xx[1] * (xx[28] + xx[63] * xx[63]);
  xx[56] = xx[1] * (xx[62] * xx[63] + xx[64] * xx[65]);
  xx[28] = pm_math_dot3(xx + 2, xx + 54);
  xx[30] = pm_math_dot3(xx + 2, xx + 48);
  xx[33] = xx[30] * xx[30] + xx[28] * xx[28];
  if (xx[15] > xx[33])
    xx[33] = xx[15];
  xx[15] = xx[33] == 0.0 ? 0.0 : (pm_math_dot3(xx + 45, xx + 48) * xx[28] -
    pm_math_dot3(xx + 45, xx + 54) * xx[30]) / xx[33];
  xx[34] = 0.03282062425369642;
  xx[35] = 0.04089681274430031;
  xx[37] = xx[25] * state[4];
  xx[40] = cos(xx[37]);
  xx[57] = 0.8709379761288196;
  xx[58] = sin(xx[37]);
  xx[37] = 0.182724714184937 * xx[58];
  xx[59] = 0.07994726428595826;
  xx[60] = 0.9831641159165814 * xx[58];
  xx[58] = xx[35] * xx[40] - xx[57] * xx[37] + xx[59] * xx[60];
  xx[61] = xx[34] * xx[58];
  xx[66] = 0.4831179228482263;
  xx[67] = xx[59] * xx[40] + xx[66] * xx[37] - xx[35] * xx[60];
  xx[68] = xx[57] * xx[60] - xx[66] * xx[40] + xx[59] * xx[37];
  xx[59] = xx[34] * xx[68];
  xx[69] = xx[57] * xx[40] + xx[35] * xx[37] + xx[66] * xx[60];
  xx[35] = 0.03282062425369643;
  xx[37] = xx[35] * xx[68];
  xx[40] = xx[35] * xx[58];
  xx[70] = xx[1] * (xx[61] * xx[67] - xx[59] * xx[69]) + xx[1] * (xx[37] * xx[69]
    - xx[40] * xx[67]);
  xx[71] = xx[34] - xx[1] * (xx[59] * xx[68] + xx[61] * xx[58]) + xx[1] * (xx[37]
    * xx[68] + xx[40] * xx[58]) - xx[35];
  xx[72] = xx[1] * (xx[61] * xx[69] + xx[59] * xx[67]) - xx[1] * (xx[40] * xx[69]
    + xx[37] * xx[67]);
  xx[34] = xx[17] == 0.0 ? 0.0 : (pm_math_dot3(xx + 70, xx + 51) * xx[23] -
    pm_math_dot3(xx + 70, xx + 20) * xx[13]) / xx[17];
  xx[20] = xx[69];
  xx[21] = xx[58];
  xx[22] = xx[67];
  xx[23] = xx[68];
  xx[51] = - 0.818041992030798;
  xx[52] = - 0.5547001962252291;
  xx[53] = - 0.1520361522203753;
  pm_math_quatXform(xx + 20, xx + 51, xx + 57);
  xx[51] = - 0.5453613280205316;
  xx[52] = 0.8320502943378444;
  xx[53] = - 0.1013574348135835;
  pm_math_quatXform(xx + 20, xx + 51, xx + 66);
  xx[13] = xx[33] == 0.0 ? 0.0 : (xx[30] * (pm_math_dot3(xx + 70, xx + 54) +
    pm_math_dot3(xx + 2, xx + 57)) - xx[28] * (pm_math_dot3(xx + 70, xx + 48) +
    pm_math_dot3(xx + 2, xx + 66))) / xx[33];
  xx[20] = xx[14];
  xx[21] = xx[16];
  xx[22] = xx[8];
  xx[23] = xx[12];
  pm_math_quatInverseCompose(xx + 20, xx + 62, xx + 48);
  xx[20] = xx[1] * (motionData[7] * motionData[9] + motionData[8] * motionData
                    [10]);
  xx[21] = xx[1] * (motionData[9] * motionData[10] - motionData[7] * motionData
                    [8]);
  xx[22] = xx[5] - xx[1] * (motionData[8] * motionData[8] + motionData[9] *
    motionData[9]);
  pm_math_quatInverseXform(xx + 62, xx + 20, xx + 52);
  xx[20] = - xx[52];
  xx[21] = - xx[53];
  xx[22] = - xx[54];
  pm_math_quatDeriv(xx + 48, xx + 20, xx + 52);
  xx[20] = 5.273559366969494e-16;
  xx[21] = 8.118505867571457e-16;
  xx[22] = xx[5];
  pm_math_quatDeriv(xx + 48, xx + 20, xx + 56);
  xx[8] = sqrt(xx[2] * xx[2] + xx[3] * xx[3] + xx[4] * xx[4]);
  xx[12] = xx[8] == 0.0 ? 0.0 : xx[2] / xx[8];
  xx[2] = xx[8] == 0.0 ? 0.0 : xx[3] / xx[8];
  xx[3] = xx[8] == 0.0 ? 0.0 : xx[4] / xx[8];
  xx[20] = xx[12];
  xx[21] = xx[2];
  xx[22] = xx[3];
  xx[2] = xx[1] * (xx[19] + xx[18]);
  xx[3] = xx[1] * (xx[44] - xx[43]);
  xx[4] = xx[5] - xx[1] * (xx[39] + xx[10]);
  xx[16] = 0.9775690487425092;
  xx[17] = 3.533241901317298e-3;
  xx[18] = - 7.584927208271003e-4;
  xx[19] = 0.2105841775422004;
  xx[8] = xx[25] * state[0];
  xx[10] = 2.971047694847219e-3;
  xx[12] = sin(xx[8]);
  xx[14] = 6.588522717321608e-3;
  xx[23] = 0.9999738817809185;
  xx[48] = cos(xx[8]);
  xx[49] = xx[10] * xx[12];
  xx[50] = xx[14] * xx[12];
  xx[51] = xx[23] * xx[12];
  pm_math_quatCompose(xx + 16, xx + 48, xx + 59);
  xx[16] = motionData[7];
  xx[17] = motionData[8];
  xx[18] = motionData[9];
  xx[19] = motionData[10];
  pm_math_quatCompose(xx + 59, xx + 16, xx + 48);
  xx[63] = xx[10];
  xx[64] = xx[14];
  xx[65] = xx[23];
  pm_math_quatInverseXform(xx + 16, xx + 63, xx + 66);
  xx[16] = xx[9] * xx[68];
  xx[17] = xx[11] * xx[68];
  xx[18] = - (xx[9] * xx[66] + xx[11] * xx[67]);
  pm_math_quatXform(xx + 48, xx + 16, xx + 73);
  xx[16] = motionData[11];
  xx[17] = motionData[12];
  xx[18] = motionData[13];
  pm_math_cross3(xx + 63, xx + 16, xx + 76);
  pm_math_quatXform(xx + 59, xx + 76, xx + 16);
  xx[63] = 9.769655003657077e-3;
  xx[64] = 0.09968416567382769;
  xx[65] = - 6.85815413354548e-4;
  pm_math_quatXform(xx + 59, xx + 63, xx + 76);
  xx[8] = xx[74] + xx[17] + xx[77];
  xx[59] = motionData[22];
  xx[60] = motionData[23];
  xx[61] = motionData[24];
  xx[10] = xx[9] * motionData[24];
  xx[12] = xx[9] * motionData[22] + xx[11] * motionData[23];
  xx[62] = xx[10];
  xx[63] = xx[11] * motionData[24];
  xx[64] = - xx[12];
  pm_math_cross3(xx + 59, xx + 62, xx + 79);
  xx[14] = xx[11] + xx[1] * (xx[79] + xx[10] * motionData[21]) + motionData[25];
  xx[10] = xx[73] + xx[16] + xx[76];
  xx[19] = xx[1] * (xx[11] * motionData[21] * motionData[24] + xx[80]) - xx[9] +
    motionData[26];
  xx[23] = xx[14] * xx[14] + xx[19] * xx[19];
  xx[28] = 2.250000000000001e-4;
  xx[30] = xx[23];
  if (xx[28] > xx[30])
    xx[30] = xx[28];
  xx[33] = xx[30] == 0.0 ? 0.0 : (xx[8] * xx[14] - xx[10] * xx[19]) / xx[30];
  xx[35] = xx[1] * (xx[81] - xx[12] * motionData[21]) + motionData[27];
  xx[59] = xx[14];
  xx[60] = xx[19];
  xx[61] = xx[35];
  xx[12] = xx[6] * motionData[23] - xx[7] * motionData[22];
  xx[37] = xx[7] * motionData[21] + xx[6] * motionData[24];
  xx[39] = xx[37] * xx[37];
  xx[40] = xx[6] * motionData[21] - xx[7] * motionData[24];
  xx[43] = xx[40] * xx[37];
  xx[44] = xx[6] * motionData[22] + xx[7] * motionData[23];
  xx[52] = xx[12] * xx[44];
  xx[62] = xx[5] - xx[1] * (xx[12] * xx[12] + xx[39]);
  xx[63] = xx[1] * (xx[43] + xx[52]);
  xx[64] = xx[1] * (xx[44] * xx[37] - xx[12] * xx[40]);
  xx[55] = pm_math_dot3(xx + 59, xx + 62);
  xx[16] = xx[75] + xx[18] + xx[78];
  xx[73] = xx[10];
  xx[74] = xx[8];
  xx[75] = xx[16];
  xx[76] = xx[1] * (xx[52] - xx[43]);
  xx[77] = xx[5] - xx[1] * (xx[39] + xx[44] * xx[44]);
  xx[78] = xx[1] * (xx[40] * xx[44] + xx[12] * xx[37]);
  xx[8] = xx[38] * xx[68];
  xx[10] = - (xx[36] * xx[68]);
  xx[79] = - xx[8];
  xx[80] = xx[10];
  xx[81] = xx[38] * xx[66] + xx[36] * xx[67];
  pm_math_quatXform(xx + 48, xx + 79, xx + 82);
  xx[17] = pm_math_dot3(xx + 59, xx + 76);
  xx[79] = xx[10];
  xx[80] = xx[8];
  xx[81] = xx[36] * xx[66] - xx[38] * xx[67];
  pm_math_quatXform(xx + 48, xx + 79, xx + 85);
  xx[8] = xx[55] * xx[55] + xx[17] * xx[17];
  if (xx[28] > xx[8])
    xx[8] = xx[28];
  xx[10] = xx[8] == 0.0 ? 0.0 : (xx[55] * (pm_math_dot3(xx + 73, xx + 76) +
    pm_math_dot3(xx + 59, xx + 82)) - xx[17] * (pm_math_dot3(xx + 73, xx + 62) +
    pm_math_dot3(xx + 59, xx + 85))) / xx[8];
  xx[48] = motionData[0];
  xx[49] = motionData[1];
  xx[50] = motionData[2];
  xx[51] = motionData[3];
  xx[79] = - xx[42];
  xx[80] = xx[26];
  xx[81] = xx[24];
  xx[82] = xx[32];
  pm_math_quatCompose(xx + 48, xx + 79, xx + 83);
  xx[18] = xx[83] * xx[86];
  xx[24] = xx[11] * xx[86];
  xx[26] = xx[11] * xx[84] - xx[9] * xx[85];
  xx[79] = - xx[24];
  xx[80] = xx[9] * xx[86];
  xx[81] = xx[26];
  pm_math_cross3(xx + 84, xx + 79, xx + 87);
  xx[79] = xx[29];
  xx[80] = xx[31];
  xx[81] = xx[41];
  pm_math_quatXform(xx + 48, xx + 79, xx + 41);
  xx[28] = xx[11] + xx[1] * (xx[9] * xx[18] + xx[88]) + xx[42];
  xx[11] = xx[9] + xx[1] * (xx[87] - xx[24] * xx[83]) + xx[41];
  xx[9] = xx[30] == 0.0 ? 0.0 : (xx[28] * xx[14] - xx[11] * xx[19]) / xx[30];
  xx[24] = xx[1] * (xx[26] * xx[83] + xx[89]) + xx[43];
  xx[29] = xx[11];
  xx[30] = xx[28];
  xx[31] = xx[24];
  xx[11] = xx[36] * xx[86];
  xx[26] = xx[38] * xx[86];
  xx[28] = - xx[26];
  xx[32] = xx[38] * xx[85] - xx[36] * xx[84];
  xx[41] = xx[11];
  xx[42] = xx[28];
  xx[43] = xx[32];
  pm_math_cross3(xx + 84, xx + 41, xx + 48);
  xx[41] = xx[1] * (xx[48] + xx[11] * xx[83]) - xx[38];
  xx[42] = xx[1] * (xx[49] - xx[38] * xx[18]) - xx[36];
  xx[43] = xx[1] * (xx[32] * xx[83] + xx[50]);
  xx[32] = xx[38] * xx[84] + xx[36] * xx[85];
  xx[48] = xx[28];
  xx[49] = - xx[11];
  xx[50] = xx[32];
  pm_math_cross3(xx + 84, xx + 48, xx + 79);
  xx[48] = xx[1] * (xx[79] - xx[26] * xx[83]) - xx[36];
  xx[49] = xx[38] + xx[1] * (xx[80] - xx[36] * xx[18]);
  xx[50] = xx[1] * (xx[32] * xx[83] + xx[81]);
  xx[11] = xx[8] == 0.0 ? 0.0 : (xx[55] * (pm_math_dot3(xx + 29, xx + 76) +
    pm_math_dot3(xx + 59, xx + 41)) - xx[17] * (pm_math_dot3(xx + 29, xx + 62) +
    pm_math_dot3(xx + 59, xx + 48))) / xx[8];
  xx[48] = - xx[40];
  xx[49] = - xx[44];
  xx[50] = - xx[12];
  xx[51] = - xx[37];
  xx[8] = xx[7] * xx[66];
  xx[12] = xx[7] * xx[67];
  xx[36] = xx[66] - xx[1] * (xx[7] * xx[8] - xx[6] * xx[12]);
  xx[37] = xx[67] - xx[1] * (xx[6] * xx[8] + xx[7] * xx[12]);
  xx[38] = xx[68];
  pm_math_quatDeriv(xx + 48, xx + 36, xx + 39);
  xx[1] = 0.0;
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  pm_math_quatDeriv(xx + 48, xx + 6, xx + 59);
  xx[1] = sqrt(xx[23] + xx[35] * xx[35]);
  xx[5] = xx[1] == 0.0 ? 0.0 : xx[14] / xx[1];
  xx[6] = xx[1] == 0.0 ? 0.0 : xx[19] / xx[1];
  xx[7] = xx[1] == 0.0 ? 0.0 : xx[35] / xx[1];
  J[1] = xx[27] + xx[15];
  J[2] = xx[34] + xx[13];
  J[4] = xx[53];
  J[5] = xx[57];
  J[7] = xx[54];
  J[8] = xx[58];
  J[10] = - pm_math_dot3(xx + 45, xx + 20);
  J[11] = pm_math_dot3(xx + 70, xx + 20);
  J[13] = - pm_math_dot3(xx + 45, xx + 2);
  J[14] = pm_math_dot3(xx + 70, xx + 2);
  J[15] = xx[33] + xx[25] * xx[10];
  J[16] = xx[9] + xx[25] * xx[11];
  J[18] = xx[40];
  J[19] = xx[60];
  J[21] = xx[41];
  J[22] = xx[61];
  J[24] = pm_math_dot3(xx + 73, xx + 5);
  J[25] = pm_math_dot3(xx + 29, xx + 5);
  J[27] = xx[16];
  J[28] = xx[24];
  return 10;
}

static int isInKinematicSingularity_0(const double *rtdv, const double
  *motionData)
{
  (void) rtdv;
  (void) motionData;
  return 0;
}

static int isInKinematicSingularity_1(const double *rtdv, const double
  *motionData)
{
  (void) rtdv;
  (void) motionData;
  return 0;
}

int sm_cardan_gear_ffe27655_1_isInKinematicSingularity(const void *mech, const
  double *rtdv, size_t constraintIdx, const double *motionData)
{
  (void) mech;
  (void) rtdv
    ;
  (void) motionData;
  switch (constraintIdx)
  {
   case 0:
    return isInKinematicSingularity_0(rtdv, motionData);

   case 1:
    return isInKinematicSingularity_1(rtdv, motionData);
  }

  return 0;
}

PmfMessageId sm_cardan_gear_ffe27655_1_convertStateVector(const void *asmMech,
  const double *rtdv, const void *simMech, const double *asmState, double
  *simState, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) asmMech;
  (void) rtdv;
  (void) simMech;
  (void) neDiagMgr;
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  simState[2] = asmState[2];
  simState[3] = asmState[3];
  simState[4] = asmState[4];
  simState[5] = asmState[5];
  simState[6] = asmState[6];
  simState[7] = asmState[7];
  simState[8] = asmState[8];
  simState[9] = asmState[9];
  simState[10] = asmState[10];
  simState[11] = asmState[11];
  return NULL;
}

void sm_cardan_gear_ffe27655_1_constructStateVector(const void *mech, const
  double *solverState, const double *u, const double *uDot, double
  *discreteState, double *fullState)
{
  (void) mech;
  (void) u;
  (void) uDot;
  fullState[0] = solverState[0];
  fullState[1] = solverState[1];
  fullState[2] = solverState[2];
  fullState[3] = solverState[3];
  fullState[4] = solverState[4];
  fullState[5] = solverState[5];
  fullState[6] = solverState[6];
  fullState[7] = solverState[7];
  fullState[8] = solverState[8];
  fullState[9] = solverState[9];
  fullState[10] = discreteState[0];
  fullState[11] = discreteState[1];
}

void sm_cardan_gear_ffe27655_1_extractSolverStateVector(const void *mech, const
  double *fullState, double *solverState)
{
  (void) mech;
  solverState[0] = fullState[0];
  solverState[1] = fullState[1];
  solverState[2] = fullState[2];
  solverState[3] = fullState[3];
  solverState[4] = fullState[4];
  solverState[5] = fullState[5];
  solverState[6] = fullState[6];
  solverState[7] = fullState[7];
  solverState[8] = fullState[8];
  solverState[9] = fullState[9];
}

int sm_cardan_gear_ffe27655_1_isPositionViolation(const void *mech, const double
  *rtdv, const int *eqnEnableFlags, const double *state)
{
  int ii[3];
  double xx[41];
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  xx[0] = 3.141592653589793;
  xx[1] = 2.0;
  xx[2] = 0.04089681274430031;
  xx[3] = 0.5;
  xx[4] = xx[3] * state[4];
  xx[5] = cos(xx[4]);
  xx[6] = 0.8709379761288196;
  xx[7] = sin(xx[4]);
  xx[4] = 0.182724714184937 * xx[7];
  xx[8] = 0.07994726428595826;
  xx[9] = 0.9831641159165814 * xx[7];
  xx[7] = xx[2] * xx[5] - xx[6] * xx[4] + xx[8] * xx[9];
  xx[10] = 0.4831179228482263;
  xx[11] = xx[8] * xx[5] + xx[10] * xx[4] - xx[2] * xx[9];
  xx[12] = xx[6] * xx[9] - xx[10] * xx[5] + xx[8] * xx[4];
  xx[13] = xx[7];
  xx[14] = xx[11];
  xx[15] = xx[12];
  xx[8] = 7.034264913192121e-3;
  xx[16] = xx[8] * xx[11];
  xx[17] = 0.03468999503471949;
  xx[18] = xx[17] * xx[12] + xx[8] * xx[7];
  xx[8] = xx[17] * xx[11];
  xx[19] = - xx[16];
  xx[20] = xx[18];
  xx[21] = - xx[8];
  pm_math_cross3(xx + 13, xx + 19, xx + 22);
  xx[17] = xx[6] * xx[5] + xx[2] * xx[4] + xx[10] * xx[9];
  xx[2] = 7.713196825556601e-3;
  xx[4] = xx[2] * xx[11];
  xx[5] = 0.03194912432194544;
  xx[6] = xx[5] * xx[12] - xx[2] * xx[7];
  xx[2] = xx[5] * xx[11];
  xx[19] = xx[4];
  xx[20] = xx[6];
  xx[21] = - xx[2];
  pm_math_cross3(xx + 13, xx + 19, xx + 25);
  xx[5] = 3.568507962179244e-3;
  xx[9] = xx[3] * state[2];
  xx[10] = cos(xx[9]);
  xx[13] = 5.699653188004584e-4;
  xx[14] = sin(xx[9]);
  xx[9] = xx[5] * xx[10] - xx[13] * xx[14];
  xx[15] = xx[13] * xx[10] + xx[5] * xx[14];
  xx[5] = - xx[15];
  xx[13] = 0.2621533222727515;
  xx[19] = 0.9650194694988377;
  xx[20] = xx[13] * xx[10] - xx[19] * xx[14];
  xx[28] = xx[9];
  xx[29] = xx[5];
  xx[30] = xx[20];
  xx[21] = 4.336171384355309e-17;
  xx[31] = xx[21] * xx[20];
  xx[32] = 6.240732392112002e-18;
  xx[33] = xx[32] * xx[20];
  xx[34] = xx[32] * xx[15] - xx[21] * xx[9];
  xx[35] = xx[31];
  xx[36] = xx[33];
  xx[37] = xx[34];
  pm_math_cross3(xx + 28, xx + 35, xx + 38);
  xx[28] = xx[19] * xx[10] + xx[13] * xx[14];
  xx[10] = xx[1] * (xx[38] - xx[31] * xx[28]);
  xx[13] = xx[32] + xx[10];
  xx[14] = xx[1] * (xx[39] - xx[33] * xx[28]);
  xx[19] = xx[14] - xx[21];
  xx[29] = xx[1] * (xx[40] - xx[28] * xx[34]);
  xx[30] = 0.01449907368972891;
  xx[33] = xx[1] * (xx[22] - xx[16] * xx[17]) - xx[1] * (xx[4] * xx[17] + xx[25])
    + 0.08092328375554529 - (xx[10] - xx[13] + 0.03696626849097064);
  xx[34] = xx[1] * (xx[18] * xx[17] + xx[23]) - xx[1] * (xx[6] * xx[17] + xx[26])
    + 0.03914259083055165 - (xx[14] - xx[19] - 0.05208460108431659);
  xx[35] = xx[1] * (xx[24] - xx[8] * xx[17]) - xx[1] * (xx[27] - xx[2] * xx[17])
    - 0.01496967009981087 - (xx[29] - xx[29] - xx[30]);
  xx[2] = 0.9985915472931449;
  xx[4] = 0.05305583544420572;
  xx[6] = xx[2] * xx[28] + xx[4] * xx[20];
  xx[8] = xx[2] * xx[20] - xx[4] * xx[28];
  xx[10] = xx[6] * xx[8];
  xx[14] = xx[2] * xx[15] + xx[4] * xx[9];
  xx[16] = xx[2] * xx[9] - xx[4] * xx[15];
  xx[15] = xx[14] * xx[16];
  xx[18] = 1.0;
  xx[22] = xx[8] * xx[8];
  xx[23] = xx[1] * (xx[10] - xx[15]);
  xx[24] = xx[18] - xx[1] * (xx[22] + xx[16] * xx[16]);
  xx[25] = - (xx[1] * (xx[6] * xx[16] + xx[14] * xx[8]));
  xx[36] = xx[18] - xx[1] * (xx[14] * xx[14] + xx[22]);
  xx[37] = - (xx[1] * (xx[10] + xx[15]));
  xx[38] = xx[1] * (xx[16] * xx[8] - xx[14] * xx[6]);
  xx[6] = atan2(pm_math_dot3(xx + 33, xx + 23), pm_math_dot3(xx + 33, xx + 36))
    - state[6];
  xx[8] = (xx[6] < 0.0 ? -1.0 : +1.0);
  xx[10] = 6.283185307179586;
  xx[22] = xx[17];
  xx[23] = xx[7];
  xx[24] = xx[11];
  xx[25] = xx[12];
  xx[14] = - 0.9530551403624588;
  xx[15] = 0.02658750541312705;
  xx[16] = 0.08781256514654519;
  xx[17] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 22, xx + 14, xx + 36);
  xx[7] = xx[37] * xx[38];
  xx[11] = xx[36] * xx[39];
  xx[12] = xx[39] * xx[39];
  xx[14] = xx[1] * (xx[7] - xx[11]);
  xx[15] = xx[18] - xx[1] * (xx[12] + xx[37] * xx[37]);
  xx[16] = xx[1] * (xx[36] * xx[37] + xx[38] * xx[39]);
  xx[22] = xx[18] - xx[1] * (xx[38] * xx[38] + xx[12]);
  xx[23] = xx[1] * (xx[11] + xx[7]);
  xx[24] = xx[1] * (xx[37] * xx[39] - xx[36] * xx[38]);
  xx[7] = state[6] + (fmod(xx[0] + xx[6] * xx[8], xx[10]) - xx[0]) * xx[8] -
    state[10] + atan2(pm_math_dot3(xx + 33, xx + 14), pm_math_dot3(xx + 33, xx +
    22));
  xx[6] = (xx[7] < 0.0 ? -1.0 : +1.0);
  xx[14] = 0.9775690487425092;
  xx[15] = 3.533241901317298e-3;
  xx[16] = - 7.584927208271003e-4;
  xx[17] = 0.2105841775422004;
  xx[8] = xx[3] * state[0];
  xx[11] = sin(xx[8]);
  xx[22] = cos(xx[8]);
  xx[23] = 2.971047694847219e-3 * xx[11];
  xx[24] = 6.588522717321608e-3 * xx[11];
  xx[25] = 0.9999738817809185 * xx[11];
  pm_math_quatCompose(xx + 14, xx + 22, xx + 33);
  xx[14] = - xx[28];
  xx[15] = xx[9];
  xx[16] = xx[5];
  xx[17] = xx[20];
  pm_math_quatCompose(xx + 33, xx + 14, xx + 22);
  xx[5] = xx[21] * xx[25];
  xx[8] = xx[21] * xx[23] + xx[32] * xx[24];
  xx[14] = xx[5];
  xx[15] = xx[32] * xx[25];
  xx[16] = - xx[8];
  pm_math_cross3(xx + 23, xx + 14, xx + 26);
  xx[14] = 0.03696626849097063 - xx[13];
  xx[15] = - (0.05208460108431655 + xx[19]);
  xx[16] = - (xx[30] + xx[29]);
  pm_math_quatXform(xx + 33, xx + 14, xx + 11);
  xx[14] = - 0.09972985016632961;
  xx[15] = 9.674375133208124e-3;
  xx[16] = - 0.01449984343940976;
  pm_math_quatXform(xx + 33, xx + 14, xx + 29);
  xx[9] = xx[1] * (xx[32] * xx[22] * xx[25] + xx[27]) - xx[21] + xx[12] - xx[30];
  xx[14] = xx[32] + xx[1] * (xx[26] + xx[5] * xx[22]) + xx[11] - xx[29];
  xx[5] = atan2(xx[9], xx[14]) - state[8];
  xx[15] = (xx[5] < 0.0 ? -1.0 : +1.0);
  xx[19] = xx[14];
  xx[20] = xx[9];
  xx[21] = xx[1] * (xx[28] - xx[8] * xx[22]) + xx[13] - xx[31];
  xx[8] = xx[2] * xx[24] - xx[4] * xx[23];
  xx[9] = xx[2] * xx[23] + xx[4] * xx[24];
  xx[11] = xx[8] * xx[9];
  xx[12] = xx[2] * xx[22] - xx[4] * xx[25];
  xx[13] = xx[4] * xx[22] + xx[2] * xx[25];
  xx[2] = xx[12] * xx[13];
  xx[4] = xx[13] * xx[13];
  xx[22] = xx[1] * (xx[11] - xx[2]);
  xx[23] = xx[18] - xx[1] * (xx[4] + xx[9] * xx[9]);
  xx[24] = xx[1] * (xx[12] * xx[9] + xx[8] * xx[13]);
  xx[25] = xx[18] - xx[1] * (xx[8] * xx[8] + xx[4]);
  xx[26] = xx[1] * (xx[2] + xx[11]);
  xx[27] = xx[1] * (xx[13] * xx[9] - xx[12] * xx[8]);
  xx[1] = (state[8] + (fmod(xx[0] + xx[5] * xx[15], xx[10]) - xx[0]) * xx[15] -
           state[11]) / xx[3] + atan2(pm_math_dot3(xx + 19, xx + 22),
    pm_math_dot3(xx + 19, xx + 25));
  xx[2] = (xx[1] < 0.0 ? -1.0 : +1.0);
  xx[4] = fabs((fmod(xx[0] + xx[6] * xx[7], xx[10]) - xx[0]) * xx[6]);
  xx[5] = fabs(xx[3] * (fmod(xx[0] + xx[2] * xx[1], xx[10]) - xx[0]) * xx[2]);
  ii[0] = 4;

  {
    int ll;
    for (ll = 5; ll < 6; ++ll)
      if (xx[ll] > xx[ii[0]])
        ii[0] = ll;
  }

  ii[0] -= 4;
  xx[0] = xx[4 + (ii[0])];
  xx[1] = xx[0] - 1.0e-5;
  if (xx[1] < 0.0)
    ii[0] = -1;
  else if (xx[1] > 0.0)
    ii[0] = +1;
  else
    ii[0] = 0;
  ii[1] = ii[0];
  if (0 > ii[1])
    ii[1] = 0;
  return ii[1];
}

int sm_cardan_gear_ffe27655_1_isVelocityViolation(const void *mech, const double
  *rtdv, const int *eqnEnableFlags, const double *state)
{
  int ii[3];
  double xx[66];
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  xx[0] = 2.0;
  xx[1] = 0.04089681274430031;
  xx[2] = 0.5;
  xx[3] = xx[2] * state[4];
  xx[4] = cos(xx[3]);
  xx[5] = 0.8709379761288196;
  xx[6] = 0.182724714184937;
  xx[7] = sin(xx[3]);
  xx[3] = xx[6] * xx[7];
  xx[8] = 0.07994726428595826;
  xx[9] = 0.9831641159165814;
  xx[10] = xx[9] * xx[7];
  xx[7] = xx[1] * xx[4] - xx[5] * xx[3] + xx[8] * xx[10];
  xx[11] = 0.4831179228482263;
  xx[12] = xx[8] * xx[4] + xx[11] * xx[3] - xx[1] * xx[10];
  xx[13] = xx[5] * xx[10] - xx[11] * xx[4] + xx[8] * xx[3];
  xx[14] = xx[7];
  xx[15] = xx[12];
  xx[16] = xx[13];
  xx[8] = 7.034264913192121e-3;
  xx[17] = xx[8] * xx[12];
  xx[18] = 0.03468999503471949;
  xx[19] = xx[18] * xx[13] + xx[8] * xx[7];
  xx[20] = xx[18] * xx[12];
  xx[21] = - xx[17];
  xx[22] = xx[19];
  xx[23] = - xx[20];
  pm_math_cross3(xx + 14, xx + 21, xx + 24);
  xx[21] = xx[5] * xx[4] + xx[1] * xx[3] + xx[11] * xx[10];
  xx[1] = 7.713196825556601e-3;
  xx[3] = xx[1] * xx[12];
  xx[4] = 0.03194912432194544;
  xx[5] = xx[4] * xx[13] - xx[1] * xx[7];
  xx[1] = xx[4] * xx[12];
  xx[27] = xx[3];
  xx[28] = xx[5];
  xx[29] = - xx[1];
  pm_math_cross3(xx + 14, xx + 27, xx + 30);
  xx[4] = 3.568507962179244e-3;
  xx[10] = xx[2] * state[2];
  xx[11] = cos(xx[10]);
  xx[14] = 5.699653188004584e-4;
  xx[15] = sin(xx[10]);
  xx[10] = xx[4] * xx[11] - xx[14] * xx[15];
  xx[16] = xx[14] * xx[11] + xx[4] * xx[15];
  xx[4] = - xx[16];
  xx[14] = 0.2621533222727515;
  xx[22] = 0.9650194694988377;
  xx[23] = xx[14] * xx[11] - xx[22] * xx[15];
  xx[27] = xx[10];
  xx[28] = xx[4];
  xx[29] = xx[23];
  xx[33] = 4.336171384355309e-17;
  xx[34] = xx[33] * xx[23];
  xx[35] = 6.240732392112002e-18;
  xx[36] = xx[35] * xx[23];
  xx[37] = xx[35] * xx[16] - xx[33] * xx[10];
  xx[38] = xx[34];
  xx[39] = xx[36];
  xx[40] = xx[37];
  pm_math_cross3(xx + 27, xx + 38, xx + 41);
  xx[38] = xx[22] * xx[11] + xx[14] * xx[15];
  xx[11] = xx[34] * xx[38];
  xx[14] = xx[0] * (xx[41] - xx[11]);
  xx[15] = xx[35] + xx[14];
  xx[22] = xx[36] * xx[38];
  xx[39] = xx[0] * (xx[42] - xx[22]);
  xx[40] = xx[39] - xx[33];
  xx[41] = xx[0] * (xx[43] - xx[37] * xx[38]);
  xx[37] = 0.01449907368972891;
  xx[42] = xx[0] * (xx[24] - xx[17] * xx[21]) - xx[0] * (xx[3] * xx[21] + xx[30])
    + 0.08092328375554529 - (xx[14] - xx[15] + 0.03696626849097064);
  xx[43] = xx[0] * (xx[19] * xx[21] + xx[25]) - xx[0] * (xx[21] * xx[5] + xx[31])
    + 0.03914259083055165 - (xx[39] - xx[40] - 0.05208460108431659);
  xx[44] = xx[0] * (xx[26] - xx[20] * xx[21]) - xx[0] * (xx[32] - xx[1] * xx[21])
    - 0.01496967009981087 - (xx[41] - xx[41] - xx[37]);
  xx[1] = 1.0;
  xx[3] = 0.9985915472931449;
  xx[5] = 0.05305583544420572;
  xx[14] = xx[3] * xx[16] + xx[5] * xx[10];
  xx[17] = xx[3] * xx[23] - xx[5] * xx[38];
  xx[19] = xx[17] * xx[17];
  xx[20] = xx[3] * xx[38] + xx[5] * xx[23];
  xx[24] = xx[20] * xx[17];
  xx[25] = xx[3] * xx[10] - xx[5] * xx[16];
  xx[26] = xx[14] * xx[25];
  xx[30] = xx[1] - xx[0] * (xx[14] * xx[14] + xx[19]);
  xx[31] = - (xx[0] * (xx[24] + xx[26]));
  xx[32] = xx[0] * (xx[17] * xx[25] - xx[14] * xx[20]);
  xx[39] = pm_math_dot3(xx + 42, xx + 30);
  xx[45] = xx[9] * state[5];
  xx[9] = xx[6] * state[5];
  xx[6] = xx[18] * xx[45] - xx[8] * xx[9];
  xx[8] = xx[6] * xx[7];
  xx[18] = xx[6] * xx[13];
  xx[46] = 0.03282062425369643;
  xx[47] = xx[46] * xx[13];
  xx[48] = xx[46] * xx[7];
  xx[49] = xx[35] * state[3];
  xx[50] = xx[49] * xx[23];
  xx[51] = xx[33] * state[3];
  xx[52] = xx[51] * xx[23];
  xx[53] = xx[49] * xx[10] + xx[51] * xx[16];
  xx[54] = - xx[50];
  xx[55] = xx[52];
  xx[56] = xx[53];
  pm_math_cross3(xx + 27, xx + 54, xx + 57);
  xx[54] = xx[35] * xx[10] + xx[33] * xx[16];
  xx[60] = xx[36];
  xx[61] = - xx[34];
  xx[62] = - xx[54];
  pm_math_cross3(xx + 27, xx + 60, xx + 63);
  xx[34] = state[3] * (xx[0] * (xx[63] - xx[22]) - xx[33]);
  xx[22] = state[3] * (xx[0] * (xx[11] + xx[64]) - xx[35]);
  xx[11] = xx[0] * state[3] * (xx[38] * xx[54] + xx[65]);
  xx[54] = xx[0] * (xx[8] * xx[12] - xx[18] * xx[21]) + xx[0] * (xx[47] * xx[21]
    - xx[48] * xx[12]) * state[5] - (xx[0] * (xx[57] + xx[50] * xx[38]) + xx[51]
    + xx[34]);
  xx[55] = xx[6] - xx[0] * (xx[18] * xx[13] + xx[8] * xx[7]) + (xx[0] * (xx[47] *
    xx[13] + xx[48] * xx[7]) - xx[46]) * state[5] - (xx[49] + xx[0] * (xx[58] -
    xx[52] * xx[38]) + xx[22]);
  xx[56] = xx[0] * (xx[8] * xx[21] + xx[18] * xx[12]) - xx[0] * state[5] * (xx
    [48] * xx[21] + xx[47] * xx[12]) - (xx[0] * (xx[59] - xx[38] * xx[53]) + xx
    [11]);
  xx[46] = xx[0] * (xx[24] - xx[26]);
  xx[47] = xx[1] - xx[0] * (xx[19] + xx[25] * xx[25]);
  xx[48] = - (xx[0] * (xx[20] * xx[25] + xx[14] * xx[17]));
  xx[6] = 0.1059622176183197;
  xx[8] = xx[6] * state[3];
  xx[14] = xx[8] * xx[23];
  xx[17] = 0.9943701566506347;
  xx[18] = xx[17] * state[3];
  xx[19] = xx[18] * xx[23];
  xx[20] = - xx[19];
  xx[24] = xx[8] * xx[10] + xx[18] * xx[16];
  xx[49] = xx[14];
  xx[50] = xx[20];
  xx[51] = - xx[24];
  pm_math_cross3(xx + 27, xx + 49, xx + 57);
  xx[25] = xx[14] * xx[38];
  xx[26] = xx[19] * xx[38];
  xx[49] = xx[0] * (xx[57] - xx[25]) - xx[18];
  xx[50] = xx[0] * (xx[58] + xx[26]) - xx[8];
  xx[51] = xx[0] * (xx[38] * xx[24] + xx[59]);
  xx[19] = pm_math_dot3(xx + 42, xx + 46);
  xx[24] = xx[18] * xx[10] - xx[8] * xx[16];
  xx[57] = xx[20];
  xx[58] = - xx[14];
  xx[59] = xx[24];
  pm_math_cross3(xx + 27, xx + 57, xx + 60);
  xx[27] = xx[0] * (xx[60] + xx[26]) - xx[8];
  xx[28] = xx[18] + xx[0] * (xx[61] + xx[25]);
  xx[29] = xx[0] * (xx[62] - xx[38] * xx[24]);
  xx[8] = xx[39] * xx[39] + xx[19] * xx[19];
  xx[8] = xx[8] == 0.0 ? 0.0 : (xx[39] * (pm_math_dot3(xx + 54, xx + 46) +
    pm_math_dot3(xx + 42, xx + 49)) - xx[19] * (pm_math_dot3(xx + 54, xx + 30) +
    pm_math_dot3(xx + 42, xx + 27))) / xx[8];
  xx[24] = xx[21];
  xx[25] = xx[7];
  xx[26] = xx[12];
  xx[27] = xx[13];
  xx[18] = - 0.9530551403624588;
  xx[19] = 0.02658750541312705;
  xx[20] = 0.08781256514654519;
  xx[21] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 24, xx + 18, xx + 28);
  xx[7] = xx[31] * xx[31];
  xx[12] = xx[28] * xx[31];
  xx[13] = xx[29] * xx[30];
  xx[18] = xx[1] - xx[0] * (xx[30] * xx[30] + xx[7]);
  xx[19] = xx[0] * (xx[12] + xx[13]);
  xx[20] = xx[0] * (xx[29] * xx[31] - xx[28] * xx[30]);
  xx[14] = pm_math_dot3(xx + 42, xx + 18);
  xx[46] = xx[0] * (xx[13] - xx[12]);
  xx[47] = xx[1] - xx[0] * (xx[7] + xx[29] * xx[29]);
  xx[48] = xx[0] * (xx[28] * xx[29] + xx[30] * xx[31]);
  xx[7] = 0.8320502943378443;
  xx[28] = - (xx[7] * xx[45]);
  xx[29] = - (0.5453613280205318 * xx[45] + 0.1013574348135827 * xx[9]);
  xx[30] = - (xx[7] * xx[9]);
  pm_math_quatXform(xx + 24, xx + 28, xx + 49);
  xx[7] = pm_math_dot3(xx + 42, xx + 46);
  xx[12] = 0.5547001962252291;
  xx[28] = - (xx[12] * xx[45]);
  xx[29] = 0.818041992030798 * xx[45] + 0.1520361522203757 * xx[9];
  xx[30] = - (xx[12] * xx[9]);
  pm_math_quatXform(xx + 24, xx + 28, xx + 57);
  xx[9] = xx[14] * xx[14] + xx[7] * xx[7];
  xx[9] = xx[9] == 0.0 ? 0.0 : (xx[14] * (pm_math_dot3(xx + 54, xx + 46) +
    pm_math_dot3(xx + 42, xx + 49)) - xx[7] * (pm_math_dot3(xx + 54, xx + 18) +
    pm_math_dot3(xx + 42, xx + 57))) / xx[9];
  xx[18] = 0.9775690487425092;
  xx[19] = 3.533241901317298e-3;
  xx[20] = - 7.584927208271003e-4;
  xx[21] = 0.2105841775422004;
  xx[7] = xx[2] * state[0];
  xx[12] = 2.971047694847219e-3;
  xx[13] = sin(xx[7]);
  xx[14] = 6.588522717321608e-3;
  xx[16] = 0.9999738817809185;
  xx[24] = cos(xx[7]);
  xx[25] = xx[12] * xx[13];
  xx[26] = xx[14] * xx[13];
  xx[27] = xx[16] * xx[13];
  pm_math_quatCompose(xx + 18, xx + 24, xx + 28);
  xx[18] = - xx[38];
  xx[19] = xx[10];
  xx[20] = xx[4];
  xx[21] = xx[23];
  pm_math_quatCompose(xx + 28, xx + 18, xx + 23);
  xx[42] = xx[12] * state[1];
  xx[43] = xx[14] * state[1];
  xx[44] = xx[16] * state[1];
  pm_math_quatInverseXform(xx + 18, xx + 42, xx + 12);
  xx[4] = xx[14] + state[3];
  xx[18] = xx[33] * xx[4];
  xx[19] = xx[35] * xx[4];
  xx[20] = - (xx[33] * xx[12] + xx[35] * xx[13]);
  pm_math_quatXform(xx + 23, xx + 18, xx + 45);
  xx[18] = 9.769655003657077e-3;
  xx[19] = 0.09968416567382769;
  xx[20] = - 6.85815413354548e-4;
  pm_math_quatXform(xx + 28, xx + 18, xx + 48);
  xx[18] = 0.03696626849097063 - xx[15];
  xx[19] = - (0.05208460108431655 + xx[40]);
  xx[20] = - (xx[37] + xx[41]);
  pm_math_cross3(xx + 42, xx + 18, xx + 14);
  xx[36] = xx[34] + xx[14];
  xx[37] = xx[22] + xx[15];
  xx[38] = xx[11] + xx[16];
  pm_math_quatXform(xx + 28, xx + 36, xx + 14);
  xx[7] = xx[46] + state[1] * xx[49] + xx[15];
  xx[10] = xx[33] * xx[26];
  xx[11] = xx[33] * xx[24] + xx[35] * xx[25];
  xx[36] = xx[10];
  xx[37] = xx[35] * xx[26];
  xx[38] = - xx[11];
  pm_math_cross3(xx + 24, xx + 36, xx + 39);
  pm_math_quatXform(xx + 28, xx + 18, xx + 36);
  xx[18] = - 0.09972985016632961;
  xx[19] = 9.674375133208124e-3;
  xx[20] = - 0.01449984343940976;
  pm_math_quatXform(xx + 28, xx + 18, xx + 42);
  xx[18] = xx[35] + xx[0] * (xx[39] + xx[10] * xx[23]) + xx[36] - xx[42];
  xx[10] = xx[0] * (xx[35] * xx[23] * xx[26] + xx[40]) - xx[33] + xx[37] - xx[43];
  xx[19] = xx[45] + state[1] * xx[48] + xx[14];
  xx[20] = xx[18] * xx[18] + xx[10] * xx[10];
  xx[20] = xx[20] == 0.0 ? 0.0 : (xx[7] * xx[18] - xx[10] * xx[19]) / xx[20];
  xx[27] = xx[18];
  xx[28] = xx[10];
  xx[29] = xx[0] * (xx[41] - xx[11] * xx[23]) + xx[38] - xx[44];
  xx[10] = xx[3] * xx[25] - xx[5] * xx[24];
  xx[11] = xx[5] * xx[23] + xx[3] * xx[26];
  xx[18] = xx[11] * xx[11];
  xx[21] = xx[3] * xx[23] - xx[5] * xx[26];
  xx[22] = xx[21] * xx[11];
  xx[30] = xx[3] * xx[24] + xx[5] * xx[25];
  xx[3] = xx[10] * xx[30];
  xx[31] = xx[1] - xx[0] * (xx[10] * xx[10] + xx[18]);
  xx[32] = xx[0] * (xx[22] + xx[3]);
  xx[33] = xx[0] * (xx[30] * xx[11] - xx[21] * xx[10]);
  xx[5] = pm_math_dot3(xx + 27, xx + 31);
  xx[34] = xx[19];
  xx[35] = xx[7];
  xx[36] = xx[47] + state[1] * xx[50] + xx[16];
  xx[14] = xx[0] * (xx[3] - xx[22]);
  xx[15] = xx[1] - xx[0] * (xx[18] + xx[30] * xx[30]);
  xx[16] = xx[0] * (xx[21] * xx[30] + xx[10] * xx[11]);
  xx[0] = xx[17] * xx[4];
  xx[1] = - (xx[6] * xx[4]);
  xx[37] = - xx[0];
  xx[38] = xx[1];
  xx[39] = xx[17] * xx[12] + xx[6] * xx[13];
  pm_math_quatXform(xx + 23, xx + 37, xx + 40);
  xx[3] = pm_math_dot3(xx + 27, xx + 14);
  xx[37] = xx[1];
  xx[38] = xx[0];
  xx[39] = xx[6] * xx[12] - xx[17] * xx[13];
  pm_math_quatXform(xx + 23, xx + 37, xx + 10);
  xx[0] = xx[5] * xx[5] + xx[3] * xx[3];
  xx[0] = xx[0] == 0.0 ? 0.0 : (xx[5] * (pm_math_dot3(xx + 34, xx + 14) +
    pm_math_dot3(xx + 27, xx + 40)) - xx[3] * (pm_math_dot3(xx + 34, xx + 31) +
    pm_math_dot3(xx + 27, xx + 10))) / xx[0];
  xx[3] = fabs(xx[8] + xx[9]);
  xx[4] = fabs(xx[20] + xx[2] * xx[0]);
  ii[0] = 3;

  {
    int ll;
    for (ll = 4; ll < 5; ++ll)
      if (xx[ll] > xx[ii[0]])
        ii[0] = ll;
  }

  ii[0] -= 3;
  xx[0] = xx[3 + (ii[0])];
  xx[1] = xx[0] - 1.0e-5;
  if (xx[1] < 0.0)
    ii[0] = -1;
  else if (xx[1] > 0.0)
    ii[0] = +1;
  else
    ii[0] = 0;
  ii[1] = ii[0];
  if (0 > ii[1])
    ii[1] = 0;
  return ii[1];
}

PmfMessageId sm_cardan_gear_ffe27655_1_projectStateSim(const void *mech, const
  double *rtdv, const int *eqnEnableFlags, const double *input, double *state,
  void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  int ii[4];
  double xx[172];
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) input;
  (void) neDiagMgr;
  xx[0] = 0.0;
  xx[1] = 2.0;
  xx[2] = 0.04089681274430031;
  xx[3] = 0.5;
  xx[4] = xx[3] * state[4];
  xx[5] = cos(xx[4]);
  xx[6] = 0.8709379761288196;
  xx[7] = 0.182724714184937;
  xx[8] = sin(xx[4]);
  xx[4] = xx[7] * xx[8];
  xx[9] = 0.07994726428595826;
  xx[10] = 0.9831641159165814;
  xx[11] = xx[10] * xx[8];
  xx[8] = xx[2] * xx[5] - xx[6] * xx[4] + xx[9] * xx[11];
  xx[12] = 0.4831179228482263;
  xx[13] = xx[9] * xx[5] + xx[12] * xx[4] - xx[2] * xx[11];
  xx[14] = xx[6] * xx[11] - xx[12] * xx[5] + xx[9] * xx[4];
  xx[15] = xx[8];
  xx[16] = xx[13];
  xx[17] = xx[14];
  xx[18] = 7.034264913192121e-3;
  xx[19] = xx[18] * xx[13];
  xx[20] = 0.03468999503471949;
  xx[21] = xx[20] * xx[14] + xx[18] * xx[8];
  xx[22] = xx[20] * xx[13];
  xx[23] = - xx[19];
  xx[24] = xx[21];
  xx[25] = - xx[22];
  pm_math_cross3(xx + 15, xx + 23, xx + 26);
  xx[23] = xx[6] * xx[5] + xx[2] * xx[4] + xx[12] * xx[11];
  xx[4] = 7.713196825556601e-3;
  xx[5] = xx[4] * xx[13];
  xx[11] = 0.03194912432194544;
  xx[24] = xx[11] * xx[14] - xx[4] * xx[8];
  xx[25] = xx[11] * xx[13];
  xx[29] = xx[5];
  xx[30] = xx[24];
  xx[31] = - xx[25];
  pm_math_cross3(xx + 15, xx + 29, xx + 32);
  xx[15] = 0.08092328375554529;
  xx[16] = 3.568507962179244e-3;
  xx[17] = xx[3] * state[2];
  xx[29] = cos(xx[17]);
  xx[30] = 5.699653188004584e-4;
  xx[31] = sin(xx[17]);
  xx[17] = xx[16] * xx[29] - xx[30] * xx[31];
  xx[35] = xx[30] * xx[29] + xx[16] * xx[31];
  xx[36] = - xx[35];
  xx[37] = 0.2621533222727515;
  xx[38] = 0.9650194694988377;
  xx[39] = xx[37] * xx[29] - xx[38] * xx[31];
  xx[40] = xx[17];
  xx[41] = xx[36];
  xx[42] = xx[39];
  xx[43] = 4.336171384355309e-17;
  xx[44] = xx[43] * xx[39];
  xx[45] = 6.240732392112002e-18;
  xx[46] = xx[45] * xx[39];
  xx[47] = xx[45] * xx[35] - xx[43] * xx[17];
  xx[48] = xx[44];
  xx[49] = xx[46];
  xx[50] = xx[47];
  pm_math_cross3(xx + 40, xx + 48, xx + 51);
  xx[48] = xx[38] * xx[29] + xx[37] * xx[31];
  xx[29] = xx[44] * xx[48];
  xx[31] = xx[1] * (xx[51] - xx[29]);
  xx[49] = xx[45] + xx[31];
  xx[50] = 0.03696626849097064;
  xx[54] = 0.03914259083055165;
  xx[55] = xx[46] * xx[48];
  xx[56] = xx[1] * (xx[52] - xx[55]);
  xx[57] = xx[56] - xx[43];
  xx[58] = 0.05208460108431659;
  xx[59] = 0.01496967009981087;
  xx[51] = xx[1] * (xx[53] - xx[47] * xx[48]);
  xx[47] = 0.01449907368972891;
  xx[60] = xx[1] * (xx[26] - xx[19] * xx[23]) - xx[1] * (xx[5] * xx[23] + xx[32])
    + xx[15] - (xx[31] - xx[49] + xx[50]);
  xx[61] = xx[1] * (xx[21] * xx[23] + xx[27]) - xx[1] * (xx[23] * xx[24] + xx[33])
    + xx[54] - (xx[56] - xx[57] - xx[58]);
  xx[62] = xx[1] * (xx[28] - xx[22] * xx[23]) - xx[1] * (xx[34] - xx[25] * xx[23])
    - xx[59] - (xx[51] - xx[51] - xx[47]);
  xx[5] = 1.0;
  xx[19] = 0.9985915472931449;
  xx[21] = 0.05305583544420572;
  xx[22] = xx[19] * xx[35] + xx[21] * xx[17];
  xx[24] = xx[19] * xx[39] - xx[21] * xx[48];
  xx[25] = xx[24] * xx[24];
  xx[26] = xx[19] * xx[48] + xx[21] * xx[39];
  xx[27] = xx[26] * xx[24];
  xx[28] = xx[19] * xx[17] - xx[21] * xx[35];
  xx[31] = xx[22] * xx[28];
  xx[32] = xx[5] - xx[1] * (xx[22] * xx[22] + xx[25]);
  xx[33] = - (xx[1] * (xx[27] + xx[31]));
  xx[34] = xx[1] * (xx[24] * xx[28] - xx[22] * xx[26]);
  xx[52] = pm_math_dot3(xx + 60, xx + 32);
  xx[53] = 0.1059622176183197;
  xx[56] = xx[53] * xx[39];
  xx[63] = 0.9943701566506347;
  xx[64] = xx[63] * xx[39];
  xx[65] = - xx[64];
  xx[66] = xx[53] * xx[17] + xx[63] * xx[35];
  xx[67] = xx[56];
  xx[68] = xx[65];
  xx[69] = - xx[66];
  pm_math_cross3(xx + 40, xx + 67, xx + 70);
  xx[67] = xx[56] * xx[48];
  xx[68] = xx[64] * xx[48];
  xx[73] = xx[1] * (xx[70] - xx[67]) - xx[63];
  xx[74] = xx[1] * (xx[68] + xx[71]) - xx[53];
  xx[75] = xx[1] * (xx[48] * xx[66] + xx[72]);
  xx[64] = xx[45] * xx[17];
  xx[66] = xx[43] * xx[35];
  xx[69] = xx[64] + xx[66];
  xx[70] = - xx[46];
  xx[71] = xx[44];
  xx[72] = xx[69];
  pm_math_cross3(xx + 40, xx + 70, xx + 76);
  xx[70] = xx[64] + xx[66];
  xx[79] = xx[46];
  xx[80] = - xx[44];
  xx[81] = - xx[70];
  pm_math_cross3(xx + 40, xx + 79, xx + 82);
  xx[44] = xx[1] * (xx[82] - xx[55]) - xx[43];
  xx[46] = xx[1] * (xx[29] + xx[83]) - xx[45];
  xx[64] = xx[1] * (xx[48] * xx[70] + xx[84]);
  xx[70] = xx[43] + xx[1] * (xx[76] + xx[55]) + xx[44];
  xx[71] = xx[45] + xx[1] * (xx[77] - xx[29]) + xx[46];
  xx[72] = xx[1] * (xx[78] - xx[48] * xx[69]) + xx[64];
  xx[76] = xx[1] * (xx[27] - xx[31]);
  xx[77] = xx[5] - xx[1] * (xx[25] + xx[28] * xx[28]);
  xx[78] = - (xx[1] * (xx[26] * xx[28] + xx[22] * xx[24]));
  xx[22] = pm_math_dot3(xx + 60, xx + 76);
  xx[24] = xx[63] * xx[17] - xx[53] * xx[35];
  xx[25] = xx[65];
  xx[26] = - xx[56];
  xx[27] = xx[24];
  pm_math_cross3(xx + 40, xx + 25, xx + 79);
  xx[25] = xx[1] * (xx[79] + xx[68]) - xx[53];
  xx[26] = xx[63] + xx[1] * (xx[67] + xx[80]);
  xx[27] = xx[1] * (xx[81] - xx[48] * xx[24]);
  xx[24] = xx[52] * xx[52] + xx[22] * xx[22];
  xx[28] = xx[24] == 0.0 ? 0.0 : (xx[52] * (pm_math_dot3(xx + 60, xx + 73) -
    pm_math_dot3(xx + 70, xx + 76)) - xx[22] * (pm_math_dot3(xx + 60, xx + 25) -
    pm_math_dot3(xx + 70, xx + 32))) / xx[24];
  xx[65] = xx[23];
  xx[66] = xx[8];
  xx[67] = xx[13];
  xx[68] = xx[14];
  xx[79] = - 0.9530551403624588;
  xx[80] = 0.02658750541312705;
  xx[81] = 0.08781256514654519;
  xx[82] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 65, xx + 79, xx + 83);
  xx[25] = xx[86] * xx[86];
  xx[26] = xx[83] * xx[86];
  xx[27] = xx[84] * xx[85];
  xx[40] = xx[5] - xx[1] * (xx[85] * xx[85] + xx[25]);
  xx[41] = xx[1] * (xx[26] + xx[27]);
  xx[42] = xx[1] * (xx[84] * xx[86] - xx[83] * xx[85]);
  xx[73] = xx[1] * (xx[27] - xx[26]);
  xx[74] = xx[5] - xx[1] * (xx[25] + xx[84] * xx[84]);
  xx[75] = xx[1] * (xx[83] * xx[84] + xx[85] * xx[86]);
  xx[25] = pm_math_dot3(xx + 60, xx + 73);
  xx[26] = pm_math_dot3(xx + 60, xx + 40);
  xx[27] = xx[26] * xx[26] + xx[25] * xx[25];
  xx[29] = xx[27] == 0.0 ? 0.0 : (pm_math_dot3(xx + 70, xx + 40) * xx[25] -
    pm_math_dot3(xx + 70, xx + 73) * xx[26]) / xx[27];
  xx[31] = 0.03282062425369642;
  xx[35] = xx[31] * xx[8];
  xx[55] = xx[31] * xx[14];
  xx[56] = 0.03282062425369643;
  xx[69] = xx[56] * xx[14];
  xx[70] = xx[56] * xx[8];
  xx[83] = xx[1] * (xx[35] * xx[13] - xx[55] * xx[23]) + xx[1] * (xx[69] * xx[23]
    - xx[70] * xx[13]);
  xx[84] = xx[31] - xx[1] * (xx[55] * xx[14] + xx[35] * xx[8]) + xx[1] * (xx[69]
    * xx[14] + xx[70] * xx[8]) - xx[56];
  xx[85] = xx[1] * (xx[35] * xx[23] + xx[55] * xx[13]) - xx[1] * (xx[70] * xx[23]
    + xx[69] * xx[13]);
  xx[8] = xx[24] == 0.0 ? 0.0 : (pm_math_dot3(xx + 83, xx + 76) * xx[52] -
    pm_math_dot3(xx + 83, xx + 32) * xx[22]) / xx[24];
  xx[13] = 0.818041992030798;
  xx[14] = 0.5547001962252291;
  xx[32] = - xx[13];
  xx[33] = - xx[14];
  xx[34] = - 0.1520361522203753;
  pm_math_quatXform(xx + 65, xx + 32, xx + 69);
  xx[76] = - 0.5453613280205316;
  xx[77] = 0.8320502943378444;
  xx[78] = - 0.1013574348135835;
  pm_math_quatXform(xx + 65, xx + 76, xx + 86);
  xx[23] = xx[27] == 0.0 ? 0.0 : (xx[26] * (pm_math_dot3(xx + 83, xx + 73) +
    pm_math_dot3(xx + 60, xx + 69)) - xx[25] * (pm_math_dot3(xx + 83, xx + 40) +
    pm_math_dot3(xx + 60, xx + 86))) / xx[27];
  xx[65] = 0.9775690487425092;
  xx[66] = 3.533241901317298e-3;
  xx[67] = - 7.584927208271003e-4;
  xx[68] = 0.2105841775422004;
  xx[24] = xx[3] * state[0];
  xx[27] = 2.971047694847219e-3;
  xx[35] = sin(xx[24]);
  xx[40] = 6.588522717321608e-3;
  xx[41] = 0.9999738817809185;
  xx[69] = cos(xx[24]);
  xx[70] = xx[27] * xx[35];
  xx[71] = xx[40] * xx[35];
  xx[72] = xx[41] * xx[35];
  pm_math_quatCompose(xx + 65, xx + 69, xx + 83);
  xx[69] = - xx[48];
  xx[70] = xx[17];
  xx[71] = xx[36];
  xx[72] = xx[39];
  pm_math_quatCompose(xx + 83, xx + 69, xx + 87);
  xx[17] = xx[43] * xx[90];
  xx[24] = xx[45] * xx[90];
  xx[35] = xx[43] * xx[88] + xx[45] * xx[89];
  xx[60] = xx[17];
  xx[61] = xx[24];
  xx[62] = - xx[35];
  pm_math_cross3(xx + 88, xx + 60, xx + 73);
  xx[36] = 0.03696626849097063;
  xx[39] = 0.05208460108431655;
  xx[60] = xx[36] - xx[49];
  xx[61] = - (xx[39] + xx[57]);
  xx[62] = - (xx[47] + xx[51]);
  pm_math_quatXform(xx + 83, xx + 60, xx + 91);
  xx[94] = - 0.09972985016632961;
  xx[95] = 9.674375133208124e-3;
  xx[96] = - 0.01449984343940976;
  pm_math_quatXform(xx + 83, xx + 94, xx + 97);
  xx[42] = xx[45] + xx[1] * (xx[73] + xx[17] * xx[87]) + xx[91] - xx[97];
  xx[100] = xx[27];
  xx[101] = xx[40];
  xx[102] = xx[41];
  pm_math_quatInverseXform(xx + 69, xx + 100, xx + 103);
  xx[69] = xx[43] * xx[105];
  xx[70] = xx[45] * xx[105];
  xx[71] = - (xx[43] * xx[103] + xx[45] * xx[104]);
  pm_math_quatXform(xx + 87, xx + 69, xx + 106);
  pm_math_cross3(xx + 100, xx + 60, xx + 69);
  pm_math_quatXform(xx + 83, xx + 69, xx + 60);
  xx[69] = 9.769655003657077e-3;
  xx[70] = 0.09968416567382769;
  xx[71] = - 6.85815413354548e-4;
  pm_math_quatXform(xx + 83, xx + 69, xx + 109);
  xx[48] = xx[107] + xx[61] + xx[110];
  xx[49] = xx[87] * xx[90];
  xx[51] = xx[1] * (xx[45] * xx[49] + xx[74]) - xx[43] + xx[92] - xx[98];
  xx[55] = xx[106] + xx[60] + xx[109];
  xx[57] = xx[42] * xx[42] + xx[51] * xx[51];
  xx[72] = xx[57] == 0.0 ? 0.0 : (xx[42] * xx[48] - xx[51] * xx[55]) / xx[57];
  xx[112] = xx[42];
  xx[113] = xx[51];
  xx[114] = xx[1] * (xx[75] - xx[35] * xx[87]) + xx[93] - xx[99];
  xx[35] = xx[19] * xx[89] - xx[21] * xx[88];
  xx[73] = xx[21] * xx[87] + xx[19] * xx[90];
  xx[74] = xx[73] * xx[73];
  xx[75] = xx[19] * xx[87] - xx[21] * xx[90];
  xx[91] = xx[75] * xx[73];
  xx[92] = xx[19] * xx[88] + xx[21] * xx[89];
  xx[93] = xx[35] * xx[92];
  xx[97] = xx[5] - xx[1] * (xx[35] * xx[35] + xx[74]);
  xx[98] = xx[1] * (xx[91] + xx[93]);
  xx[99] = xx[1] * (xx[73] * xx[92] - xx[35] * xx[75]);
  xx[115] = pm_math_dot3(xx + 112, xx + 97);
  xx[116] = xx[55];
  xx[117] = xx[48];
  xx[118] = xx[108] + xx[62] + xx[111];
  xx[60] = xx[1] * (xx[93] - xx[91]);
  xx[61] = xx[5] - xx[1] * (xx[74] + xx[92] * xx[92]);
  xx[62] = xx[1] * (xx[75] * xx[92] + xx[35] * xx[73]);
  xx[35] = xx[63] * xx[105];
  xx[48] = - (xx[53] * xx[105]);
  xx[73] = - xx[35];
  xx[74] = xx[48];
  xx[75] = xx[63] * xx[103] + xx[53] * xx[104];
  pm_math_quatXform(xx + 87, xx + 73, xx + 91);
  xx[55] = pm_math_dot3(xx + 112, xx + 60);
  xx[73] = xx[48];
  xx[74] = xx[35];
  xx[75] = xx[53] * xx[103] - xx[63] * xx[104];
  pm_math_quatXform(xx + 87, xx + 73, xx + 103);
  xx[35] = xx[115] * xx[115] + xx[55] * xx[55];
  xx[48] = xx[35] == 0.0 ? 0.0 : (xx[115] * (pm_math_dot3(xx + 116, xx + 60) +
    pm_math_dot3(xx + 112, xx + 91)) - xx[55] * (pm_math_dot3(xx + 116, xx + 97)
    + pm_math_dot3(xx + 112, xx + 103))) / xx[35];
  xx[73] = xx[45] * xx[88] - xx[43] * xx[89];
  xx[91] = - xx[24];
  xx[92] = xx[17];
  xx[93] = xx[73];
  pm_math_cross3(xx + 88, xx + 91, xx + 103);
  xx[91] = xx[44];
  xx[92] = xx[46];
  xx[93] = xx[64];
  pm_math_quatXform(xx + 83, xx + 91, xx + 106);
  xx[17] = xx[45] + xx[1] * (xx[43] * xx[49] + xx[104]) + xx[107];
  xx[44] = xx[43] + xx[1] * (xx[103] - xx[24] * xx[87]) + xx[106];
  xx[24] = xx[57] == 0.0 ? 0.0 : (xx[42] * xx[17] - xx[51] * xx[44]) / xx[57];
  xx[83] = xx[44];
  xx[84] = xx[17];
  xx[85] = xx[1] * (xx[73] * xx[87] + xx[105]) + xx[108];
  xx[17] = xx[53] * xx[90];
  xx[44] = xx[63] * xx[90];
  xx[46] = - xx[44];
  xx[57] = xx[63] * xx[89] - xx[53] * xx[88];
  xx[73] = xx[17];
  xx[74] = xx[46];
  xx[75] = xx[57];
  pm_math_cross3(xx + 88, xx + 73, xx + 91);
  xx[73] = xx[1] * (xx[91] + xx[17] * xx[87]) - xx[63];
  xx[74] = xx[1] * (xx[92] - xx[63] * xx[49]) - xx[53];
  xx[75] = xx[1] * (xx[57] * xx[87] + xx[93]);
  xx[57] = xx[63] * xx[88] + xx[53] * xx[89];
  xx[91] = xx[46];
  xx[92] = - xx[17];
  xx[93] = xx[57];
  pm_math_cross3(xx + 88, xx + 91, xx + 103);
  xx[88] = xx[1] * (xx[103] - xx[44] * xx[87]) - xx[53];
  xx[89] = xx[63] + xx[1] * (xx[104] - xx[53] * xx[49]);
  xx[90] = xx[1] * (xx[57] * xx[87] + xx[105]);
  xx[17] = xx[35] == 0.0 ? 0.0 : (xx[115] * (pm_math_dot3(xx + 83, xx + 60) +
    pm_math_dot3(xx + 112, xx + 73)) - xx[55] * (pm_math_dot3(xx + 83, xx + 97)
    + pm_math_dot3(xx + 112, xx + 88))) / xx[35];
  xx[83] = xx[0];
  xx[84] = xx[28] + xx[29];
  xx[85] = xx[8] + xx[23];
  xx[86] = xx[72] + xx[3] * xx[48];
  xx[87] = xx[24] + xx[3] * xx[17];
  xx[88] = xx[0];
  xx[8] = 3.141592653589793;
  xx[17] = atan2(xx[22], xx[52]) - state[6];
  xx[22] = (xx[17] < 0.0 ? -1.0 : +1.0);
  xx[23] = 6.283185307179586;
  xx[24] = state[6] + (fmod(xx[8] + xx[17] * xx[22], xx[23]) - xx[8]) * xx[22] -
    state[10] + atan2(xx[25], xx[26]);
  xx[17] = (xx[24] < 0.0 ? -1.0 : +1.0);
  xx[22] = atan2(xx[51], xx[42]) - state[8];
  xx[25] = (xx[22] < 0.0 ? -1.0 : +1.0);
  xx[26] = (state[8] + (fmod(xx[8] + xx[22] * xx[25], xx[23]) - xx[8]) * xx[25]
            - state[11]) / xx[3] + atan2(xx[55], xx[115]);
  xx[22] = (xx[26] < 0.0 ? -1.0 : +1.0);
  xx[28] = - ((fmod(xx[8] + xx[17] * xx[24], xx[23]) - xx[8]) * xx[17]);
  xx[29] = - (xx[3] * (fmod(xx[8] + xx[22] * xx[26], xx[23]) - xx[8]) * xx[22]);
  xx[17] = 1.0e-8;
  memcpy(xx + 103, xx + 83, 6 * sizeof(double));
  factorAndSolveWide(2, 3, xx + 103, xx + 48, xx + 51, ii + 0, xx + 28, xx[17],
                     xx + 24);
  xx[22] = state[0] + xx[24];
  xx[28] = state[4] + xx[26];
  xx[29] = xx[3] * xx[28];
  xx[35] = cos(xx[29]);
  xx[42] = sin(xx[29]);
  xx[29] = xx[7] * xx[42];
  xx[44] = xx[10] * xx[42];
  xx[42] = xx[2] * xx[35] - xx[6] * xx[29] + xx[9] * xx[44];
  xx[46] = xx[9] * xx[35] + xx[12] * xx[29] - xx[2] * xx[44];
  xx[48] = xx[6] * xx[44] - xx[12] * xx[35] + xx[9] * xx[29];
  xx[60] = xx[42];
  xx[61] = xx[46];
  xx[62] = xx[48];
  xx[49] = xx[18] * xx[46];
  xx[51] = xx[20] * xx[48] + xx[18] * xx[42];
  xx[52] = xx[20] * xx[46];
  xx[72] = - xx[49];
  xx[73] = xx[51];
  xx[74] = - xx[52];
  pm_math_cross3(xx + 60, xx + 72, xx + 83);
  xx[55] = xx[6] * xx[35] + xx[2] * xx[29] + xx[12] * xx[44];
  xx[29] = xx[4] * xx[46];
  xx[35] = xx[11] * xx[48] - xx[4] * xx[42];
  xx[44] = xx[11] * xx[46];
  xx[72] = xx[29];
  xx[73] = xx[35];
  xx[74] = - xx[44];
  pm_math_cross3(xx + 60, xx + 72, xx + 86);
  xx[24] = state[2] + xx[25];
  xx[25] = xx[3] * xx[24];
  xx[26] = cos(xx[25]);
  xx[57] = sin(xx[25]);
  xx[25] = xx[16] * xx[26] - xx[30] * xx[57];
  xx[60] = xx[30] * xx[26] + xx[16] * xx[57];
  xx[61] = - xx[60];
  xx[62] = xx[37] * xx[26] - xx[38] * xx[57];
  xx[72] = xx[25];
  xx[73] = xx[61];
  xx[74] = xx[62];
  xx[64] = xx[43] * xx[62];
  xx[75] = xx[45] * xx[62];
  xx[89] = xx[45] * xx[60] - xx[43] * xx[25];
  xx[90] = xx[64];
  xx[91] = xx[75];
  xx[92] = xx[89];
  pm_math_cross3(xx + 72, xx + 90, xx + 97);
  xx[90] = xx[38] * xx[26] + xx[37] * xx[57];
  xx[26] = xx[64] * xx[90];
  xx[57] = xx[1] * (xx[97] - xx[26]);
  xx[91] = xx[45] + xx[57];
  xx[92] = xx[75] * xx[90];
  xx[93] = xx[1] * (xx[98] - xx[92]);
  xx[103] = xx[93] - xx[43];
  xx[97] = xx[1] * (xx[99] - xx[90] * xx[89]);
  xx[104] = xx[1] * (xx[83] - xx[49] * xx[55]) - xx[1] * (xx[29] * xx[55] + xx
    [86]) + xx[15] - (xx[57] - xx[91] + xx[50]);
  xx[105] = xx[1] * (xx[55] * xx[51] + xx[84]) - xx[1] * (xx[55] * xx[35] + xx
    [87]) + xx[54] - (xx[93] - xx[103] - xx[58]);
  xx[106] = xx[1] * (xx[85] - xx[52] * xx[55]) - xx[1] * (xx[88] - xx[44] * xx
    [55]) - xx[59] - (xx[97] - xx[97] - xx[47]);
  xx[29] = xx[19] * xx[60] + xx[21] * xx[25];
  xx[35] = xx[19] * xx[62] - xx[21] * xx[90];
  xx[44] = xx[35] * xx[35];
  xx[49] = xx[19] * xx[90] + xx[21] * xx[62];
  xx[51] = xx[49] * xx[35];
  xx[52] = xx[19] * xx[25] - xx[21] * xx[60];
  xx[57] = xx[29] * xx[52];
  xx[83] = xx[5] - xx[1] * (xx[29] * xx[29] + xx[44]);
  xx[84] = - (xx[1] * (xx[51] + xx[57]));
  xx[85] = xx[1] * (xx[35] * xx[52] - xx[29] * xx[49]);
  xx[86] = pm_math_dot3(xx + 104, xx + 83);
  xx[87] = xx[53] * xx[62];
  xx[88] = xx[63] * xx[62];
  xx[89] = - xx[88];
  xx[93] = xx[53] * xx[25] + xx[63] * xx[60];
  xx[107] = xx[87];
  xx[108] = xx[89];
  xx[109] = - xx[93];
  pm_math_cross3(xx + 72, xx + 107, xx + 110);
  xx[98] = xx[87] * xx[90];
  xx[99] = xx[88] * xx[90];
  xx[107] = xx[1] * (xx[110] - xx[98]) - xx[63];
  xx[108] = xx[1] * (xx[99] + xx[111]) - xx[53];
  xx[109] = xx[1] * (xx[90] * xx[93] + xx[112]);
  xx[88] = xx[45] * xx[25];
  xx[93] = xx[43] * xx[60];
  xx[110] = xx[88] + xx[93];
  xx[111] = - xx[75];
  xx[112] = xx[64];
  xx[113] = xx[110];
  pm_math_cross3(xx + 72, xx + 111, xx + 114);
  xx[111] = xx[88] + xx[93];
  xx[117] = xx[75];
  xx[118] = - xx[64];
  xx[119] = - xx[111];
  pm_math_cross3(xx + 72, xx + 117, xx + 120);
  xx[64] = xx[1] * (xx[120] - xx[92]) - xx[43];
  xx[75] = xx[1] * (xx[26] + xx[121]) - xx[45];
  xx[88] = xx[1] * (xx[90] * xx[111] + xx[122]);
  xx[111] = xx[43] + xx[1] * (xx[114] + xx[92]) + xx[64];
  xx[112] = xx[45] + xx[1] * (xx[115] - xx[26]) + xx[75];
  xx[113] = xx[1] * (xx[116] - xx[90] * xx[110]) + xx[88];
  xx[114] = xx[1] * (xx[51] - xx[57]);
  xx[115] = xx[5] - xx[1] * (xx[44] + xx[52] * xx[52]);
  xx[116] = - (xx[1] * (xx[49] * xx[52] + xx[29] * xx[35]));
  xx[26] = pm_math_dot3(xx + 104, xx + 114);
  xx[29] = xx[63] * xx[25] - xx[53] * xx[60];
  xx[117] = xx[89];
  xx[118] = - xx[87];
  xx[119] = xx[29];
  pm_math_cross3(xx + 72, xx + 117, xx + 120);
  xx[72] = xx[1] * (xx[120] + xx[99]) - xx[53];
  xx[73] = xx[63] + xx[1] * (xx[98] + xx[121]);
  xx[74] = xx[1] * (xx[122] - xx[90] * xx[29]);
  xx[29] = xx[86] * xx[86] + xx[26] * xx[26];
  xx[35] = xx[29] == 0.0 ? 0.0 : (xx[86] * (pm_math_dot3(xx + 104, xx + 107) -
    pm_math_dot3(xx + 111, xx + 114)) - xx[26] * (pm_math_dot3(xx + 104, xx + 72)
    - pm_math_dot3(xx + 111, xx + 83))) / xx[29];
  xx[107] = xx[55];
  xx[108] = xx[42];
  xx[109] = xx[46];
  xx[110] = xx[48];
  pm_math_quatCompose(xx + 107, xx + 79, xx + 117);
  xx[44] = xx[118] * xx[119];
  xx[49] = xx[117] * xx[120];
  xx[51] = xx[120] * xx[120];
  xx[72] = xx[1] * (xx[44] - xx[49]);
  xx[73] = xx[5] - xx[1] * (xx[51] + xx[118] * xx[118]);
  xx[74] = xx[1] * (xx[117] * xx[118] + xx[119] * xx[120]);
  xx[52] = pm_math_dot3(xx + 104, xx + 72);
  xx[121] = xx[5] - xx[1] * (xx[119] * xx[119] + xx[51]);
  xx[122] = xx[1] * (xx[49] + xx[44]);
  xx[123] = xx[1] * (xx[118] * xx[120] - xx[117] * xx[119]);
  xx[44] = pm_math_dot3(xx + 104, xx + 121);
  xx[49] = xx[44] * xx[44] + xx[52] * xx[52];
  xx[51] = xx[49] == 0.0 ? 0.0 : (xx[52] * pm_math_dot3(xx + 111, xx + 121) -
    xx[44] * pm_math_dot3(xx + 111, xx + 72)) / xx[49];
  xx[57] = xx[31] * xx[42];
  xx[60] = xx[31] * xx[48];
  xx[87] = xx[56] * xx[48];
  xx[89] = xx[56] * xx[42];
  xx[111] = xx[1] * (xx[57] * xx[46] - xx[60] * xx[55]) + xx[1] * (xx[87] * xx
    [55] - xx[89] * xx[46]);
  xx[112] = xx[31] - xx[1] * (xx[60] * xx[48] + xx[57] * xx[42]) + xx[1] * (xx
    [87] * xx[48] + xx[89] * xx[42]) - xx[56];
  xx[113] = xx[1] * (xx[57] * xx[55] + xx[60] * xx[46]) - xx[1] * (xx[89] * xx
    [55] + xx[87] * xx[46]);
  xx[42] = xx[29] == 0.0 ? 0.0 : (xx[86] * pm_math_dot3(xx + 111, xx + 114) -
    xx[26] * pm_math_dot3(xx + 111, xx + 83)) / xx[29];
  pm_math_quatXform(xx + 107, xx + 32, xx + 83);
  pm_math_quatXform(xx + 107, xx + 76, xx + 114);
  xx[29] = xx[49] == 0.0 ? 0.0 : (xx[44] * (pm_math_dot3(xx + 111, xx + 72) +
    pm_math_dot3(xx + 104, xx + 83)) - xx[52] * (pm_math_dot3(xx + 111, xx + 121)
    + pm_math_dot3(xx + 104, xx + 114))) / xx[49];
  xx[46] = xx[3] * xx[22];
  xx[48] = sin(xx[46]);
  xx[104] = cos(xx[46]);
  xx[105] = xx[27] * xx[48];
  xx[106] = xx[40] * xx[48];
  xx[107] = xx[41] * xx[48];
  pm_math_quatCompose(xx + 65, xx + 104, xx + 108);
  xx[104] = - xx[90];
  xx[105] = xx[25];
  xx[106] = xx[61];
  xx[107] = xx[62];
  pm_math_quatCompose(xx + 108, xx + 104, xx + 112);
  pm_math_quatInverseXform(xx + 104, xx + 100, xx + 60);
  xx[72] = xx[43] * xx[62];
  xx[73] = xx[45] * xx[62];
  xx[74] = - (xx[43] * xx[60] + xx[45] * xx[61]);
  pm_math_quatXform(xx + 112, xx + 72, xx + 83);
  xx[72] = xx[36] - xx[91];
  xx[73] = - (xx[39] + xx[103]);
  xx[74] = - (xx[47] + xx[97]);
  pm_math_cross3(xx + 100, xx + 72, xx + 89);
  pm_math_quatXform(xx + 108, xx + 89, xx + 97);
  pm_math_quatXform(xx + 108, xx + 69, xx + 89);
  xx[25] = xx[84] + xx[98] + xx[90];
  xx[46] = xx[43] * xx[115];
  xx[48] = xx[45] * xx[115];
  xx[49] = xx[43] * xx[113] + xx[45] * xx[114];
  xx[103] = xx[46];
  xx[104] = xx[48];
  xx[105] = - xx[49];
  pm_math_cross3(xx + 113, xx + 103, xx + 116);
  pm_math_quatXform(xx + 108, xx + 72, xx + 103);
  pm_math_quatXform(xx + 108, xx + 94, xx + 72);
  xx[55] = xx[45] + xx[1] * (xx[116] + xx[46] * xx[112]) + xx[103] - xx[72];
  xx[57] = xx[112] * xx[115];
  xx[87] = xx[1] * (xx[45] * xx[57] + xx[117]) - xx[43] + xx[104] - xx[73];
  xx[92] = xx[83] + xx[97] + xx[89];
  xx[93] = xx[55] * xx[55] + xx[87] * xx[87];
  xx[106] = xx[93] == 0.0 ? 0.0 : (xx[25] * xx[55] - xx[87] * xx[92]) / xx[93];
  xx[119] = xx[55];
  xx[120] = xx[87];
  xx[121] = xx[1] * (xx[118] - xx[49] * xx[112]) + xx[105] - xx[74];
  xx[49] = xx[19] * xx[114] - xx[21] * xx[113];
  xx[72] = xx[21] * xx[112] + xx[19] * xx[115];
  xx[73] = xx[72] * xx[72];
  xx[74] = xx[19] * xx[112] - xx[21] * xx[115];
  xx[103] = xx[74] * xx[72];
  xx[104] = xx[19] * xx[113] + xx[21] * xx[114];
  xx[105] = xx[49] * xx[104];
  xx[116] = xx[5] - xx[1] * (xx[49] * xx[49] + xx[73]);
  xx[117] = xx[1] * (xx[103] + xx[105]);
  xx[118] = xx[1] * (xx[72] * xx[104] - xx[49] * xx[74]);
  xx[107] = pm_math_dot3(xx + 119, xx + 116);
  xx[122] = xx[92];
  xx[123] = xx[25];
  xx[124] = xx[85] + xx[99] + xx[91];
  xx[83] = xx[1] * (xx[105] - xx[103]);
  xx[84] = xx[5] - xx[1] * (xx[73] + xx[104] * xx[104]);
  xx[85] = xx[1] * (xx[74] * xx[104] + xx[49] * xx[72]);
  xx[25] = xx[63] * xx[62];
  xx[49] = - (xx[53] * xx[62]);
  xx[72] = - xx[25];
  xx[73] = xx[49];
  xx[74] = xx[63] * xx[60] + xx[53] * xx[61];
  pm_math_quatXform(xx + 112, xx + 72, xx + 89);
  xx[62] = pm_math_dot3(xx + 119, xx + 83);
  xx[72] = xx[49];
  xx[73] = xx[25];
  xx[74] = xx[53] * xx[60] - xx[63] * xx[61];
  pm_math_quatXform(xx + 112, xx + 72, xx + 97);
  xx[25] = xx[107] * xx[107] + xx[62] * xx[62];
  xx[49] = xx[25] == 0.0 ? 0.0 : (xx[107] * (pm_math_dot3(xx + 122, xx + 83) +
    pm_math_dot3(xx + 119, xx + 89)) - xx[62] * (pm_math_dot3(xx + 122, xx + 116)
    + pm_math_dot3(xx + 119, xx + 97))) / xx[25];
  xx[60] = xx[45] * xx[113] - xx[43] * xx[114];
  xx[72] = - xx[48];
  xx[73] = xx[46];
  xx[74] = xx[60];
  pm_math_cross3(xx + 113, xx + 72, xx + 89);
  xx[72] = xx[64];
  xx[73] = xx[75];
  xx[74] = xx[88];
  pm_math_quatXform(xx + 108, xx + 72, xx + 97);
  xx[46] = xx[45] + xx[1] * (xx[43] * xx[57] + xx[90]) + xx[98];
  xx[61] = xx[43] + xx[1] * (xx[89] - xx[48] * xx[112]) + xx[97];
  xx[48] = xx[93] == 0.0 ? 0.0 : (xx[55] * xx[46] - xx[87] * xx[61]) / xx[93];
  xx[72] = xx[61];
  xx[73] = xx[46];
  xx[74] = xx[1] * (xx[60] * xx[112] + xx[91]) + xx[99];
  xx[46] = xx[53] * xx[115];
  xx[60] = xx[63] * xx[115];
  xx[61] = - xx[60];
  xx[64] = xx[63] * xx[114] - xx[53] * xx[113];
  xx[88] = xx[46];
  xx[89] = xx[61];
  xx[90] = xx[64];
  pm_math_cross3(xx + 113, xx + 88, xx + 91);
  xx[88] = xx[1] * (xx[91] + xx[46] * xx[112]) - xx[63];
  xx[89] = xx[1] * (xx[92] - xx[63] * xx[57]) - xx[53];
  xx[90] = xx[1] * (xx[64] * xx[112] + xx[93]);
  xx[64] = xx[63] * xx[113] + xx[53] * xx[114];
  xx[91] = xx[61];
  xx[92] = - xx[46];
  xx[93] = xx[64];
  pm_math_cross3(xx + 113, xx + 91, xx + 97);
  xx[91] = xx[1] * (xx[97] - xx[60] * xx[112]) - xx[53];
  xx[92] = xx[63] + xx[1] * (xx[98] - xx[53] * xx[57]);
  xx[93] = xx[1] * (xx[64] * xx[112] + xx[99]);
  xx[46] = xx[25] == 0.0 ? 0.0 : (xx[107] * (pm_math_dot3(xx + 72, xx + 83) +
    pm_math_dot3(xx + 119, xx + 88)) - xx[62] * (pm_math_dot3(xx + 72, xx + 116)
    + pm_math_dot3(xx + 119, xx + 91))) / xx[25];
  xx[88] = xx[0];
  xx[89] = xx[35] + xx[51];
  xx[90] = xx[42] + xx[29];
  xx[91] = xx[106] + xx[3] * xx[49];
  xx[92] = xx[48] + xx[3] * xx[46];
  xx[93] = xx[0];
  xx[25] = atan2(xx[26], xx[86]) - state[6];
  xx[26] = (xx[25] < 0.0 ? -1.0 : +1.0);
  xx[29] = state[6] + (fmod(xx[8] + xx[25] * xx[26], xx[23]) - xx[8]) * xx[26] -
    state[10] + atan2(xx[52], xx[44]);
  xx[25] = (xx[29] < 0.0 ? -1.0 : +1.0);
  xx[26] = atan2(xx[87], xx[55]) - state[8];
  xx[35] = (xx[26] < 0.0 ? -1.0 : +1.0);
  xx[42] = (state[8] + (fmod(xx[8] + xx[26] * xx[35], xx[23]) - xx[8]) * xx[35]
            - state[11]) / xx[3] + atan2(xx[62], xx[107]);
  xx[26] = (xx[42] < 0.0 ? -1.0 : +1.0);
  xx[48] = - ((fmod(xx[8] + xx[25] * xx[29], xx[23]) - xx[8]) * xx[25]);
  xx[49] = - (xx[3] * (fmod(xx[8] + xx[26] * xx[42], xx[23]) - xx[8]) * xx[26]);
  memcpy(xx + 103, xx + 88, 6 * sizeof(double));
  factorAndSolveWide(2, 3, xx + 103, xx + 25, xx + 51, ii + 0, xx + 48, xx[17],
                     xx + 60);
  xx[25] = xx[22] + xx[60];
  xx[22] = xx[24] + xx[61];
  xx[24] = xx[28] + xx[62];
  xx[103] = xx[25];
  xx[104] = state[1];
  xx[105] = xx[22];
  xx[106] = state[3];
  xx[107] = xx[24];
  xx[108] = state[5];
  xx[109] = state[6];
  xx[110] = state[7];
  xx[111] = state[8];
  xx[112] = state[9];
  xx[113] = state[10];
  xx[114] = state[11];
  xx[26] = xx[3] * xx[24];
  xx[24] = cos(xx[26]);
  xx[28] = sin(xx[26]);
  xx[26] = xx[7] * xx[28];
  xx[29] = xx[10] * xx[28];
  xx[28] = xx[2] * xx[24] - xx[6] * xx[26] + xx[9] * xx[29];
  xx[35] = xx[9] * xx[24] + xx[12] * xx[26] - xx[2] * xx[29];
  xx[42] = xx[6] * xx[29] - xx[12] * xx[24] + xx[9] * xx[26];
  xx[60] = xx[28];
  xx[61] = xx[35];
  xx[62] = xx[42];
  xx[44] = xx[18] * xx[35];
  xx[46] = xx[20] * xx[42] + xx[18] * xx[28];
  xx[48] = xx[20] * xx[35];
  xx[72] = - xx[44];
  xx[73] = xx[46];
  xx[74] = - xx[48];
  pm_math_cross3(xx + 60, xx + 72, xx + 83);
  xx[49] = xx[6] * xx[24] + xx[2] * xx[26] + xx[12] * xx[29];
  xx[24] = xx[4] * xx[35];
  xx[26] = xx[11] * xx[42] - xx[4] * xx[28];
  xx[29] = xx[11] * xx[35];
  xx[72] = xx[24];
  xx[73] = xx[26];
  xx[74] = - xx[29];
  pm_math_cross3(xx + 60, xx + 72, xx + 86);
  xx[51] = xx[3] * xx[22];
  xx[22] = cos(xx[51]);
  xx[52] = sin(xx[51]);
  xx[51] = xx[16] * xx[22] - xx[30] * xx[52];
  xx[55] = xx[30] * xx[22] + xx[16] * xx[52];
  xx[57] = - xx[55];
  xx[60] = xx[37] * xx[22] - xx[38] * xx[52];
  xx[72] = xx[51];
  xx[73] = xx[57];
  xx[74] = xx[60];
  xx[61] = xx[43] * xx[60];
  xx[62] = xx[45] * xx[60];
  xx[64] = xx[45] * xx[55] - xx[43] * xx[51];
  xx[89] = xx[61];
  xx[90] = xx[62];
  xx[91] = xx[64];
  pm_math_cross3(xx + 72, xx + 89, xx + 97);
  xx[72] = xx[38] * xx[22] + xx[37] * xx[52];
  xx[22] = xx[1] * (xx[97] - xx[61] * xx[72]);
  xx[52] = xx[45] + xx[22];
  xx[61] = xx[1] * (xx[98] - xx[62] * xx[72]);
  xx[62] = xx[61] - xx[43];
  xx[73] = xx[1] * (xx[99] - xx[64] * xx[72]);
  xx[89] = xx[1] * (xx[83] - xx[44] * xx[49]) - xx[1] * (xx[24] * xx[49] + xx[86])
    + xx[15] - (xx[22] - xx[52] + xx[50]);
  xx[90] = xx[1] * (xx[49] * xx[46] + xx[84]) - xx[1] * (xx[49] * xx[26] + xx[87])
    + xx[54] - (xx[61] - xx[62] - xx[58]);
  xx[91] = xx[1] * (xx[85] - xx[48] * xx[49]) - xx[1] * (xx[88] - xx[29] * xx[49])
    - xx[59] - (xx[73] - xx[73] - xx[47]);
  xx[22] = xx[19] * xx[72] + xx[21] * xx[60];
  xx[24] = xx[19] * xx[60] - xx[21] * xx[72];
  xx[26] = xx[22] * xx[24];
  xx[29] = xx[19] * xx[55] + xx[21] * xx[51];
  xx[44] = xx[19] * xx[51] - xx[21] * xx[55];
  xx[46] = xx[29] * xx[44];
  xx[48] = xx[24] * xx[24];
  xx[83] = xx[1] * (xx[26] - xx[46]);
  xx[84] = xx[5] - xx[1] * (xx[48] + xx[44] * xx[44]);
  xx[85] = - (xx[1] * (xx[22] * xx[44] + xx[29] * xx[24]));
  xx[86] = xx[5] - xx[1] * (xx[29] * xx[29] + xx[48]);
  xx[87] = - (xx[1] * (xx[26] + xx[46]));
  xx[88] = xx[1] * (xx[24] * xx[44] - xx[29] * xx[22]);
  xx[22] = atan2(pm_math_dot3(xx + 89, xx + 83), pm_math_dot3(xx + 89, xx + 86))
    - state[6];
  xx[24] = (xx[22] < 0.0 ? -1.0 : +1.0);
  xx[83] = xx[49];
  xx[84] = xx[28];
  xx[85] = xx[35];
  xx[86] = xx[42];
  pm_math_quatCompose(xx + 83, xx + 79, xx + 115);
  xx[26] = xx[116] * xx[117];
  xx[28] = xx[115] * xx[118];
  xx[29] = xx[118] * xx[118];
  xx[83] = xx[1] * (xx[26] - xx[28]);
  xx[84] = xx[5] - xx[1] * (xx[29] + xx[116] * xx[116]);
  xx[85] = xx[1] * (xx[115] * xx[116] + xx[117] * xx[118]);
  xx[86] = xx[5] - xx[1] * (xx[117] * xx[117] + xx[29]);
  xx[87] = xx[1] * (xx[28] + xx[26]);
  xx[88] = xx[1] * (xx[116] * xx[118] - xx[115] * xx[117]);
  xx[26] = state[6] + (fmod(xx[8] + xx[22] * xx[24], xx[23]) - xx[8]) * xx[24] -
    state[10] + atan2(pm_math_dot3(xx + 89, xx + 83), pm_math_dot3(xx + 89, xx +
    86));
  xx[22] = (xx[26] < 0.0 ? -1.0 : +1.0);
  xx[24] = xx[3] * xx[25];
  xx[25] = sin(xx[24]);
  xx[83] = cos(xx[24]);
  xx[84] = xx[27] * xx[25];
  xx[85] = xx[40] * xx[25];
  xx[86] = xx[41] * xx[25];
  pm_math_quatCompose(xx + 65, xx + 83, xx + 87);
  xx[83] = - xx[72];
  xx[84] = xx[51];
  xx[85] = xx[57];
  xx[86] = xx[60];
  pm_math_quatCompose(xx + 87, xx + 83, xx + 115);
  xx[24] = xx[43] * xx[118];
  xx[25] = xx[43] * xx[116] + xx[45] * xx[117];
  xx[83] = xx[24];
  xx[84] = xx[45] * xx[118];
  xx[85] = - xx[25];
  pm_math_cross3(xx + 116, xx + 83, xx + 91);
  xx[83] = xx[36] - xx[52];
  xx[84] = - (xx[39] + xx[62]);
  xx[85] = - (xx[47] + xx[73]);
  pm_math_quatXform(xx + 87, xx + 83, xx + 60);
  pm_math_quatXform(xx + 87, xx + 94, xx + 72);
  xx[28] = xx[1] * (xx[45] * xx[115] * xx[118] + xx[92]) - xx[43] + xx[61] - xx
    [73];
  xx[29] = xx[45] + xx[1] * (xx[91] + xx[24] * xx[115]) + xx[60] - xx[72];
  xx[24] = atan2(xx[28], xx[29]) - state[8];
  xx[35] = (xx[24] < 0.0 ? -1.0 : +1.0);
  xx[83] = xx[29];
  xx[84] = xx[28];
  xx[85] = xx[1] * (xx[93] - xx[25] * xx[115]) + xx[62] - xx[74];
  xx[25] = xx[19] * xx[117] - xx[21] * xx[116];
  xx[28] = xx[19] * xx[116] + xx[21] * xx[117];
  xx[29] = xx[25] * xx[28];
  xx[42] = xx[19] * xx[115] - xx[21] * xx[118];
  xx[44] = xx[21] * xx[115] + xx[19] * xx[118];
  xx[46] = xx[42] * xx[44];
  xx[48] = xx[44] * xx[44];
  xx[60] = xx[1] * (xx[29] - xx[46]);
  xx[61] = xx[5] - xx[1] * (xx[48] + xx[28] * xx[28]);
  xx[62] = xx[1] * (xx[42] * xx[28] + xx[25] * xx[44]);
  xx[72] = xx[5] - xx[1] * (xx[25] * xx[25] + xx[48]);
  xx[73] = xx[1] * (xx[46] + xx[29]);
  xx[74] = xx[1] * (xx[28] * xx[44] - xx[25] * xx[42]);
  xx[25] = (state[8] + (fmod(xx[8] + xx[24] * xx[35], xx[23]) - xx[8]) * xx[35]
            - state[11]) / xx[3] + atan2(pm_math_dot3(xx + 83, xx + 60),
    pm_math_dot3(xx + 83, xx + 72));
  xx[24] = (xx[25] < 0.0 ? -1.0 : +1.0);
  xx[28] = fabs((fmod(xx[8] + xx[22] * xx[26], xx[23]) - xx[8]) * xx[22]);
  xx[29] = fabs(xx[3] * (fmod(xx[8] + xx[24] * xx[25], xx[23]) - xx[8]) * xx[24]);
  ii[0] = 28;

  {
    int ll;
    for (ll = 29; ll < 30; ++ll)
      if (xx[ll] > xx[ii[0]])
        ii[0] = ll;
  }

  ii[0] -= 28;
  xx[22] = xx[28 + (ii[0])];
  xx[24] = 1.0e-5;
  xx[25] = xx[22] - xx[24];
  if (xx[25] < 0.0)
    ii[1] = -1;
  else if (xx[25] > 0.0)
    ii[1] = +1;
  else
    ii[1] = 0;
  ii[2] = ii[1];
  if (0 > ii[2])
    ii[2] = 0;
  if (ii[2] != 0) {
    switch (ii[0])
    {
     case 0:
      {
        return sm_ssci_recordRunTimeError(
          "sm:compiler:messages:simulationErrors:ConstraintViolation",
          "'sm_cardan_gear/PlanetA- PlanetB Gear' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem.",
          neDiagMgr);
      }

     case 1:
      {
        return sm_ssci_recordRunTimeError(
          "sm:compiler:messages:simulationErrors:ConstraintViolation",
          "'sm_cardan_gear/Sun-PlanetA Gear' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem.",
          neDiagMgr);
      }
    }
  }

  xx[22] = xx[3] * xx[107];
  xx[25] = cos(xx[22]);
  xx[26] = sin(xx[22]);
  xx[22] = xx[7] * xx[26];
  xx[28] = xx[10] * xx[26];
  xx[26] = xx[2] * xx[25] - xx[6] * xx[22] + xx[9] * xx[28];
  xx[29] = xx[9] * xx[25] + xx[12] * xx[22] - xx[2] * xx[28];
  xx[35] = xx[6] * xx[28] - xx[12] * xx[25] + xx[9] * xx[22];
  xx[60] = xx[26];
  xx[61] = xx[29];
  xx[62] = xx[35];
  xx[42] = xx[18] * xx[29];
  xx[44] = xx[20] * xx[35] + xx[18] * xx[26];
  xx[46] = xx[20] * xx[29];
  xx[72] = - xx[42];
  xx[73] = xx[44];
  xx[74] = - xx[46];
  pm_math_cross3(xx + 60, xx + 72, xx + 83);
  xx[48] = xx[6] * xx[25] + xx[2] * xx[22] + xx[12] * xx[28];
  xx[22] = xx[4] * xx[29];
  xx[25] = xx[11] * xx[35] - xx[4] * xx[26];
  xx[28] = xx[11] * xx[29];
  xx[72] = xx[22];
  xx[73] = xx[25];
  xx[74] = - xx[28];
  pm_math_cross3(xx + 60, xx + 72, xx + 86);
  xx[49] = xx[3] * xx[105];
  xx[51] = cos(xx[49]);
  xx[52] = sin(xx[49]);
  xx[49] = xx[16] * xx[51] - xx[30] * xx[52];
  xx[55] = xx[30] * xx[51] + xx[16] * xx[52];
  xx[57] = - xx[55];
  xx[60] = xx[37] * xx[51] - xx[38] * xx[52];
  xx[72] = xx[49];
  xx[73] = xx[57];
  xx[74] = xx[60];
  xx[61] = xx[43] * xx[60];
  xx[62] = xx[45] * xx[60];
  xx[64] = xx[45] * xx[55] - xx[43] * xx[49];
  xx[89] = xx[61];
  xx[90] = xx[62];
  xx[91] = xx[64];
  pm_math_cross3(xx + 72, xx + 89, xx + 97);
  xx[75] = xx[38] * xx[51] + xx[37] * xx[52];
  xx[51] = xx[61] * xx[75];
  xx[52] = xx[1] * (xx[97] - xx[51]);
  xx[89] = xx[45] + xx[52];
  xx[90] = xx[62] * xx[75];
  xx[91] = xx[1] * (xx[98] - xx[90]);
  xx[92] = xx[91] - xx[43];
  xx[93] = xx[1] * (xx[99] - xx[64] * xx[75]);
  xx[97] = xx[1] * (xx[83] - xx[42] * xx[48]) - xx[1] * (xx[22] * xx[48] + xx[86])
    + xx[15] - (xx[52] - xx[89] + xx[50]);
  xx[98] = xx[1] * (xx[48] * xx[44] + xx[84]) - xx[1] * (xx[48] * xx[25] + xx[87])
    + xx[54] - (xx[91] - xx[92] - xx[58]);
  xx[99] = xx[1] * (xx[85] - xx[46] * xx[48]) - xx[1] * (xx[88] - xx[28] * xx[48])
    - xx[59] - (xx[93] - xx[93] - xx[47]);
  xx[22] = xx[19] * xx[55] + xx[21] * xx[49];
  xx[25] = xx[19] * xx[60] - xx[21] * xx[75];
  xx[28] = xx[25] * xx[25];
  xx[42] = xx[19] * xx[75] + xx[21] * xx[60];
  xx[44] = xx[42] * xx[25];
  xx[46] = xx[19] * xx[49] - xx[21] * xx[55];
  xx[52] = xx[22] * xx[46];
  xx[83] = xx[5] - xx[1] * (xx[22] * xx[22] + xx[28]);
  xx[84] = - (xx[1] * (xx[44] + xx[52]));
  xx[85] = xx[1] * (xx[25] * xx[46] - xx[42] * xx[22]);
  xx[64] = pm_math_dot3(xx + 97, xx + 83);
  xx[86] = xx[53] * xx[60];
  xx[87] = xx[63] * xx[60];
  xx[88] = - xx[87];
  xx[91] = xx[53] * xx[49] + xx[63] * xx[55];
  xx[115] = xx[86];
  xx[116] = xx[88];
  xx[117] = - xx[91];
  pm_math_cross3(xx + 72, xx + 115, xx + 118);
  xx[115] = xx[86] * xx[75];
  xx[116] = xx[87] * xx[75];
  xx[121] = xx[1] * (xx[118] - xx[115]) - xx[63];
  xx[122] = xx[1] * (xx[116] + xx[119]) - xx[53];
  xx[123] = xx[1] * (xx[75] * xx[91] + xx[120]);
  xx[87] = xx[45] * xx[49];
  xx[91] = xx[43] * xx[55];
  xx[117] = xx[87] + xx[91];
  xx[118] = - xx[62];
  xx[119] = xx[61];
  xx[120] = xx[117];
  pm_math_cross3(xx + 72, xx + 118, xx + 124);
  xx[118] = xx[87] + xx[91];
  xx[127] = xx[62];
  xx[128] = - xx[61];
  xx[129] = - xx[118];
  pm_math_cross3(xx + 72, xx + 127, xx + 130);
  xx[61] = xx[1] * (xx[130] - xx[90]) - xx[43];
  xx[62] = xx[1] * (xx[51] + xx[131]) - xx[45];
  xx[87] = xx[75] * xx[118] + xx[132];
  xx[91] = xx[1] * xx[87];
  xx[118] = xx[43] + xx[1] * (xx[124] + xx[90]) + xx[61];
  xx[119] = xx[45] + xx[1] * (xx[125] - xx[51]) + xx[62];
  xx[120] = xx[1] * (xx[126] - xx[75] * xx[117]) + xx[91];
  xx[124] = xx[1] * (xx[44] - xx[52]);
  xx[125] = xx[5] - xx[1] * (xx[28] + xx[46] * xx[46]);
  xx[126] = - (xx[1] * (xx[42] * xx[46] + xx[22] * xx[25]));
  xx[22] = pm_math_dot3(xx + 97, xx + 124);
  xx[25] = xx[63] * xx[49] - xx[53] * xx[55];
  xx[127] = xx[88];
  xx[128] = - xx[86];
  xx[129] = xx[25];
  pm_math_cross3(xx + 72, xx + 127, xx + 130);
  xx[127] = xx[1] * (xx[130] + xx[116]) - xx[53];
  xx[128] = xx[63] + xx[1] * (xx[115] + xx[131]);
  xx[129] = xx[1] * (xx[132] - xx[75] * xx[25]);
  xx[25] = xx[64] * xx[64] + xx[22] * xx[22];
  xx[28] = xx[25] == 0.0 ? 0.0 : (xx[64] * (pm_math_dot3(xx + 97, xx + 121) -
    pm_math_dot3(xx + 118, xx + 124)) - xx[22] * (pm_math_dot3(xx + 97, xx + 127)
    - pm_math_dot3(xx + 118, xx + 83))) / xx[25];
  xx[127] = xx[48];
  xx[128] = xx[26];
  xx[129] = xx[29];
  xx[130] = xx[35];
  pm_math_quatCompose(xx + 127, xx + 79, xx + 131);
  xx[42] = xx[132] * xx[133];
  xx[44] = xx[131] * xx[134];
  xx[46] = xx[134] * xx[134];
  xx[79] = xx[1] * (xx[42] - xx[44]);
  xx[80] = xx[5] - xx[1] * (xx[46] + xx[132] * xx[132]);
  xx[81] = xx[1] * (xx[131] * xx[132] + xx[133] * xx[134]);
  xx[51] = pm_math_dot3(xx + 97, xx + 79);
  xx[115] = xx[5] - xx[1] * (xx[133] * xx[133] + xx[46]);
  xx[116] = xx[1] * (xx[44] + xx[42]);
  xx[117] = xx[1] * (xx[132] * xx[134] - xx[131] * xx[133]);
  xx[42] = pm_math_dot3(xx + 97, xx + 115);
  xx[44] = xx[42] * xx[42] + xx[51] * xx[51];
  xx[46] = xx[44] == 0.0 ? 0.0 : (xx[51] * pm_math_dot3(xx + 118, xx + 115) -
    xx[42] * pm_math_dot3(xx + 118, xx + 79)) / xx[44];
  xx[52] = xx[31] * xx[26];
  xx[82] = xx[31] * xx[35];
  xx[86] = xx[56] * xx[35];
  xx[88] = xx[56] * xx[26];
  xx[90] = xx[86] * xx[48] - xx[88] * xx[29];
  xx[118] = xx[1] * xx[90];
  xx[119] = xx[1] * (xx[86] * xx[35] + xx[88] * xx[26]) - xx[56];
  xx[56] = xx[88] * xx[48] + xx[86] * xx[29];
  xx[86] = xx[1] * xx[56];
  xx[120] = xx[1] * (xx[52] * xx[29] - xx[82] * xx[48]) + xx[118];
  xx[121] = xx[31] - xx[1] * (xx[82] * xx[35] + xx[52] * xx[26]) + xx[119];
  xx[122] = xx[1] * (xx[52] * xx[48] + xx[82] * xx[29]) - xx[86];
  xx[31] = xx[25] == 0.0 ? 0.0 : (xx[64] * pm_math_dot3(xx + 120, xx + 124) -
    xx[22] * pm_math_dot3(xx + 120, xx + 83)) / xx[25];
  pm_math_quatXform(xx + 127, xx + 32, xx + 131);
  pm_math_quatXform(xx + 127, xx + 76, xx + 32);
  xx[52] = xx[44] == 0.0 ? 0.0 : (xx[42] * (pm_math_dot3(xx + 120, xx + 79) +
    pm_math_dot3(xx + 97, xx + 131)) - xx[51] * (pm_math_dot3(xx + 120, xx + 115)
    + pm_math_dot3(xx + 97, xx + 32))) / xx[44];
  xx[32] = xx[3] * xx[103];
  xx[33] = sin(xx[32]);
  xx[120] = cos(xx[32]);
  xx[121] = xx[27] * xx[33];
  xx[122] = xx[40] * xx[33];
  xx[123] = xx[41] * xx[33];
  pm_math_quatCompose(xx + 65, xx + 120, xx + 131);
  xx[120] = - xx[75];
  xx[121] = xx[49];
  xx[122] = xx[57];
  xx[123] = xx[60];
  pm_math_quatCompose(xx + 131, xx + 120, xx + 135);
  xx[32] = xx[43] * xx[138];
  xx[33] = xx[45] * xx[138];
  xx[34] = xx[43] * xx[136] + xx[45] * xx[137];
  xx[76] = xx[32];
  xx[77] = xx[33];
  xx[78] = - xx[34];
  pm_math_cross3(xx + 136, xx + 76, xx + 139);
  xx[76] = xx[36] - xx[89];
  xx[77] = - (xx[39] + xx[92]);
  xx[78] = - (xx[47] + xx[93]);
  pm_math_quatXform(xx + 131, xx + 76, xx + 142);
  pm_math_quatXform(xx + 131, xx + 94, xx + 145);
  xx[57] = xx[45] + xx[1] * (xx[139] + xx[32] * xx[135]) + xx[142] - xx[145];
  pm_math_quatInverseXform(xx + 120, xx + 100, xx + 148);
  xx[151] = xx[43] * xx[150];
  xx[152] = xx[45] * xx[150];
  xx[153] = - (xx[43] * xx[148] + xx[45] * xx[149]);
  pm_math_quatXform(xx + 135, xx + 151, xx + 154);
  pm_math_cross3(xx + 100, xx + 76, xx + 151);
  pm_math_quatXform(xx + 131, xx + 151, xx + 100);
  pm_math_quatXform(xx + 131, xx + 69, xx + 151);
  xx[69] = xx[155] + xx[101] + xx[152];
  xx[70] = xx[135] * xx[138];
  xx[71] = xx[1] * (xx[45] * xx[70] + xx[140]) - xx[43] + xx[143] - xx[146];
  xx[82] = xx[154] + xx[100] + xx[151];
  xx[88] = xx[57] * xx[57] + xx[71] * xx[71];
  xx[89] = xx[88] == 0.0 ? 0.0 : (xx[57] * xx[69] - xx[71] * xx[82]) / xx[88];
  xx[157] = xx[57];
  xx[158] = xx[71];
  xx[159] = xx[1] * (xx[141] - xx[34] * xx[135]) + xx[144] - xx[147];
  xx[34] = xx[19] * xx[137] - xx[21] * xx[136];
  xx[92] = xx[21] * xx[135] + xx[19] * xx[138];
  xx[93] = xx[92] * xx[92];
  xx[139] = xx[19] * xx[135] - xx[21] * xx[138];
  xx[140] = xx[139] * xx[92];
  xx[141] = xx[19] * xx[136] + xx[21] * xx[137];
  xx[142] = xx[34] * xx[141];
  xx[143] = xx[5] - xx[1] * (xx[34] * xx[34] + xx[93]);
  xx[144] = xx[1] * (xx[140] + xx[142]);
  xx[145] = xx[1] * (xx[92] * xx[141] - xx[34] * xx[139]);
  xx[146] = pm_math_dot3(xx + 157, xx + 143);
  xx[160] = xx[82];
  xx[161] = xx[69];
  xx[162] = xx[156] + xx[102] + xx[153];
  xx[100] = xx[1] * (xx[142] - xx[140]);
  xx[101] = xx[5] - xx[1] * (xx[93] + xx[141] * xx[141]);
  xx[102] = xx[1] * (xx[139] * xx[141] + xx[34] * xx[92]);
  xx[34] = xx[63] * xx[150];
  xx[69] = - (xx[53] * xx[150]);
  xx[139] = - xx[34];
  xx[140] = xx[69];
  xx[141] = xx[63] * xx[148] + xx[53] * xx[149];
  pm_math_quatXform(xx + 135, xx + 139, xx + 154);
  xx[82] = pm_math_dot3(xx + 157, xx + 100);
  xx[139] = xx[69];
  xx[140] = xx[34];
  xx[141] = xx[53] * xx[148] - xx[63] * xx[149];
  pm_math_quatXform(xx + 135, xx + 139, xx + 147);
  xx[34] = xx[146] * xx[146] + xx[82] * xx[82];
  xx[69] = xx[34] == 0.0 ? 0.0 : (xx[146] * (pm_math_dot3(xx + 160, xx + 100) +
    pm_math_dot3(xx + 157, xx + 154)) - xx[82] * (pm_math_dot3(xx + 160, xx +
    143) + pm_math_dot3(xx + 157, xx + 147))) / xx[34];
  xx[92] = xx[45] * xx[136] - xx[43] * xx[137];
  xx[139] = - xx[33];
  xx[140] = xx[32];
  xx[141] = xx[92];
  pm_math_cross3(xx + 136, xx + 139, xx + 147);
  xx[139] = xx[61];
  xx[140] = xx[62];
  xx[141] = xx[91];
  pm_math_quatXform(xx + 131, xx + 139, xx + 154);
  xx[32] = xx[45] + xx[1] * (xx[43] * xx[70] + xx[148]) + xx[155];
  xx[93] = xx[43] + xx[1] * (xx[147] - xx[33] * xx[135]) + xx[154];
  xx[33] = xx[88] == 0.0 ? 0.0 : (xx[57] * xx[32] - xx[71] * xx[93]) / xx[88];
  xx[139] = xx[93];
  xx[140] = xx[32];
  xx[141] = xx[1] * (xx[92] * xx[135] + xx[149]) + xx[156];
  xx[32] = xx[53] * xx[138];
  xx[92] = xx[63] * xx[138];
  xx[93] = - xx[92];
  xx[142] = xx[63] * xx[137] - xx[53] * xx[136];
  xx[147] = xx[32];
  xx[148] = xx[93];
  xx[149] = xx[142];
  pm_math_cross3(xx + 136, xx + 147, xx + 154);
  xx[147] = xx[1] * (xx[154] + xx[32] * xx[135]) - xx[63];
  xx[148] = xx[1] * (xx[155] - xx[63] * xx[70]) - xx[53];
  xx[149] = xx[1] * (xx[142] * xx[135] + xx[156]);
  xx[142] = xx[63] * xx[136] + xx[53] * xx[137];
  xx[154] = xx[93];
  xx[155] = - xx[32];
  xx[156] = xx[142];
  pm_math_cross3(xx + 136, xx + 154, xx + 160);
  xx[154] = xx[1] * (xx[160] - xx[92] * xx[135]) - xx[53];
  xx[155] = xx[63] + xx[1] * (xx[161] - xx[53] * xx[70]);
  xx[156] = xx[1] * (xx[142] * xx[135] + xx[162]);
  xx[32] = xx[34] == 0.0 ? 0.0 : (xx[146] * (pm_math_dot3(xx + 139, xx + 100) +
    pm_math_dot3(xx + 157, xx + 147)) - xx[82] * (pm_math_dot3(xx + 139, xx +
    143) + pm_math_dot3(xx + 157, xx + 154))) / xx[34];
  xx[160] = xx[0];
  xx[161] = xx[28] + xx[46];
  xx[162] = xx[31] + xx[52];
  xx[163] = xx[89] + xx[3] * xx[69];
  xx[164] = xx[33] + xx[3] * xx[32];
  xx[165] = xx[0];
  xx[0] = xx[10] * xx[108];
  xx[28] = xx[7] * xx[108];
  xx[31] = xx[20] * xx[0] - xx[18] * xx[28];
  xx[32] = xx[31] * xx[26];
  xx[33] = xx[35] * xx[31];
  xx[46] = xx[45] * xx[106];
  xx[52] = xx[46] * xx[60];
  xx[69] = xx[43] * xx[106];
  xx[70] = xx[69] * xx[60];
  xx[89] = xx[46] * xx[49] + xx[69] * xx[55];
  xx[139] = - xx[52];
  xx[140] = xx[70];
  xx[141] = xx[89];
  pm_math_cross3(xx + 72, xx + 139, xx + 147);
  xx[92] = xx[61] * xx[106];
  xx[93] = xx[62] * xx[106];
  xx[139] = xx[1] * xx[87] * xx[106];
  xx[140] = xx[1] * (xx[32] * xx[29] - xx[33] * xx[48]) + xx[1] * xx[90] * xx
    [108] - (xx[1] * (xx[147] + xx[52] * xx[75]) + xx[69] + xx[92]);
  xx[141] = xx[31] - xx[1] * (xx[33] * xx[35] + xx[32] * xx[26]) + xx[119] * xx
    [108] - (xx[46] + xx[1] * (xx[148] - xx[70] * xx[75]) + xx[93]);
  xx[142] = xx[1] * (xx[32] * xx[48] + xx[33] * xx[29]) - xx[1] * xx[56] * xx
    [108] - (xx[1] * (xx[149] - xx[75] * xx[89]) + xx[139]);
  xx[31] = xx[53] * xx[106];
  xx[32] = xx[31] * xx[60];
  xx[33] = xx[63] * xx[106];
  xx[46] = xx[33] * xx[60];
  xx[52] = - xx[46];
  xx[56] = xx[31] * xx[49] + xx[33] * xx[55];
  xx[147] = xx[32];
  xx[148] = xx[52];
  xx[149] = - xx[56];
  pm_math_cross3(xx + 72, xx + 147, xx + 154);
  xx[69] = xx[32] * xx[75];
  xx[70] = xx[46] * xx[75];
  xx[147] = xx[1] * (xx[154] - xx[69]) - xx[33];
  xx[148] = xx[1] * (xx[155] + xx[70]) - xx[31];
  xx[149] = xx[1] * (xx[75] * xx[56] + xx[156]);
  xx[46] = xx[33] * xx[49] - xx[31] * xx[55];
  xx[154] = xx[52];
  xx[155] = - xx[32];
  xx[156] = xx[46];
  pm_math_cross3(xx + 72, xx + 154, xx + 166);
  xx[154] = xx[1] * (xx[166] + xx[70]) - xx[31];
  xx[155] = xx[33] + xx[1] * (xx[167] + xx[69]);
  xx[156] = xx[1] * (xx[168] - xx[75] * xx[46]);
  xx[31] = xx[25] == 0.0 ? 0.0 : (xx[64] * (pm_math_dot3(xx + 140, xx + 124) +
    pm_math_dot3(xx + 97, xx + 147)) - xx[22] * (pm_math_dot3(xx + 140, xx + 83)
    + pm_math_dot3(xx + 97, xx + 154))) / xx[25];
  xx[32] = 0.8320502943378443;
  xx[33] = 0.5453613280205318;
  xx[46] = 0.1013574348135827;
  xx[147] = - (xx[32] * xx[0]);
  xx[148] = - (xx[33] * xx[0] + xx[46] * xx[28]);
  xx[149] = - (xx[32] * xx[28]);
  pm_math_quatXform(xx + 127, xx + 147, xx + 154);
  xx[52] = 0.1520361522203757;
  xx[147] = - (xx[14] * xx[0]);
  xx[148] = xx[13] * xx[0] + xx[52] * xx[28];
  xx[149] = - (xx[14] * xx[28]);
  pm_math_quatXform(xx + 127, xx + 147, xx + 166);
  xx[0] = xx[44] == 0.0 ? 0.0 : (xx[42] * (pm_math_dot3(xx + 140, xx + 79) +
    pm_math_dot3(xx + 97, xx + 154)) - xx[51] * (pm_math_dot3(xx + 140, xx + 115)
    + pm_math_dot3(xx + 97, xx + 166))) / xx[44];
  xx[140] = xx[27] * xx[104];
  xx[141] = xx[40] * xx[104];
  xx[142] = xx[41] * xx[104];
  pm_math_quatInverseXform(xx + 120, xx + 140, xx + 147);
  xx[28] = xx[149] + xx[106];
  xx[154] = xx[43] * xx[28];
  xx[155] = xx[45] * xx[28];
  xx[156] = - (xx[43] * xx[147] + xx[45] * xx[148]);
  pm_math_quatXform(xx + 135, xx + 154, xx + 166);
  pm_math_cross3(xx + 140, xx + 76, xx + 154);
  xx[140] = xx[92] + xx[154];
  xx[141] = xx[93] + xx[155];
  xx[142] = xx[139] + xx[156];
  pm_math_quatXform(xx + 131, xx + 140, xx + 154);
  xx[56] = xx[167] + xx[104] * xx[152] + xx[155];
  xx[69] = xx[166] + xx[104] * xx[151] + xx[154];
  xx[70] = xx[88] == 0.0 ? 0.0 : (xx[57] * xx[56] - xx[71] * xx[69]) / xx[88];
  xx[139] = xx[69];
  xx[140] = xx[56];
  xx[141] = xx[168] + xx[104] * xx[153] + xx[156];
  xx[56] = xx[63] * xx[28];
  xx[69] = - (xx[53] * xx[28]);
  xx[154] = - xx[56];
  xx[155] = xx[69];
  xx[156] = xx[63] * xx[147] + xx[53] * xx[148];
  pm_math_quatXform(xx + 135, xx + 154, xx + 166);
  xx[154] = xx[69];
  xx[155] = xx[56];
  xx[156] = xx[53] * xx[147] - xx[63] * xx[148];
  pm_math_quatXform(xx + 135, xx + 154, xx + 147);
  xx[28] = xx[34] == 0.0 ? 0.0 : (xx[146] * (pm_math_dot3(xx + 139, xx + 100) +
    pm_math_dot3(xx + 157, xx + 166)) - xx[82] * (pm_math_dot3(xx + 139, xx +
    143) + pm_math_dot3(xx + 157, xx + 147))) / xx[34];
  xx[89] = - (xx[31] + xx[0]);
  xx[90] = - (xx[70] + xx[3] * xx[28]);
  memcpy(xx + 166, xx + 160, 6 * sizeof(double));
  factorAndSolveWide(2, 3, xx + 166, xx + 69, xx + 92, ii + 0, xx + 89, xx[17],
                     xx + 139);
  xx[0] = xx[104] + xx[139];
  xx[17] = xx[106] + xx[140];
  xx[28] = xx[108] + xx[141];
  xx[160] = xx[103];
  xx[161] = xx[0];
  xx[162] = xx[105];
  xx[163] = xx[17];
  xx[164] = xx[107];
  xx[165] = xx[28];
  xx[166] = xx[109];
  xx[167] = xx[110];
  xx[168] = xx[111];
  xx[169] = xx[112];
  xx[170] = xx[113];
  xx[171] = xx[114];
  xx[31] = xx[10] * xx[28];
  xx[56] = xx[7] * xx[28];
  xx[69] = xx[20] * xx[31] - xx[18] * xx[56];
  xx[70] = xx[69] * xx[26];
  xx[87] = xx[69] * xx[35];
  xx[89] = xx[45] * xx[17];
  xx[90] = xx[89] * xx[60];
  xx[92] = xx[43] * xx[17];
  xx[93] = xx[92] * xx[60];
  xx[103] = xx[89] * xx[49] + xx[92] * xx[55];
  xx[104] = - xx[90];
  xx[105] = xx[93];
  xx[106] = xx[103];
  pm_math_cross3(xx + 72, xx + 104, xx + 107);
  xx[104] = xx[61] * xx[17];
  xx[61] = xx[62] * xx[17];
  xx[62] = xx[91] * xx[17];
  xx[110] = xx[1] * (xx[70] * xx[29] - xx[87] * xx[48]) + xx[118] * xx[28] -
    (xx[1] * (xx[107] + xx[90] * xx[75]) + xx[92] + xx[104]);
  xx[111] = xx[69] - xx[1] * (xx[87] * xx[35] + xx[70] * xx[26]) + xx[119] * xx
    [28] - (xx[89] + xx[1] * (xx[108] - xx[93] * xx[75]) + xx[61]);
  xx[112] = xx[1] * (xx[70] * xx[48] + xx[87] * xx[29]) - xx[86] * xx[28] - (xx
    [1] * (xx[109] - xx[75] * xx[103]) + xx[62]);
  xx[26] = xx[53] * xx[17];
  xx[28] = xx[26] * xx[60];
  xx[29] = xx[63] * xx[17];
  xx[35] = xx[29] * xx[60];
  xx[48] = - xx[35];
  xx[60] = xx[26] * xx[49] + xx[29] * xx[55];
  xx[89] = xx[28];
  xx[90] = xx[48];
  xx[91] = - xx[60];
  pm_math_cross3(xx + 72, xx + 89, xx + 105);
  xx[69] = xx[28] * xx[75];
  xx[70] = xx[35] * xx[75];
  xx[89] = xx[1] * (xx[105] - xx[69]) - xx[29];
  xx[90] = xx[1] * (xx[106] + xx[70]) - xx[26];
  xx[91] = xx[1] * (xx[75] * xx[60] + xx[107]);
  xx[35] = xx[29] * xx[49] - xx[26] * xx[55];
  xx[105] = xx[48];
  xx[106] = - xx[28];
  xx[107] = xx[35];
  pm_math_cross3(xx + 72, xx + 105, xx + 139);
  xx[72] = xx[1] * (xx[139] + xx[70]) - xx[26];
  xx[73] = xx[29] + xx[1] * (xx[140] + xx[69]);
  xx[74] = xx[1] * (xx[141] - xx[75] * xx[35]);
  xx[26] = xx[25] == 0.0 ? 0.0 : (xx[64] * (pm_math_dot3(xx + 110, xx + 124) +
    pm_math_dot3(xx + 97, xx + 89)) - xx[22] * (pm_math_dot3(xx + 110, xx + 83)
    + pm_math_dot3(xx + 97, xx + 72))) / xx[25];
  xx[72] = - (xx[32] * xx[31]);
  xx[73] = - (xx[33] * xx[31] + xx[46] * xx[56]);
  xx[74] = - (xx[32] * xx[56]);
  pm_math_quatXform(xx + 127, xx + 72, xx + 83);
  xx[72] = - (xx[14] * xx[31]);
  xx[73] = xx[13] * xx[31] + xx[52] * xx[56];
  xx[74] = - (xx[14] * xx[56]);
  pm_math_quatXform(xx + 127, xx + 72, xx + 31);
  xx[13] = xx[44] == 0.0 ? 0.0 : (xx[42] * (pm_math_dot3(xx + 110, xx + 79) +
    pm_math_dot3(xx + 97, xx + 83)) - xx[51] * (pm_math_dot3(xx + 110, xx + 115)
    + pm_math_dot3(xx + 97, xx + 31))) / xx[44];
  xx[31] = xx[27] * xx[0];
  xx[32] = xx[40] * xx[0];
  xx[33] = xx[41] * xx[0];
  pm_math_quatInverseXform(xx + 120, xx + 31, xx + 72);
  xx[14] = xx[74] + xx[17];
  xx[79] = xx[43] * xx[14];
  xx[80] = xx[45] * xx[14];
  xx[81] = - (xx[43] * xx[72] + xx[45] * xx[73]);
  pm_math_quatXform(xx + 135, xx + 79, xx + 83);
  pm_math_cross3(xx + 31, xx + 76, xx + 79);
  xx[31] = xx[104] + xx[79];
  xx[32] = xx[61] + xx[80];
  xx[33] = xx[62] + xx[81];
  pm_math_quatXform(xx + 131, xx + 31, xx + 60);
  xx[17] = xx[84] + xx[0] * xx[152] + xx[61];
  xx[22] = xx[83] + xx[0] * xx[151] + xx[60];
  xx[25] = xx[88] == 0.0 ? 0.0 : (xx[17] * xx[57] - xx[22] * xx[71]) / xx[88];
  xx[31] = xx[22];
  xx[32] = xx[17];
  xx[33] = xx[85] + xx[0] * xx[153] + xx[62];
  xx[0] = xx[63] * xx[14];
  xx[17] = - (xx[53] * xx[14]);
  xx[55] = - xx[0];
  xx[56] = xx[17];
  xx[57] = xx[63] * xx[72] + xx[53] * xx[73];
  pm_math_quatXform(xx + 135, xx + 55, xx + 60);
  xx[55] = xx[17];
  xx[56] = xx[0];
  xx[57] = xx[53] * xx[72] - xx[63] * xx[73];
  pm_math_quatXform(xx + 135, xx + 55, xx + 51);
  xx[0] = xx[34] == 0.0 ? 0.0 : (xx[146] * (pm_math_dot3(xx + 31, xx + 100) +
    pm_math_dot3(xx + 157, xx + 60)) - xx[82] * (pm_math_dot3(xx + 31, xx + 143)
    + pm_math_dot3(xx + 157, xx + 51))) / xx[34];
  xx[28] = fabs(xx[26] + xx[13]);
  xx[29] = fabs(xx[25] + xx[3] * xx[0]);
  ii[0] = 28;

  {
    int ll;
    for (ll = 29; ll < 30; ++ll)
      if (xx[ll] > xx[ii[0]])
        ii[0] = ll;
  }

  ii[0] -= 28;
  xx[0] = xx[28 + (ii[0])];
  xx[13] = xx[0] - xx[24];
  if (xx[13] < 0.0)
    ii[1] = -1;
  else if (xx[13] > 0.0)
    ii[1] = +1;
  else
    ii[1] = 0;
  ii[2] = ii[1];
  if (0 > ii[2])
    ii[2] = 0;
  if (ii[2] != 0) {
    switch (ii[0])
    {
     case 0:
      {
        return sm_ssci_recordRunTimeError(
          "sm:compiler:messages:simulationErrors:ConstraintViolation",
          "'sm_cardan_gear/PlanetA- PlanetB Gear' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem.",
          neDiagMgr);
      }

     case 1:
      {
        return sm_ssci_recordRunTimeError(
          "sm:compiler:messages:simulationErrors:ConstraintViolation",
          "'sm_cardan_gear/Sun-PlanetA Gear' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem.",
          neDiagMgr);
      }
    }
  }

  xx[0] = xx[3] * xx[164];
  xx[13] = cos(xx[0]);
  xx[14] = sin(xx[0]);
  xx[0] = xx[7] * xx[14];
  xx[17] = xx[10] * xx[14];
  xx[14] = xx[2] * xx[13] - xx[6] * xx[0] + xx[9] * xx[17];
  xx[22] = xx[9] * xx[13] + xx[12] * xx[0] - xx[2] * xx[17];
  xx[24] = xx[6] * xx[17] - xx[12] * xx[13] + xx[9] * xx[0];
  xx[31] = xx[14];
  xx[32] = xx[22];
  xx[33] = xx[24];
  xx[9] = xx[18] * xx[22];
  xx[25] = xx[20] * xx[24] + xx[18] * xx[14];
  xx[18] = xx[20] * xx[22];
  xx[51] = - xx[9];
  xx[52] = xx[25];
  xx[53] = - xx[18];
  pm_math_cross3(xx + 31, xx + 51, xx + 55);
  xx[20] = xx[6] * xx[13] + xx[2] * xx[0] + xx[12] * xx[17];
  xx[0] = xx[4] * xx[22];
  xx[2] = xx[11] * xx[24] - xx[4] * xx[14];
  xx[4] = xx[11] * xx[22];
  xx[11] = xx[0];
  xx[12] = xx[2];
  xx[13] = - xx[4];
  pm_math_cross3(xx + 31, xx + 11, xx + 51);
  xx[6] = xx[3] * xx[162];
  xx[11] = cos(xx[6]);
  xx[12] = sin(xx[6]);
  xx[6] = xx[16] * xx[11] - xx[30] * xx[12];
  xx[13] = xx[30] * xx[11] + xx[16] * xx[12];
  xx[16] = - xx[13];
  xx[17] = xx[37] * xx[11] - xx[38] * xx[12];
  xx[28] = xx[6];
  xx[29] = xx[16];
  xx[30] = xx[17];
  xx[26] = xx[43] * xx[17];
  xx[31] = xx[45] * xx[17];
  xx[32] = xx[45] * xx[13] - xx[43] * xx[6];
  xx[33] = xx[26];
  xx[34] = xx[31];
  xx[35] = xx[32];
  pm_math_cross3(xx + 28, xx + 33, xx + 60);
  xx[28] = xx[38] * xx[11] + xx[37] * xx[12];
  xx[11] = xx[1] * (xx[60] - xx[26] * xx[28]);
  xx[12] = xx[45] + xx[11];
  xx[26] = xx[1] * (xx[61] - xx[31] * xx[28]);
  xx[29] = xx[26] - xx[43];
  xx[30] = xx[1] * (xx[62] - xx[32] * xx[28]);
  xx[31] = xx[1] * (xx[55] - xx[9] * xx[20]) - xx[1] * (xx[0] * xx[20] + xx[51])
    + xx[15] - (xx[11] - xx[12] + xx[50]);
  xx[32] = xx[1] * (xx[20] * xx[25] + xx[56]) - xx[1] * (xx[20] * xx[2] + xx[52])
    + xx[54] - (xx[26] - xx[29] - xx[58]);
  xx[33] = xx[1] * (xx[57] - xx[18] * xx[20]) - xx[1] * (xx[53] - xx[4] * xx[20])
    - xx[59] - (xx[30] - xx[30] - xx[47]);
  xx[0] = xx[19] * xx[28] + xx[21] * xx[17];
  xx[2] = xx[19] * xx[17] - xx[21] * xx[28];
  xx[4] = xx[0] * xx[2];
  xx[9] = xx[19] * xx[13] + xx[21] * xx[6];
  xx[11] = xx[19] * xx[6] - xx[21] * xx[13];
  xx[13] = xx[9] * xx[11];
  xx[15] = xx[2] * xx[2];
  xx[48] = xx[1] * (xx[4] - xx[13]);
  xx[49] = xx[5] - xx[1] * (xx[15] + xx[11] * xx[11]);
  xx[50] = - (xx[1] * (xx[0] * xx[11] + xx[9] * xx[2]));
  xx[51] = xx[5] - xx[1] * (xx[9] * xx[9] + xx[15]);
  xx[52] = - (xx[1] * (xx[4] + xx[13]));
  xx[53] = xx[1] * (xx[2] * xx[11] - xx[9] * xx[0]);
  xx[4] = atan2(pm_math_dot3(xx + 31, xx + 48), pm_math_dot3(xx + 31, xx + 51))
    - xx[166];
  xx[5] = (xx[4] < 0.0 ? -1.0 : +1.0);
  xx[31] = - xx[0];
  xx[32] = xx[11];
  xx[33] = - xx[9];
  xx[34] = xx[2];
  xx[48] = xx[20];
  xx[49] = xx[14];
  xx[50] = xx[22];
  xx[51] = xx[24];
  xx[13] = xx[27] * xx[161];
  xx[14] = xx[40] * xx[161];
  xx[15] = xx[41] * xx[161];
  pm_math_quatInverseXform(xx + 48, xx + 13, xx + 18);
  xx[24] = xx[18] - xx[7] * xx[165];
  xx[25] = xx[19];
  xx[26] = xx[20] + xx[10] * xx[165];
  pm_math_quatXform(xx + 48, xx + 24, xx + 9);
  xx[18] = - xx[28];
  xx[19] = xx[6];
  xx[20] = xx[16];
  xx[21] = xx[17];
  pm_math_quatInverseXform(xx + 18, xx + 13, xx + 24);
  xx[13] = xx[24];
  xx[14] = xx[25];
  xx[15] = xx[26] + xx[163];
  pm_math_quatXform(xx + 18, xx + 13, xx + 24);
  xx[48] = xx[9] - xx[24];
  xx[49] = xx[10] - xx[25];
  xx[50] = xx[11] - xx[26];
  pm_math_quatInverseXform(xx + 31, xx + 48, xx + 9);
  xx[0] = xx[3] * xx[160];
  xx[2] = sin(xx[0]);
  xx[31] = cos(xx[0]);
  xx[32] = xx[27] * xx[2];
  xx[33] = xx[40] * xx[2];
  xx[34] = xx[41] * xx[2];
  pm_math_quatCompose(xx + 65, xx + 31, xx + 24);
  pm_math_quatCompose(xx + 24, xx + 18, xx + 31);
  xx[0] = xx[43] * xx[34];
  xx[16] = xx[0];
  xx[17] = xx[45] * xx[34];
  xx[18] = - (xx[43] * xx[32] + xx[45] * xx[33]);
  pm_math_cross3(xx + 32, xx + 16, xx + 19);
  xx[16] = xx[36] - xx[12];
  xx[17] = - (xx[39] + xx[29]);
  xx[18] = - (xx[47] + xx[30]);
  pm_math_quatXform(xx + 24, xx + 16, xx + 28);
  pm_math_quatXform(xx + 24, xx + 94, xx + 16);
  xx[2] = atan2(xx[1] * (xx[45] * xx[31] * xx[34] + xx[20]) + xx[29] - xx[17] -
                xx[43], xx[1] * (xx[19] + xx[0] * xx[31]) + xx[28] - xx[16] +
                xx[45]) - xx[168];
  xx[0] = (xx[2] < 0.0 ? -1.0 : +1.0);
  pm_math_quatXform(xx + 31, xx + 13, xx + 16);
  state[0] = xx[160];
  state[1] = xx[161];
  state[2] = xx[162];
  state[3] = xx[163];
  state[4] = xx[164];
  state[5] = xx[165];
  state[6] = xx[166] + (fmod(xx[8] + xx[4] * xx[5], xx[23]) - xx[8]) * xx[5];
  state[7] = xx[3] * xx[11];
  state[8] = xx[168] + (fmod(xx[8] + xx[2] * xx[0], xx[23]) - xx[8]) * xx[0];
  state[9] = 0.3333333333333333 * xx[18];
  state[10] = xx[170];
  state[11] = xx[171];
  return NULL;
}
