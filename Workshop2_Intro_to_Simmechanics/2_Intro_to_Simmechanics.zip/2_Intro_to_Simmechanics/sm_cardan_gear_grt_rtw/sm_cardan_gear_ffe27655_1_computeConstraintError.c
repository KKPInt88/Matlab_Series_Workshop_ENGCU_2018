/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cardan_gear/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

void sm_cardan_gear_ffe27655_1_computeConstraintError(const void *mech, const
  double *rtdv, const double *state, double *error)
{
  double xx[41];
  (void) mech;
  (void) rtdv;
  xx[0] = 3.141592653589793;
  xx[1] = 2.0;
  xx[2] = 0.04089681274430031;
  xx[3] = 0.5;
  xx[4] = xx[3] * state[4];
  xx[5] = cos(xx[4]);
  xx[6] = 0.8709379761288196;
  xx[7] = sin(xx[4]);
  xx[4] = 0.182724714184937 * xx[7];
  xx[8] = 0.07994726428595826;
  xx[9] = 0.9831641159165814 * xx[7];
  xx[7] = xx[2] * xx[5] - xx[6] * xx[4] + xx[8] * xx[9];
  xx[10] = 0.4831179228482263;
  xx[11] = xx[8] * xx[5] + xx[10] * xx[4] - xx[2] * xx[9];
  xx[12] = xx[6] * xx[9] - xx[10] * xx[5] + xx[8] * xx[4];
  xx[13] = xx[7];
  xx[14] = xx[11];
  xx[15] = xx[12];
  xx[8] = 7.034264913192121e-3;
  xx[16] = xx[8] * xx[11];
  xx[17] = 0.03468999503471949;
  xx[18] = xx[17] * xx[12] + xx[8] * xx[7];
  xx[8] = xx[17] * xx[11];
  xx[19] = - xx[16];
  xx[20] = xx[18];
  xx[21] = - xx[8];
  pm_math_cross3(xx + 13, xx + 19, xx + 22);
  xx[17] = xx[6] * xx[5] + xx[2] * xx[4] + xx[10] * xx[9];
  xx[2] = 7.713196825556601e-3;
  xx[4] = xx[2] * xx[11];
  xx[5] = 0.03194912432194544;
  xx[6] = xx[5] * xx[12] - xx[2] * xx[7];
  xx[2] = xx[5] * xx[11];
  xx[19] = xx[4];
  xx[20] = xx[6];
  xx[21] = - xx[2];
  pm_math_cross3(xx + 13, xx + 19, xx + 25);
  xx[5] = 3.568507962179244e-3;
  xx[9] = xx[3] * state[2];
  xx[10] = cos(xx[9]);
  xx[13] = 5.699653188004584e-4;
  xx[14] = sin(xx[9]);
  xx[9] = xx[5] * xx[10] - xx[13] * xx[14];
  xx[15] = xx[13] * xx[10] + xx[5] * xx[14];
  xx[5] = - xx[15];
  xx[13] = 0.2621533222727515;
  xx[19] = 0.9650194694988377;
  xx[20] = xx[13] * xx[10] - xx[19] * xx[14];
  xx[28] = xx[9];
  xx[29] = xx[5];
  xx[30] = xx[20];
  xx[21] = 4.336171384355309e-17;
  xx[31] = xx[21] * xx[20];
  xx[32] = 6.240732392112002e-18;
  xx[33] = xx[32] * xx[20];
  xx[34] = xx[32] * xx[15] - xx[21] * xx[9];
  xx[35] = xx[31];
  xx[36] = xx[33];
  xx[37] = xx[34];
  pm_math_cross3(xx + 28, xx + 35, xx + 38);
  xx[28] = xx[19] * xx[10] + xx[13] * xx[14];
  xx[10] = xx[1] * (xx[38] - xx[31] * xx[28]);
  xx[13] = xx[32] + xx[10];
  xx[14] = xx[1] * (xx[39] - xx[33] * xx[28]);
  xx[19] = xx[14] - xx[21];
  xx[29] = xx[1] * (xx[40] - xx[34] * xx[28]);
  xx[30] = 0.01449907368972891;
  xx[33] = xx[1] * (xx[22] - xx[16] * xx[17]) - xx[1] * (xx[4] * xx[17] + xx[25])
    + 0.08092328375554529 - (xx[10] - xx[13] + 0.03696626849097064);
  xx[34] = xx[1] * (xx[18] * xx[17] + xx[23]) - xx[1] * (xx[6] * xx[17] + xx[26])
    + 0.03914259083055165 - (xx[14] - xx[19] - 0.05208460108431659);
  xx[35] = xx[1] * (xx[24] - xx[8] * xx[17]) - xx[1] * (xx[27] - xx[2] * xx[17])
    - 0.01496967009981087 - (xx[29] - xx[29] - xx[30]);
  xx[2] = 0.9985915472931449;
  xx[4] = 0.05305583544420572;
  xx[6] = xx[2] * xx[28] + xx[4] * xx[20];
  xx[8] = xx[2] * xx[20] - xx[4] * xx[28];
  xx[10] = xx[6] * xx[8];
  xx[14] = xx[2] * xx[15] + xx[4] * xx[9];
  xx[16] = xx[2] * xx[9] - xx[4] * xx[15];
  xx[15] = xx[14] * xx[16];
  xx[18] = 1.0;
  xx[22] = xx[8] * xx[8];
  xx[23] = xx[1] * (xx[10] - xx[15]);
  xx[24] = xx[18] - xx[1] * (xx[22] + xx[16] * xx[16]);
  xx[25] = - (xx[1] * (xx[6] * xx[16] + xx[14] * xx[8]));
  xx[36] = xx[18] - xx[1] * (xx[14] * xx[14] + xx[22]);
  xx[37] = - (xx[1] * (xx[10] + xx[15]));
  xx[38] = xx[1] * (xx[8] * xx[16] - xx[6] * xx[14]);
  xx[6] = atan2(pm_math_dot3(xx + 33, xx + 23), pm_math_dot3(xx + 33, xx + 36))
    - state[6];
  xx[8] = (xx[6] < 0.0 ? -1.0 : +1.0);
  xx[10] = 6.283185307179586;
  xx[22] = xx[17];
  xx[23] = xx[7];
  xx[24] = xx[11];
  xx[25] = xx[12];
  xx[14] = - 0.9530551403624588;
  xx[15] = 0.02658750541312705;
  xx[16] = 0.08781256514654519;
  xx[17] = - 0.2885618779169991;
  pm_math_quatCompose(xx + 22, xx + 14, xx + 36);
  xx[7] = xx[37] * xx[38];
  xx[11] = xx[36] * xx[39];
  xx[12] = xx[39] * xx[39];
  xx[14] = xx[1] * (xx[7] - xx[11]);
  xx[15] = xx[18] - xx[1] * (xx[12] + xx[37] * xx[37]);
  xx[16] = xx[1] * (xx[36] * xx[37] + xx[38] * xx[39]);
  xx[22] = xx[18] - xx[1] * (xx[38] * xx[38] + xx[12]);
  xx[23] = xx[1] * (xx[11] + xx[7]);
  xx[24] = xx[1] * (xx[37] * xx[39] - xx[36] * xx[38]);
  xx[7] = state[6] + (fmod(xx[0] + xx[6] * xx[8], xx[10]) - xx[0]) * xx[8] -
    state[10] + atan2(pm_math_dot3(xx + 33, xx + 14), pm_math_dot3(xx + 33, xx +
    22));
  xx[6] = (xx[7] < 0.0 ? -1.0 : +1.0);
  xx[14] = 0.9775690487425092;
  xx[15] = 3.533241901317298e-3;
  xx[16] = - 7.584927208271003e-4;
  xx[17] = 0.2105841775422004;
  xx[8] = xx[3] * state[0];
  xx[11] = sin(xx[8]);
  xx[22] = cos(xx[8]);
  xx[23] = 2.971047694847219e-3 * xx[11];
  xx[24] = 6.588522717321608e-3 * xx[11];
  xx[25] = 0.9999738817809185 * xx[11];
  pm_math_quatCompose(xx + 14, xx + 22, xx + 33);
  xx[14] = - xx[28];
  xx[15] = xx[9];
  xx[16] = xx[5];
  xx[17] = xx[20];
  pm_math_quatCompose(xx + 33, xx + 14, xx + 22);
  xx[5] = xx[21] * xx[25];
  xx[8] = xx[21] * xx[23] + xx[32] * xx[24];
  xx[14] = xx[5];
  xx[15] = xx[32] * xx[25];
  xx[16] = - xx[8];
  pm_math_cross3(xx + 23, xx + 14, xx + 26);
  xx[14] = 0.03696626849097063 - xx[13];
  xx[15] = - (0.05208460108431655 + xx[19]);
  xx[16] = - (xx[30] + xx[29]);
  pm_math_quatXform(xx + 33, xx + 14, xx + 11);
  xx[14] = - 0.09972985016632961;
  xx[15] = 9.674375133208124e-3;
  xx[16] = - 0.01449984343940976;
  pm_math_quatXform(xx + 33, xx + 14, xx + 29);
  xx[9] = xx[1] * (xx[32] * xx[22] * xx[25] + xx[27]) - xx[21] + xx[12] - xx[30];
  xx[14] = xx[32] + xx[1] * (xx[26] + xx[5] * xx[22]) + xx[11] - xx[29];
  xx[5] = atan2(xx[9], xx[14]) - state[8];
  xx[15] = (xx[5] < 0.0 ? -1.0 : +1.0);
  xx[19] = xx[14];
  xx[20] = xx[9];
  xx[21] = xx[1] * (xx[28] - xx[8] * xx[22]) + xx[13] - xx[31];
  xx[8] = xx[2] * xx[24] - xx[4] * xx[23];
  xx[9] = xx[2] * xx[23] + xx[4] * xx[24];
  xx[11] = xx[8] * xx[9];
  xx[12] = xx[2] * xx[22] - xx[4] * xx[25];
  xx[13] = xx[4] * xx[22] + xx[2] * xx[25];
  xx[2] = xx[12] * xx[13];
  xx[4] = xx[13] * xx[13];
  xx[22] = xx[1] * (xx[11] - xx[2]);
  xx[23] = xx[18] - xx[1] * (xx[4] + xx[9] * xx[9]);
  xx[24] = xx[1] * (xx[12] * xx[9] + xx[8] * xx[13]);
  xx[25] = xx[18] - xx[1] * (xx[8] * xx[8] + xx[4]);
  xx[26] = xx[1] * (xx[2] + xx[11]);
  xx[27] = xx[1] * (xx[13] * xx[9] - xx[8] * xx[12]);
  xx[1] = (state[8] + (fmod(xx[0] + xx[5] * xx[15], xx[10]) - xx[0]) * xx[15] -
           state[11]) / xx[3] + atan2(pm_math_dot3(xx + 19, xx + 22),
    pm_math_dot3(xx + 19, xx + 25));
  xx[2] = (xx[1] < 0.0 ? -1.0 : +1.0);
  error[0] = (fmod(xx[0] + xx[6] * xx[7], xx[10]) - xx[0]) * xx[6];
  error[1] = xx[3] * (fmod(xx[0] + xx[2] * xx[1], xx[10]) - xx[0]) * xx[2];
}
