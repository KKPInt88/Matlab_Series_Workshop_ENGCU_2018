/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_cardan_gear/Solver Configuration'.
 */

#ifndef __sm_cardan_gear_ffe27655_1_gateway_h__
#define __sm_cardan_gear_ffe27655_1_gateway_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void sm_cardan_gear_ffe27655_1_gateway(void);

#ifdef __cplusplus

}
#endif
#endif                                 /* #ifndef __sm_cardan_gear_ffe27655_1_gateway_h__ */
