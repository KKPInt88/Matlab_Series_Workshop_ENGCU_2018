/*
 * Part2_2_Model_a_Simple_Link.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Part2_2_Model_a_Simple_Link".
 *
 * Model version              : 1.9
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Mon Sep 24 17:20:24 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Part2_2_Model_a_Simple_Link.h"
#include "Part2_2_Model_a_Simple_Link_private.h"

/* Block states (default storage) */
DW_Part2_2_Model_a_Simple_Lin_T Part2_2_Model_a_Simple_Link_DW;

/* Real-time model */
RT_MODEL_Part2_2_Model_a_Simp_T Part2_2_Model_a_Simple_Link_M_;
RT_MODEL_Part2_2_Model_a_Simp_T *const Part2_2_Model_a_Simple_Link_M =
  &Part2_2_Model_a_Simple_Link_M_;

/* Model step function */
void Part2_2_Model_a_Simple_Link_step(void)
{
  {
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp;
    int_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_1;
    char *msg;

    /* SimscapeExecutionBlock: '<S3>/STATE_1' */
    simulationData = (NeslSimulationData *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_SimulationData;
    time = Part2_2_Model_a_Simple_Link_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = NULL;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (Part2_2_Model_a_Simple_Link_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0 = 0;
    simulationData->mData->mInputValues.mN = 0;
    simulationData->mData->mInputOffsets.mN = 1;
    simulationData->mData->mInputOffsets.mX = &tmp_0;
    simulationData->mData->mOutputs.mN = 0;
    simulationData->mData->mOutputs.mX = NULL;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    diagnosticManager = (NeuDiagnosticManager *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_1 = ne_simulator_method((NeslSimulator *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator, NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (tmp_1 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus
        (Part2_2_Model_a_Simple_Link_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Part2_2_Model_a_Simple_Link_M, msg);
      }
    }

    /* End of SimscapeExecutionBlock: '<S3>/STATE_1' */
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(Part2_2_Model_a_Simple_Link_M->rtwLogInfo,
                      (Part2_2_Model_a_Simple_Link_M->Timing.t));

  {
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp;
    int_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_1;
    char *msg;

    /* Update for SimscapeExecutionBlock: '<S3>/STATE_1' */
    simulationData = (NeslSimulationData *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_SimulationData;
    time = Part2_2_Model_a_Simple_Link_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = NULL;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (Part2_2_Model_a_Simple_Link_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0 = 0;
    simulationData->mData->mInputValues.mN = 0;
    simulationData->mData->mInputOffsets.mN = 1;
    simulationData->mData->mInputOffsets.mX = &tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_1 = ne_simulator_method((NeslSimulator *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator, NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (tmp_1 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus
        (Part2_2_Model_a_Simple_Link_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Part2_2_Model_a_Simple_Link_M, msg);
      }
    }

    /* End of Update for SimscapeExecutionBlock: '<S3>/STATE_1' */
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(Part2_2_Model_a_Simple_Link_M)!=-1) &&
        !((rtmGetTFinal(Part2_2_Model_a_Simple_Link_M)-
           Part2_2_Model_a_Simple_Link_M->Timing.t[0]) >
          Part2_2_Model_a_Simple_Link_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(Part2_2_Model_a_Simple_Link_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Part2_2_Model_a_Simple_Link_M->Timing.clockTick0)) {
    ++Part2_2_Model_a_Simple_Link_M->Timing.clockTickH0;
  }

  Part2_2_Model_a_Simple_Link_M->Timing.t[0] =
    Part2_2_Model_a_Simple_Link_M->Timing.clockTick0 *
    Part2_2_Model_a_Simple_Link_M->Timing.stepSize0 +
    Part2_2_Model_a_Simple_Link_M->Timing.clockTickH0 *
    Part2_2_Model_a_Simple_Link_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    Part2_2_Model_a_Simple_Link_M->Timing.clockTick1++;
    if (!Part2_2_Model_a_Simple_Link_M->Timing.clockTick1) {
      Part2_2_Model_a_Simple_Link_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void Part2_2_Model_a_Simple_Link_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Part2_2_Model_a_Simple_Link_M, 0,
                sizeof(RT_MODEL_Part2_2_Model_a_Simp_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Part2_2_Model_a_Simple_Link_M->solverInfo,
                          &Part2_2_Model_a_Simple_Link_M->Timing.simTimeStep);
    rtsiSetTPtr(&Part2_2_Model_a_Simple_Link_M->solverInfo, &rtmGetTPtr
                (Part2_2_Model_a_Simple_Link_M));
    rtsiSetStepSizePtr(&Part2_2_Model_a_Simple_Link_M->solverInfo,
                       &Part2_2_Model_a_Simple_Link_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&Part2_2_Model_a_Simple_Link_M->solverInfo,
                          (&rtmGetErrorStatus(Part2_2_Model_a_Simple_Link_M)));
    rtsiSetRTModelPtr(&Part2_2_Model_a_Simple_Link_M->solverInfo,
                      Part2_2_Model_a_Simple_Link_M);
  }

  rtsiSetSimTimeStep(&Part2_2_Model_a_Simple_Link_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&Part2_2_Model_a_Simple_Link_M->solverInfo,
                    "FixedStepDiscrete");
  rtmSetTPtr(Part2_2_Model_a_Simple_Link_M,
             &Part2_2_Model_a_Simple_Link_M->Timing.tArray[0]);
  rtmSetTFinal(Part2_2_Model_a_Simple_Link_M, 10.0);
  Part2_2_Model_a_Simple_Link_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Part2_2_Model_a_Simple_Link_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, (NULL));
    rtliSetLogT(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, "tout");
    rtliSetLogX(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, "");
    rtliSetLogXFinal(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, 1);
    rtliSetLogY(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Part2_2_Model_a_Simple_Link_M->rtwLogInfo, (NULL));
  }

  /* states (dwork) */
  (void) memset((void *)&Part2_2_Model_a_Simple_Link_DW, 0,
                sizeof(DW_Part2_2_Model_a_Simple_Lin_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Part2_2_Model_a_Simple_Link_M->rtwLogInfo,
    0.0, rtmGetTFinal(Part2_2_Model_a_Simple_Link_M),
    Part2_2_Model_a_Simple_Link_M->Timing.stepSize0, (&rtmGetErrorStatus
    (Part2_2_Model_a_Simple_Link_M)));

  {
    NeslSimulator *tmp;
    boolean_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeModelParameters modelParameters;
    real_T tmp_1;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;
    NeslSimulationData *simulationData;
    real_T time;
    NeParameterBundle expl_temp;

    /* Start for SimscapeExecutionBlock: '<S3>/STATE_1' */
    tmp = nesl_lease_simulator(
      "Part2_2_Model_a_Simple_Link/Solver Configuration_1", 0, 0);
    Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator);
    if (tmp_0) {
      Part2_2_Model_a_Simple_Link_1ad28ea1_1_gateway();
      tmp = nesl_lease_simulator(
        "Part2_2_Model_a_Simple_Link/Solver Configuration_1", 0, 0);
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    Part2_2_Model_a_Simple_Link_DW.STATE_1_SimulationData = (void *)
      simulationData;
    diagnosticManager = rtw_create_diagnostics();
    Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager = (void *)
      diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverTolerance = 0.001;
    modelParameters.mVariableStepSolver = false;
    modelParameters.mFixedStepSize = 0.001;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters.mRTWModifiedTimeStamp = 4.59710419E+8;
    tmp_1 = 0.001;
    modelParameters.mSolverTolerance = tmp_1;
    tmp_1 = 0.001;
    modelParameters.mFixedStepSize = tmp_1;
    tmp_0 = false;
    modelParameters.mVariableStepSolver = tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator, &modelParameters,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (Part2_2_Model_a_Simple_Link_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Part2_2_Model_a_Simple_Link_M, msg);
      }
    }

    expl_temp.mRealParameters.mN = 0;
    expl_temp.mRealParameters.mX = NULL;
    expl_temp.mLogicalParameters.mN = 0;
    expl_temp.mLogicalParameters.mX = NULL;
    expl_temp.mIntegerParameters.mN = 0;
    expl_temp.mIntegerParameters.mX = NULL;
    expl_temp.mIndexParameters.mN = 0;
    expl_temp.mIndexParameters.mX = NULL;
    nesl_simulator_set_rtps((NeslSimulator *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator, expl_temp);
    simulationData = (NeslSimulationData *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_SimulationData;
    time = Part2_2_Model_a_Simple_Link_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = NULL;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = NULL;
    tmp_0 = false;
    simulationData->mData->mFoundZcEvents = tmp_0;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (Part2_2_Model_a_Simple_Link_M);
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      Part2_2_Model_a_Simple_Link_DW.STATE_1_Simulator, NESL_SIM_INITIALIZEONCE,
      simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (Part2_2_Model_a_Simple_Link_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Part2_2_Model_a_Simple_Link_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S3>/STATE_1' */
  }
}

/* Model terminate function */
void Part2_2_Model_a_Simple_Link_terminate(void)
{
  /* Terminate for SimscapeExecutionBlock: '<S3>/STATE_1' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    Part2_2_Model_a_Simple_Link_DW.STATE_1_DiagnosticManager);
  nesl_destroy_simulation_data((NeslSimulationData *)
    Part2_2_Model_a_Simple_Link_DW.STATE_1_SimulationData);
  nesl_erase_simulator("Part2_2_Model_a_Simple_Link/Solver Configuration_1");
}
