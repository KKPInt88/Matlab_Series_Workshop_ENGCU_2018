/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_2_Model_a_Simple_Link/Solver Configuration'.
 */

#ifndef __Part2_2_Model_a_Simple_Link_1ad28ea1_1_gateway_h__
#define __Part2_2_Model_a_Simple_Link_1ad28ea1_1_gateway_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void Part2_2_Model_a_Simple_Link_1ad28ea1_1_gateway(void);

#ifdef __cplusplus

}
#endif
#endif                                 /* #ifndef __Part2_2_Model_a_Simple_Link_1ad28ea1_1_gateway_h__ */
