/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_2_Model_a_Simple_Link/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeConstraintError(const void
  *mech, const double *rtdv, const double *state, double *error)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) error;
}
