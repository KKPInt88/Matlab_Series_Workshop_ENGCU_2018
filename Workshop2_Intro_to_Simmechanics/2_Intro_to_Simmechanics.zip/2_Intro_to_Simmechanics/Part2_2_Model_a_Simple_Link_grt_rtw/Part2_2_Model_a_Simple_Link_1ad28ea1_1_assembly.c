/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Part2_2_Model_a_Simple_Link/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_CTarget.h"

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_checkTargets(const double *rtdv,
  const double *state)
{
  (void) rtdv;
  (void) state;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_setTargets(const double *rtdv,
  CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_resetStateVector(const void *mech,
  double *state)
{
  (void) mech;
  (void) state;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_initializeTrackedAngleState(const
  void *mech, const double *rtdv, const double *motionData, double *state, void *
  neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) motionData;
  (void) state;
  (void) neDiagMgr;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeDiscreteState(const void
  *mech, const double *rtdv, double *state)
{
  (void) mech;
  (void) rtdv;
  (void) state;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_adjustPosition(const void *mech,
  const double *dofDeltas, double *state)
{
  (void) mech;
  (void) dofDeltas;
  (void) state;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_perturbJointPrimitiveState(const
  void *mech, size_t stageIdx, size_t primIdx, double mag, boolean_T
  doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
  }
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_perturbFlexibleBodyState(const void *
  mech, size_t stageIdx, double mag, boolean_T doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch (stageIdx * 2 + (doPerturbVelocity ? 1 : 0))
  {
  }
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeDofBlendMatrix(const void
  *mech, size_t stageIdx, size_t primIdx, const double *state, int partialType,
  double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_projectPartiallyTargetedPos(const
  void *mech, size_t stageIdx, size_t primIdx, const double *origState, int
  partialType, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_propagateMotion(const void *mech,
  const double *rtdv, const double *state, double *motionData)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) motionData;
}

size_t Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeAssemblyError(const void
  *mech, const double *rtdv, size_t constraintIdx, const double *state, const
  double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) state;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeAssemblyJacobian(const void
  *mech, const double *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const double *motionData, double
  *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t Part2_2_Model_a_Simple_Link_1ad28ea1_1_computeFullAssemblyJacobian(const
  void *mech, const double *rtdv, const double *state, const double *motionData,
  double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) motionData;
  (void) J;
  return 0;
}

int Part2_2_Model_a_Simple_Link_1ad28ea1_1_isInKinematicSingularity(const void
  *mech, const double *rtdv, size_t constraintIdx, const double *motionData)
{
  (void) mech;
  (void) rtdv
    ;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

PmfMessageId Part2_2_Model_a_Simple_Link_1ad28ea1_1_convertStateVector(const
  void *asmMech, const double *rtdv, const void *simMech, const double *asmState,
  double *simState, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) asmMech;
  (void) rtdv;
  (void) simMech;
  (void) asmState;
  (void) simState;
  (void) neDiagMgr;
  return NULL;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_constructStateVector(const void
  *mech, const double *solverState, const double *u, const double *uDot, double *
  discreteState, double *fullState)
{
  (void) mech;
  (void) solverState;
  (void) u;
  (void) uDot;
  (void) discreteState;
  (void) fullState;
}

void Part2_2_Model_a_Simple_Link_1ad28ea1_1_extractSolverStateVector(const void *
  mech, const double *fullState, double *solverState)
{
  (void) mech;
  (void) fullState;
  (void) solverState;
}

int Part2_2_Model_a_Simple_Link_1ad28ea1_1_isPositionViolation(const void *mech,
  const double *rtdv, const int *eqnEnableFlags, const double *state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

int Part2_2_Model_a_Simple_Link_1ad28ea1_1_isVelocityViolation(const void *mech,
  const double *rtdv, const int *eqnEnableFlags, const double *state)
{
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) state;
  return 0;
}

PmfMessageId Part2_2_Model_a_Simple_Link_1ad28ea1_1_projectStateSim(const void
  *mech, const double *rtdv, const int *eqnEnableFlags, const double *input,
  double *state, void *neDiagMgr0)
{
  NeuDiagnosticManager *neDiagMgr = (NeuDiagnosticManager *) neDiagMgr0;
  (void) mech;
  (void) rtdv;
  (void) eqnEnableFlags;
  (void) input;
  (void) state;
  (void) neDiagMgr;
  return NULL;
}
